import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Where the Python API runs. Module 9: API_TARGET=http://localhost:8080 npm run dev
// sends every /api call through the load balancer instead.
const API_TARGET = process.env.API_TARGET || "http://localhost:8000";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    // The browser calls /api/... on localhost:5173, Vite forwards it to the API.
    // Same origin for the browser = no CORS problems during development.
    proxy: {
      "/api": { target: API_TARGET, changeOrigin: true },
    },
  },
});
