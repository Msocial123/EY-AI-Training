import { createContext, useContext, useEffect, useState } from "react";
import { devOptions } from "../services/apiClient";

// Small second context: developer switches in the footer + which API server answered last.
const DevToolsContext = createContext(null);

export function DevToolsProvider({ children }) {
  const [simulateErrors, setSimulateErrors] = useState(false);
  const [slowNetwork, setSlowNetwork] = useState(false);
  const [servedBy, setServedBy] = useState("-");

  useEffect(() => {
    devOptions.simulateErrors = simulateErrors;      // the axios interceptor reads these
    devOptions.slowNetwork = slowNetwork;
    devOptions.onServedBy = (name) => name && setServedBy(name);
  }, [simulateErrors, slowNetwork]);

  return (
    <DevToolsContext.Provider value={{ simulateErrors, setSimulateErrors, slowNetwork, setSlowNetwork, servedBy }}>
      {children}
    </DevToolsContext.Provider>
  );
}

export const useDevTools = () => useContext(DevToolsContext);
