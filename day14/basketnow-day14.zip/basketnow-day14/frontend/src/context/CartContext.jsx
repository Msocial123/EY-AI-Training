import { createContext, useContext, useEffect, useMemo, useReducer } from "react";
import { estimateBill } from "../utils/bill";
import { cartReducer, initialCart, toCartItem } from "./cartReducer";

// SHARED STATE: the cart is needed by Header (count), ProductCard (ADD / stepper),
// CartPage, CheckoutPage... Instead of passing it through every component (prop drilling),
// we put it in a Context. Any component can read it with useCart().
const CartContext = createContext(null);
const STORAGE_KEY = "bn-cart-v2";

function loadSavedCart() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));     // JSON text -> object
    return saved && Array.isArray(saved.items) ? saved : initialCart;
  } catch {
    return initialCart;                                               // broken JSON -> start empty
  }
}

export function CartProvider({ children }) {
  const [cart, dispatch] = useReducer(cartReducer, undefined, loadSavedCart);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));          // object -> JSON text
  }, [cart]);

  // useMemo: build the value object only when the cart changes, so consumers don't re-render for nothing.
  const value = useMemo(() => {
    const bill = estimateBill(cart.items, cart.couponCode);
    return {
      items: cart.items,
      couponCode: cart.couponCode,
      count: bill.itemCount,
      bill,
      qtyOf: (variantId) => cart.items.find((i) => i.variantId === variantId)?.qty ?? 0,
      addItem: (product, variant) => dispatch({ type: "ADD_ITEM", item: toCartItem(product, variant) }),
      setQty: (variantId, qty) => dispatch({ type: "SET_QTY", variantId, qty }),
      removeItem: (variantId) => dispatch({ type: "REMOVE_ITEM", variantId }),
      applyCoupon: (code) => dispatch({ type: "APPLY_COUPON", code }),
      removeCoupon: () => dispatch({ type: "REMOVE_COUPON" }),
      clearCart: () => dispatch({ type: "CLEAR" }),
    };
  }, [cart]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

// Custom hook: one import for components, and a clear error if the Provider is missing.
export function useCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error("useCart() must be used inside <CartProvider>");
  return context;
}
