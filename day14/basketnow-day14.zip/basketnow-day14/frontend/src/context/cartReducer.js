import { MAX_QTY_PER_ITEM } from "../utils/rules";

// The reducer is a PURE function: (current state, action) -> NEW state.
// All the ways the cart can change are listed here, in one place.
export const initialCart = { items: [], couponCode: null };

const clamp = (qty, maxQty) => Math.max(0, Math.min(qty, maxQty, MAX_QTY_PER_ITEM));

export function cartReducer(state, action) {
  switch (action.type) {
    case "ADD_ITEM": {
      const existing = state.items.find((i) => i.variantId === action.item.variantId);
      if (existing) {
        return cartReducer(state, { type: "SET_QTY", variantId: existing.variantId, qty: existing.qty + 1 });
      }
      return { ...state, items: [...state.items, { ...action.item, qty: 1 }] };   // new array, never push()
    }
    case "SET_QTY": {
      const items = state.items
        .map((i) => (i.variantId === action.variantId ? { ...i, qty: clamp(action.qty, i.maxQty) } : i))
        .filter((i) => i.qty > 0);                                                   // qty 0 = remove
      return { ...state, items, couponCode: items.length ? state.couponCode : null };
    }
    case "REMOVE_ITEM":
      return cartReducer(state, { type: "SET_QTY", variantId: action.variantId, qty: 0 });
    case "APPLY_COUPON":
      return { ...state, couponCode: action.code };
    case "REMOVE_COUPON":
      return { ...state, couponCode: null };
    case "CLEAR":
      return initialCart;
    default:
      throw new Error(`Unknown cart action: ${action.type}`);   // catches typos like "ADD_ITME"
  }
}

// Turn a product + chosen pack size into a cart line (a small JSON snapshot for display).
export const toCartItem = (product, variant) => ({
  variantId: variant.id,
  productId: product.id,
  name: product.name,
  label: variant.label,
  image: product.image,
  category: product.category,
  price: variant.price,
  mrp: variant.mrp,
  maxQty: variant.stock,
});
