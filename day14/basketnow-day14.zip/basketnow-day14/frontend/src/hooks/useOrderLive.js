import { useEffect, useState } from "react";
import { orderService } from "../services/orderService";

const WS_URL = import.meta.env.VITE_WS_URL ?? "ws://localhost:8765";
const FINAL = ["DELIVERED", "CANCELLED"];

// Live order tracking (Module 7).
// 1st choice: WebSocket - the server PUSHES each status change instantly.
// Fallback  : if the WebSocket server is down, POLL the REST API every 5 seconds.
export function useOrderLive(orderId, initialOrder) {
  const [order, setOrder] = useState(initialOrder);
  const [mode, setMode] = useState("connecting");     // "connecting" | "live" | "polling" | "finished"

  useEffect(() => setOrder(initialOrder), [initialOrder]);

  useEffect(() => {
    if (!initialOrder || FINAL.includes(initialOrder.status)) {
      setMode("finished");
      return undefined;
    }
    let socket = null;
    let pollTimer = null;
    let stopped = false;

    function startPolling() {
      if (stopped || pollTimer) return;
      setMode("polling");
      pollTimer = setInterval(async () => {
        try {
          const latest = await orderService.getById(orderId);
          setOrder(latest);
          if (FINAL.includes(latest.status)) {
            clearInterval(pollTimer);
            setMode("finished");
          }
        } catch {
          /* keep trying on the next tick */
        }
      }, 5000);
    }

    try {
      socket = new WebSocket(`${WS_URL}/orders/${orderId}`);
      socket.onopen = () => setMode("live");
      socket.onmessage = (event) => {
        const message = JSON.parse(event.data);           // WebSocket messages are text -> parse JSON
        if (message.type === "order") setOrder(message.order);
      };
      socket.onclose = (event) => {
        if (stopped) return;
        if (event.code === 1000) setMode("finished");     // server closed normally: delivered / cancelled
        else startPolling();                               // could not connect / dropped -> fall back
      };
    } catch {
      startPolling();
    }

    return () => {                                         // leaving the page: close everything
      stopped = true;
      socket?.close();
      clearInterval(pollTimer);
    };
  }, [orderId, initialOrder]);

  return { order, mode, setOrder };
}
