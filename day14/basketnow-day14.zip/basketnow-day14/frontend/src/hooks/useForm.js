import { useRef, useState } from "react";

// Reusable form logic: values, errors, touched, submit. Any form in the app can use it.
//
//   const form = useForm({ initialValues, validate, onSubmit });
//   <input name="phone" value={form.values.phone} onChange={form.handleChange} onBlur={form.handleBlur} />
//   {form.errorFor("phone")}
export function useForm({ initialValues, validate, onSubmit, transform = {} }) {
  const [values, setValues] = useState(initialValues);
  const [touched, setTouched] = useState({});           // fields the user has visited
  const [submitted, setSubmitted] = useState(false);    // did the user try to submit once?
  const [submitting, setSubmitting] = useState(false);
  const [serverErrors, setServerErrors] = useState({}); // errors the API sent back
  const formRef = useRef(null);

  // Errors are DERIVED from values on every render - never stored separately (Day 13 rule).
  const errors = { ...validate(values), ...serverErrors };
  const isValid = Object.keys(validate(values)).length === 0;

  function handleChange(event) {
    const { name, type, value, checked } = event.target;
    const raw = type === "checkbox" ? checked : value;
    const next = transform[name] ? transform[name](raw) : raw;      // e.g. keep only digits
    setValues((v) => ({ ...v, [name]: next }));
    setServerErrors(({ [name]: _removed, ...rest }) => rest);       // typing clears the server error
  }

  function handleBlur(event) {
    setTouched((t) => ({ ...t, [event.target.name]: true }));
  }

  // Show an error only after the user touched the field or pressed submit - not while they start typing.
  const errorFor = (name) => ((touched[name] || submitted) && errors[name]) || "";

  async function handleSubmit(event) {
    event.preventDefault();                                 // stop the browser from reloading the page
    setSubmitted(true);
    const currentErrors = validate(values);
    const firstInvalid = Object.keys(currentErrors)[0];
    if (firstInvalid) {
      const element = formRef.current?.elements[firstInvalid];
      (element?.focus ? element : element?.[0])?.focus();   // radio groups are a list: focus the first one
      return;
    }
    setSubmitting(true);
    try {
      await onSubmit(values, { setServerErrors });
    } finally {
      setSubmitting(false);
    }
  }

  const setValue = (name, value) => setValues((v) => ({ ...v, [name]: value }));

  return { values, errors, touched, isValid, submitting, submitted, formRef,
           handleChange, handleBlur, handleSubmit, errorFor, setValue, setServerErrors };
}
