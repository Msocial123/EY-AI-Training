import { useCallback, useEffect, useState } from "react";

// Reusable hook for "load data from the API when the page opens".
// Gives every page the same three states: loading, error, data - plus reload() for a Retry button.
//
//   const { data, loading, error, reload } = useApi((signal) => productService.getById(id, { signal }), [id]);
export function useApi(fetcher, deps = []) {
  const [state, setState] = useState({ data: null, loading: true, error: null });
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    const controller = new AbortController();
    setState((s) => ({ ...s, loading: true, error: null }));        // keep old data while reloading

    fetcher(controller.signal)
      .then((data) => setState({ data, loading: false, error: null }))
      .catch((error) => {
        if (error.code === "CANCELLED") return;                         // we cancelled it ourselves
        setState({ data: null, loading: false, error });
      });

    // CLEANUP (Day 13 lifecycle!): if the user leaves the page or deps change,
    // cancel the old request so a slow old answer can never overwrite new data.
    return () => controller.abort();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, attempt]);

  const reload = useCallback(() => setAttempt((n) => n + 1), []);
  return { ...state, reload };
}
