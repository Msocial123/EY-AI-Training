import { COD_LIMIT } from "./rules";

// Validation RULES for the checkout form. Each rule returns an error message or "" (valid).
// Kept as plain functions so they are easy to read, reuse and test.
export const rules = {
  fullName: (v) =>
    !v.trim() ? "Full name is required"
      : !/^[A-Za-z][A-Za-z .]{1,49}$/.test(v.trim()) ? "Use letters only, 2 to 50 characters" : "",
  phone: (v) =>
    !v ? "Mobile number is required"
      : v.length !== 10 ? `Mobile number must be 10 digits (you typed ${v.length})`
      : !/^[6-9]/.test(v) ? "Indian mobile numbers start with 6, 7, 8 or 9" : "",
  pincode: (v) => (!v ? "Pincode is required" : !/^\d{6}$/.test(v) ? "Pincode must be exactly 6 digits" : ""),
  houseNo: (v) => (!v.trim() ? "House / flat number is required" : ""),
  area: (v) => (v.trim().length < 5 ? "Area / street must be at least 5 characters" : ""),
  landmark: (v) => (v.length > 60 ? "Landmark can be at most 60 characters" : ""),
  upiId: (v) => (!/^[\w.-]{2,}@[A-Za-z]{2,}$/.test(v.trim()) ? "Enter a valid UPI ID, for example priya@okaxis" : ""),
  instructions: (v) => (v.length > 120 ? "Keep instructions under 120 characters" : ""),
};

// Validate ALL fields at once. Returns { fieldName: message } only for invalid fields.
// `context` carries things that are not form values (cart total, pincode check result).
export function validateCheckout(values, context = {}) {
  const errors = {};
  for (const field of ["fullName", "phone", "pincode", "houseNo", "area", "landmark", "instructions"]) {
    const message = rules[field](values[field]);
    if (message) errors[field] = message;
  }
  // Cross-field and conditional rules
  if (!errors.pincode && context.pincodeStatus === "not-serviceable") {
    errors.pincode = "Sorry, we do not deliver to this pincode yet";
  }
  if (values.paymentMethod === "UPI" && rules.upiId(values.upiId)) errors.upiId = rules.upiId(values.upiId);
  if (values.paymentMethod === "COD" && context.total > COD_LIMIT) {
    errors.paymentMethod = `Cash on Delivery is available only up to ₹${COD_LIMIT}`;
  }
  if (!values.agree) errors.agree = "Please accept the terms to place the order";
  return errors;
}

// INPUT HANDLING: clean what the user types BEFORE it goes into state.
export const onlyDigits = (text, maxLength) => text.replace(/\D/g, "").slice(0, maxLength);
