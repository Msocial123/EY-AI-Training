// Random ids for request ids and idempotency keys.
// crypto.randomUUID() exists only on https:// or localhost, so we keep a fallback.
export function newId(prefix = "") {
  const random = globalThis.crypto?.randomUUID?.() ?? `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  return prefix + random;
}
