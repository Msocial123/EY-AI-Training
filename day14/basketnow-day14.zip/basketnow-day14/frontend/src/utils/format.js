// Small display helpers (from Day 13).

const rupees = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 });

export const formatPrice = (amount) => rupees.format(amount);

export const discountPercent = (price, mrp) => (mrp > price ? Math.round(((mrp - price) / mrp) * 100) : 0);

export const pluralize = (count, word) => `${count} ${word}${count === 1 ? "" : "s"}`;

export const formatTime = (epochSeconds) =>
  new Date(epochSeconds * 1000).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
