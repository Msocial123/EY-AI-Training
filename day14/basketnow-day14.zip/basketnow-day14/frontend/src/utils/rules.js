// The SAME business numbers as backend/api/config.py.
// The browser uses them only for a fast PREVIEW. The server always recalculates the real bill.
export const FREE_DELIVERY_ABOVE = 199;
export const DELIVERY_FEE = 25;
export const HANDLING_FEE = 4;
export const COD_LIMIT = 2000;
export const MAX_QTY_PER_ITEM = 5;

export const COUPONS = {
  WELCOME50: { type: "flat", value: 50, minCart: 299, text: "₹50 off on orders above ₹299" },
  SAVE10: { type: "percent", value: 10, maxOff: 75, minCart: 199, text: "10% off up to ₹75 above ₹199" },
  FRESH20: { type: "category", value: 20, maxOff: 60, category: "fruits-vegetables", minCart: 0, text: "20% off fruits & vegetables, up to ₹60" },
};

export const DELIVERY_SLOTS = [
  { value: "asap", label: "Express", hint: "15 minutes" },
  { value: "evening", label: "Today", hint: "6 PM - 8 PM" },
  { value: "morning", label: "Tomorrow", hint: "7 AM - 9 AM" },
];
