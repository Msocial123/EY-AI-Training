import { COUPONS, DELIVERY_FEE, FREE_DELIVERY_ABOVE, HANDLING_FEE } from "./rules";

// Pure function: same input -> same output, no state, no API. Easy to test and reuse.
export function couponDiscount(code, items, subtotal) {
  if (!code) return { discount: 0, error: null };
  const rule = COUPONS[code];
  if (!rule) return { discount: 0, error: "This coupon code does not exist" };
  if (subtotal < rule.minCart) return { discount: 0, error: `Add ₹${rule.minCart - subtotal} more to use ${code}` };

  let discount;
  if (rule.type === "flat") discount = rule.value;
  else if (rule.type === "percent") discount = Math.min(Math.round((subtotal * rule.value) / 100), rule.maxOff);
  else {
    const eligible = items.filter((i) => i.category === rule.category).reduce((sum, i) => sum + i.price * i.qty, 0);
    if (eligible === 0) return { discount: 0, error: "FRESH20 needs at least one fruit or vegetable" };
    discount = Math.min(Math.round((eligible * rule.value) / 100), rule.maxOff);
  }
  return { discount: Math.min(discount, subtotal), error: null };
}

export function estimateBill(items, couponCode) {
  const subtotal = items.reduce((sum, i) => sum + i.price * i.qty, 0);
  const mrpTotal = items.reduce((sum, i) => sum + i.mrp * i.qty, 0);
  const { discount, error } = couponDiscount(couponCode, items, subtotal);
  const afterDiscount = subtotal - discount;
  const deliveryFee = items.length === 0 || afterDiscount >= FREE_DELIVERY_ABOVE ? 0 : DELIVERY_FEE;
  return {
    itemCount: items.reduce((sum, i) => sum + i.qty, 0),
    mrpTotal,
    subtotal,
    productSavings: mrpTotal - subtotal,
    couponDiscount: discount,
    couponError: error,
    deliveryFee,
    handlingFee: items.length ? HANDLING_FEE : 0,
    total: items.length ? afterDiscount + deliveryFee + HANDLING_FEE : 0,
    toFreeDelivery: Math.max(0, FREE_DELIVERY_ABOVE - afterDiscount),
  };
}
