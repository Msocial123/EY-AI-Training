import { formatPrice } from "../utils/format";

export default function BillDetails({ bill, couponCode }) {
  const rows = [
    ["Items total (MRP)", formatPrice(bill.mrpTotal)],
    ["Product discount", `− ${formatPrice(bill.productSavings)}`],
    couponCode && bill.couponDiscount > 0 && [`Coupon ${couponCode}`, `− ${formatPrice(bill.couponDiscount)}`],
    ["Delivery fee", bill.deliveryFee ? formatPrice(bill.deliveryFee) : "FREE"],
    ["Handling fee", formatPrice(bill.handlingFee)],
  ].filter(Boolean);
  return (
    <div className="bill">
      <h3>Bill details</h3>
      {rows.map(([label, value]) => (
        <div key={label} className="bill-row"><span>{label}</span><span>{value}</span></div>
      ))}
      <div className="bill-row total"><span>To pay</span><span>{formatPrice(bill.total)}</span></div>
    </div>
  );
}
