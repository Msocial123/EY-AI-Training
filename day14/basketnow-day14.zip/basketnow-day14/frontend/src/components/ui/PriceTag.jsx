import { discountPercent, formatPrice } from "../../utils/format";

export default function PriceTag({ price, mrp, size = "md" }) {
  const off = discountPercent(price, mrp);
  return (
    <span className={`price price-${size}`}>
      <b>{formatPrice(price)}</b>
      {off > 0 && (
        <>
          <s>{formatPrice(mrp)}</s>
          <em>{off}% off</em>
        </>
      )}
    </span>
  );
}
