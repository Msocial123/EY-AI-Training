// Reusable button (Day 13) + a loading state for API calls (Day 14).
export default function Button({ variant = "primary", size = "md", loading = false, disabled = false, children, className = "", ...rest }) {
  return (
    <button className={`btn btn-${variant} btn-${size} ${className}`} disabled={loading || disabled} aria-busy={loading} {...rest}>
      {loading && <span className="spinner" aria-hidden="true" />}
      {children}
    </button>
  );
}
