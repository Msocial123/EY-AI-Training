import { friendlyMessage } from "../../services/ApiError";
import Button from "./Button";

// One component to show ANY API error with a Retry button.
export default function ErrorState({ error, onRetry, title = "Could not load this" }) {
  return (
    <div className="error-state" role="alert">
      <div className="empty-icon" aria-hidden="true">{error?.status === 404 ? "🔍" : "⚠️"}</div>
      <h3>{title}</h3>
      <p>{friendlyMessage(error)}</p>
      {error?.status ? <small>HTTP {error.status} · {error.code}</small> : <small>{error?.code}</small>}
      {onRetry && error?.isRetryable && <Button onClick={onRetry}>Try again</Button>}
    </div>
  );
}
