import { MAX_QTY_PER_ITEM } from "../../utils/rules";

export default function QuantityStepper({ qty, max, onChange }) {
  const limit = Math.min(max, MAX_QTY_PER_ITEM);
  return (
    <div className="stepper" role="group" aria-label="Quantity">
      <button type="button" onClick={() => onChange(qty - 1)} aria-label="Decrease">−</button>
      <span>{qty}</span>
      <button type="button" onClick={() => onChange(qty + 1)} disabled={qty >= limit} aria-label="Increase">+</button>
    </div>
  );
}
