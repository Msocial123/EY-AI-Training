// Skeleton placeholders: the page shows its SHAPE while data loads (feels faster than a spinner).
export function ProductGridSkeleton({ count = 8 }) {
  return (
    <div className="grid" aria-busy="true" aria-label="Loading products">
      {Array.from({ length: count }, (_, i) => (
        <div key={i} className="card skeleton">
          <div className="sk sk-img" />
          <div className="sk sk-line" />
          <div className="sk sk-line short" />
        </div>
      ))}
    </div>
  );
}

export function PageLoader({ text = "Loading..." }) {
  return (
    <div className="page-loader" role="status">
      <span className="spinner big" aria-hidden="true" /> {text}
    </div>
  );
}
