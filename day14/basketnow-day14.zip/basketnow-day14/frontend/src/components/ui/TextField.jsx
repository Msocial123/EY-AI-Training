// A CONTROLLED input with label, hint, error message and accessibility built in.
// Everything else (name, value, onChange, onBlur, type, maxLength...) is passed through with ...rest.
export default function TextField({ label, name, error, hint, multiline = false, optional = false, ...rest }) {
  const Input = multiline ? "textarea" : "input";
  const describedBy = error ? `${name}-error` : hint ? `${name}-hint` : undefined;
  return (
    <div className={`field ${error ? "field-invalid" : ""}`}>
      <label htmlFor={name}>
        {label} {optional && <small>(optional)</small>}
      </label>
      <Input id={name} name={name} aria-invalid={Boolean(error)} aria-describedby={describedBy} {...rest} />
      {error ? (
        <p className="field-error" id={`${name}-error`} role="alert">{error}</p>
      ) : (
        hint && <p className="field-hint" id={`${name}-hint`}>{hint}</p>
      )}
    </div>
  );
}
