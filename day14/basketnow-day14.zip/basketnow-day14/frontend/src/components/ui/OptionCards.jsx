// Radio buttons that look like cards (delivery slot, payment method).
export default function OptionCards({ legend, name, value, options, onChange, error }) {
  return (
    <fieldset className={`options ${error ? "field-invalid" : ""}`}>
      <legend>{legend}</legend>
      <div className="option-row">
        {options.map((option) => (
          <label key={option.value} className={`option ${value === option.value ? "selected" : ""} ${option.disabled ? "disabled" : ""}`}>
            <input
              type="radio"
              name={name}
              value={option.value}
              checked={value === option.value}
              disabled={option.disabled}
              onChange={onChange}
            />
            <b>{option.label}</b>
            {option.hint && <small>{option.hint}</small>}
          </label>
        ))}
      </div>
      {error && <p className="field-error" role="alert">{error}</p>}
    </fieldset>
  );
}
