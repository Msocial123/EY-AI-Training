import { useState } from "react";
import { Link } from "react-router-dom";
import { useCart } from "../context/CartContext";
import Badge from "./ui/Badge";
import Button from "./ui/Button";
import PriceTag from "./ui/PriceTag";
import QuantityStepper from "./ui/QuantityStepper";

export default function ProductCard({ product }) {
  const { qtyOf, addItem, setQty } = useCart();
  const firstInStock = product.variants.find((v) => v.stock > 0) ?? product.variants[0];
  const [variantId, setVariantId] = useState(firstInStock.id);
  const variant = product.variants.find((v) => v.id === variantId);
  const qty = qtyOf(variant.id);

  return (
    <article className="card">
      <Link to={`/product/${product.id}`} className="card-link">     {/* route parameter :productId */}
        <div className="card-img" aria-hidden="true">{product.image}</div>
        {product.tags.includes("bestseller") && <Badge tone="yellow">Bestseller</Badge>}
        <h3>{product.name}</h3>
      </Link>
      <small className="muted">{product.brand} · ★ {product.rating}</small>

      {product.variants.length > 1 ? (
        <select className="pack-select" value={variantId} onChange={(e) => setVariantId(e.target.value)} aria-label="Pack size">
          {product.variants.map((v) => (
            <option key={v.id} value={v.id} disabled={v.stock === 0}>{v.label}{v.stock === 0 ? " (sold out)" : ""}</option>
          ))}
        </select>
      ) : (
        <span className="pack-label">{variant.label}</span>
      )}

      <div className="card-foot">
        <PriceTag price={variant.price} mrp={variant.mrp} size="sm" />
        {variant.stock === 0 ? (
          <Badge tone="grey">Out of stock</Badge>
        ) : qty > 0 ? (
          <QuantityStepper qty={qty} max={variant.stock} onChange={(n) => setQty(variant.id, n)} />
        ) : (
          <Button size="sm" variant="outline" onClick={() => addItem(product, variant)}>ADD</Button>
        )}
      </div>
      {variant.stock > 0 && variant.stock <= 3 && <small className="low-stock">Only {variant.stock} left</small>}
    </article>
  );
}
