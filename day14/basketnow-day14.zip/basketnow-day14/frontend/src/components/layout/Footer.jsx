import { useDevTools } from "../../context/DevToolsContext";

// Developer tools for testing loading and error screens without breaking the real server.
export default function Footer() {
  const { simulateErrors, setSimulateErrors, slowNetwork, setSlowNetwork, servedBy } = useDevTools();
  return (
    <footer className="footer">
      <span>© BasketNow Technologies · React + Python</span>
      <div className="dev-tools">
        <span className="dev-label">Developer tools</span>
        <label className="toggle">
          <input type="checkbox" checked={simulateErrors} onChange={(e) => setSimulateErrors(e.target.checked)} />
          Simulate API errors
        </label>
        <label className="toggle">
          <input type="checkbox" checked={slowNetwork} onChange={(e) => setSlowNetwork(e.target.checked)} />
          Slow network (2 s)
        </label>
        <span className="served-by" title="X-Served-By header of the last API response">Served by: <b>{servedBy}</b></span>
      </div>
    </footer>
  );
}
