import { Outlet } from "react-router-dom";
import Footer from "./Footer";
import Header from "./Header";

// The frame shared by every page. <Outlet /> is where the current page is drawn.
export default function Layout() {
  return (
    <div className="app">
      <Header />
      <main className="main">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}
