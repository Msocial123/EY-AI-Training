import { useEffect, useState } from "react";
import { Link, NavLink, useNavigate, useSearchParams } from "react-router-dom";
import { useCart } from "../../context/CartContext";
import { formatPrice, pluralize } from "../../utils/format";

export default function Header() {
  const { count, bill } = useCart();                 // shared state from Context - no props needed
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [text, setText] = useState(searchParams.get("q") ?? "");

  // Keep the box in sync when the URL changes (Back button, "Clear search" link).
  useEffect(() => setText(searchParams.get("q") ?? ""), [searchParams]);

  function handleSearch(event) {
    event.preventDefault();
    const q = text.trim();
    navigate(q ? `/?q=${encodeURIComponent(q)}` : "/");    // the search lives in the URL = shareable
  }

  return (
    <header className="header">
      <div className="header-row">
        <Link to="/" className="logo" aria-label="BasketNow home">basket<span>now</span></Link>
        <div className="promise">
          <b>Delivery in 15 minutes</b>
          <small>Hyderabad · Kadapa · Nellore · Vizag</small>
        </div>
        <form className="search" role="search" onSubmit={handleSearch}>
          <span aria-hidden="true">🔍</span>
          <input type="search" placeholder='Search "milk", "rice", "chips"...' value={text}
                 onChange={(e) => setText(e.target.value)} aria-label="Search products" />
        </form>
        <Link to="/cart" className={count > 0 ? "cart-btn has-items" : "cart-btn"}>
          {count > 0 ? (<><b>{pluralize(count, "item")}</b><span>{formatPrice(bill.total)}</span></>) : <b>My Cart</b>}
        </Link>
      </div>
      <nav className="tabs" aria-label="Main">
        {/* NavLink adds the "active" class automatically when its URL matches */}
        <NavLink to="/" end className="tab">Shop</NavLink>
        <NavLink to="/orders" className="tab">My Orders</NavLink>
        <NavLink to="/lab" className="tab">Learning Lab</NavLink>
      </nav>
    </header>
  );
}
