import { ApiError } from "./ApiError";

// The SAME job as apiClient.js, but with the browser's built-in fetch().
// Read this side by side with apiClient.js in Module 5: fetch needs more code for the same safety.
export async function fetchJson(path, { method = "GET", body, timeoutMs = 8000, signal } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort("timeout"), timeoutMs);   // fetch has NO timeout option
  signal?.addEventListener("abort", () => controller.abort("cancelled"));

  let response;
  try {
    response = await fetch(`/api${path}`, {
      method,
      headers: { "Content-Type": "application/json" },
      body: body !== undefined ? JSON.stringify(body) : undefined,   // fetch does NOT stringify for you
      signal: controller.signal,
    });
  } catch (error) {
    // fetch only rejects when there is NO response (offline, DNS, CORS, abort)
    if (controller.signal.reason === "timeout") throw new ApiError({ code: "TIMEOUT", message: "The server took too long" });
    if (error.name === "AbortError") throw new ApiError({ code: "CANCELLED", message: "Request cancelled" });
    throw new ApiError({ code: "NETWORK_ERROR", message: "Cannot reach the server" });
  } finally {
    clearTimeout(timer);
  }

  // IMPORTANT: fetch does NOT throw for 404 or 500. We must check response.ok ourselves.
  const data = await response.json().catch(() => null);       // body may be empty or not JSON
  if (!response.ok) {
    const err = data?.error ?? {};
    throw new ApiError({ status: response.status, code: err.code, message: err.message ?? response.statusText, fields: err.fields });
  }
  return data;
}
