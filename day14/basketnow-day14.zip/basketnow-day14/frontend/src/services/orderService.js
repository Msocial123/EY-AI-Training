import { apiClient } from "./apiClient";

// Everything about orders, checkout and delivery in one place.
export const orderService = {
  async quote(cartItems, couponCode) {
    const { data } = await apiClient.post("/cart/quote", {
      items: cartItems.map(({ variantId, qty }) => ({ variantId, qty })),   // send ids + qty, NEVER prices
      couponCode: couponCode || undefined,
    });
    return data.bill;
  },

  async checkPincode(pincode, { signal } = {}) {
    const { data } = await apiClient.get(`/pincodes/${pincode}`, { signal });
    return data;                                      // { serviceable, city, etaMinutes }
  },

  async place(orderRequest, idempotencyKey) {
    const { data } = await apiClient.post("/orders", orderRequest, {
      headers: { "Idempotency-Key": idempotencyKey },   // same key = same order, even if sent twice
      timeout: 15000,
    });
    return data;
  },

  async getById(orderId, { signal } = {}) {
    const { data } = await apiClient.get(`/orders/${encodeURIComponent(orderId)}`, { signal });
    return data;
  },

  async list({ signal } = {}) {
    const { data } = await apiClient.get("/orders", { signal });
    return data;
  },

  async cancel(orderId) {
    const { data } = await apiClient.patch(`/orders/${encodeURIComponent(orderId)}/cancel`);
    return data;
  },
};
