import { apiClient } from "./apiClient";

// Reusable API functions for products. Components never write URLs or call axios directly:
//   const products = await productService.list({ category: "staples" });
// If the backend URL or response shape changes, we fix it HERE, not in 10 components.

export const productService = {
  async list({ category, q, sort, inStock, signal } = {}) {
    const { data } = await apiClient.get("/products", {
      params: { category, q, sort, inStock: inStock ? 1 : undefined },   // undefined params are skipped
      signal,
    });
    return data.items;                                // callers get a plain array
  },

  async getById(productId, { signal } = {}) {
    const { data } = await apiClient.get(`/products/${encodeURIComponent(productId)}`, { signal });
    return data;
  },

  async categories({ signal } = {}) {
    const { data } = await apiClient.get("/categories", { signal });
    return data;
  },
};
