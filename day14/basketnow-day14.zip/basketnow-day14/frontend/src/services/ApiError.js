// ONE error shape for the whole app, whatever went wrong (server said no, network down, timeout).
// Components only ever deal with: error.status, error.code, error.message, error.fields
export class ApiError extends Error {
  constructor({ status = 0, code = "UNKNOWN", message = "Something went wrong", fields = {}, details = null }) {
    super(message);
    this.name = "ApiError";
    this.status = status;   // 0 = no response at all (offline, server down, CORS, timeout)
    this.code = code;       // e.g. "VALIDATION_ERROR", "OUT_OF_STOCK", "NETWORK_ERROR"
    this.fields = fields;   // per-field messages for forms: { phone: "Enter a valid..." }
    this.details = details; // anything extra the server sent (e.g. which items are out of stock)
  }

  get isRetryable() {
    // Worth trying again: no response, timeout, or server temporarily busy.
    return this.status === 0 || this.status === 503 || this.status === 504;
  }
}

// Friendly text for each situation - never show "Request failed with status code 503" to a customer.
export function friendlyMessage(error) {
  if (!(error instanceof ApiError)) return "Something went wrong. Please try again.";
  if (error.code === "NETWORK_ERROR") return "You seem to be offline, or our server is down. Check your connection.";
  if (error.code === "TIMEOUT") return "This is taking too long. Please try again.";
  if (error.status === 503) return "BasketNow is very busy right now. Please try again in a moment.";
  return error.message;
}
