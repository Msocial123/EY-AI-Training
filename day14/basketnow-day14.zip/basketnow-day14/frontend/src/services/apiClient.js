import axios from "axios";
import { ApiError } from "./ApiError";
import { newId } from "../utils/id";

// ONE configured axios instance for the whole app.
// Every service file uses this, so base URL, timeout, headers and error handling live in ONE place.
export const apiClient = axios.create({
  baseURL: "/api",                    // Vite proxies /api to the Python server (see vite.config.js)
  timeout: 8000,                      // give up after 8 s instead of spinning forever
  headers: { "Content-Type": "application/json" },
});

// Developer tools (footer switches) - read by the request interceptor below.
export const devOptions = { simulateErrors: false, slowNetwork: false, onServedBy: null };

// REQUEST interceptor: runs before EVERY request leaves the browser.
apiClient.interceptors.request.use((config) => {
  config.headers["X-Request-Id"] = newId().slice(0, 8);   // helps find this call in server logs
  if (devOptions.simulateErrors) config.headers["X-Simulate-Error"] = "1";
  if (devOptions.slowNetwork) config.headers["X-Simulate-Delay"] = "2000";
  return config;
});

// RESPONSE interceptor: runs after EVERY response (success or failure).
apiClient.interceptors.response.use(
  (response) => {
    devOptions.onServedBy?.(response.headers["x-served-by"]);           // Module 9: which server answered
    return response;
  },
  (error) => Promise.reject(toApiError(error))                         // convert ALL errors to ApiError
);

export function toApiError(error) {
  if (axios.isCancel(error)) {
    return new ApiError({ code: "CANCELLED", message: "Request cancelled" });
  }
  if (error.response) {
    // The server answered with 4xx / 5xx. Our Flask API sends { error: { code, message, fields } }
    const body = error.response.data?.error ?? {};
    const { code, message, fields, ...details } = body;
    return new ApiError({
      status: error.response.status,
      code: code ?? `HTTP_${error.response.status}`,
      message: message ?? `Request failed (${error.response.status})`,
      fields: fields ?? {},
      details,
    });
  }
  if (error.code === "ECONNABORTED") {
    return new ApiError({ code: "TIMEOUT", message: "The server took too long to answer" });
  }
  return new ApiError({ code: "NETWORK_ERROR", message: "Cannot reach the server" });   // no response at all
}
