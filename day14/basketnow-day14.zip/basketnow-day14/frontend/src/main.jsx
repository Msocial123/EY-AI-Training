import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App";
import { CartProvider } from "./context/CartContext";
import { DevToolsProvider } from "./context/DevToolsContext";
import "./styles.css";

// Providers wrap the app so EVERY component below can use the router, the cart and dev tools.
createRoot(document.getElementById("root")).render(
  <StrictMode>
    <BrowserRouter>
      <DevToolsProvider>
        <CartProvider>
          <App />
        </CartProvider>
      </DevToolsProvider>
    </BrowserRouter>
  </StrictMode>
);
