import { Route, Routes } from "react-router-dom";
import Layout from "./components/layout/Layout";
import ControlledLab from "./labs/ControlledLab";
import FetchVsAxiosLab from "./labs/FetchVsAxiosLab";
import JsonLab from "./labs/JsonLab";
import LabLayout, { LabHome } from "./labs/LabLayout";
import SharedStateLab from "./labs/SharedStateLab";
import CartPage from "./pages/CartPage";
import CheckoutPage from "./pages/CheckoutPage";
import HomePage from "./pages/HomePage";
import NotFoundPage from "./pages/NotFoundPage";
import OrdersPage from "./pages/OrdersPage";
import OrderTrackingPage from "./pages/OrderTrackingPage";
import ProductPage from "./pages/ProductPage";

// The whole site map in one place. URL -> page.
export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>                                {/* header + footer around every page */}
        <Route path="/" element={<HomePage />} />
        <Route path="/category/:slug" element={<HomePage />} />  {/* :slug is a URL parameter */}
        <Route path="/product/:productId" element={<ProductPage />} />
        <Route path="/cart" element={<CartPage />} />
        <Route path="/checkout" element={<CheckoutPage />} />
        <Route path="/orders" element={<OrdersPage />} />
        <Route path="/orders/:orderId" element={<OrderTrackingPage />} />
        <Route path="/lab" element={<LabLayout />}>               {/* nested routes */}
          <Route index element={<LabHome />} />
          <Route path="shared-state" element={<SharedStateLab />} />
          <Route path="controlled" element={<ControlledLab />} />
          <Route path="fetch-vs-axios" element={<FetchVsAxiosLab />} />
          <Route path="json" element={<JsonLab />} />
        </Route>
        <Route path="*" element={<NotFoundPage />} />            {/* anything else */}
      </Route>
    </Routes>
  );
}
