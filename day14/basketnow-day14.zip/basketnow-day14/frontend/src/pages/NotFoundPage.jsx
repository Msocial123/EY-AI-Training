import { Link, useLocation } from "react-router-dom";
import EmptyState from "../components/ui/EmptyState";

// Route path="*" - any URL that no other route matched.
export default function NotFoundPage() {
  const { pathname } = useLocation();
  return (
    <EmptyState icon="🧭" title="Page not found" text={`Nothing lives at ${pathname}.`}>
      <Link to="/" className="btn btn-primary btn-md">Go to the shop</Link>
    </EmptyState>
  );
}
