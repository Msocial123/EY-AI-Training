import { Link, NavLink, useParams, useSearchParams } from "react-router-dom";
import ProductCard from "../components/ProductCard";
import EmptyState from "../components/ui/EmptyState";
import ErrorState from "../components/ui/ErrorState";
import { ProductGridSkeleton } from "../components/ui/Loader";
import { useApi } from "../hooks/useApi";
import { productService } from "../services/productService";

// Used for TWO routes:  /                 -> all products
//                       /category/:slug   -> one category
// The search text and sort order live in the URL (?q=milk&sort=price_asc) so a link can be shared.
export default function HomePage() {
  const { slug } = useParams();                              // undefined on "/"
  const [searchParams, setSearchParams] = useSearchParams();
  const q = searchParams.get("q") ?? "";
  const sort = searchParams.get("sort") ?? "relevance";
  const inStock = searchParams.get("inStock") === "1";

  const categories = useApi((signal) => productService.categories({ signal }), []);
  const products = useApi(
    (signal) => productService.list({ category: slug, q, sort, inStock, signal }),
    [slug, q, sort, inStock]                                 // refetch when any of these change
  );

  function updateParam(key, value) {
    const next = new URLSearchParams(searchParams);
    if (value) next.set(key, value);
    else next.delete(key);
    setSearchParams(next);
  }

  const current = categories.data?.find((c) => c.slug === slug);

  return (
    <section>
      <div className="chips" aria-label="Categories">
        <NavLink to="/" end className="chip">All</NavLink>
        {categories.data?.map((c) => (
          <NavLink key={c.slug} to={`/category/${c.slug}`} className="chip">
            {c.icon} {c.name} <small>({c.count})</small>
          </NavLink>
        ))}
      </div>

      <div className="toolbar">
        <h1>
          {current ? current.name : "All products"}
          {q && <> for “{q}” <Link to={slug ? `/category/${slug}` : "/"} className="link">Clear search</Link></>}
        </h1>
        <div className="toolbar-controls">
          <label className="toggle">
            <input type="checkbox" checked={inStock} onChange={(e) => updateParam("inStock", e.target.checked ? "1" : "")} />
            In stock only
          </label>
          <select value={sort} onChange={(e) => updateParam("sort", e.target.value === "relevance" ? "" : e.target.value)} aria-label="Sort">
            <option value="relevance">Relevance</option>
            <option value="price_asc">Price: Low to High</option>
            <option value="price_desc">Price: High to Low</option>
            <option value="rating">Customer rating</option>
          </select>
        </div>
      </div>

      {/* The three states of every API call: loading -> error OR data (which may be empty) */}
      {products.loading && !products.data ? (
        <ProductGridSkeleton />
      ) : products.error ? (
        <ErrorState error={products.error} onRetry={products.reload} title="Could not load products" />
      ) : products.data.length === 0 ? (
        <EmptyState icon="🔍" title="No products found" text="Try another word or clear the filters.">
          <Link to="/" className="btn btn-primary btn-md">Show all products</Link>
        </EmptyState>
      ) : (
        <>
          <p className="muted">{products.data.length} products{products.loading && " · updating..."}</p>
          <div className="grid">
            {products.data.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </>
      )}
    </section>
  );
}
