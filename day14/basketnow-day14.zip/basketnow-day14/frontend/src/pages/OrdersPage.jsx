import { Link } from "react-router-dom";
import Badge from "../components/ui/Badge";
import EmptyState from "../components/ui/EmptyState";
import ErrorState from "../components/ui/ErrorState";
import { PageLoader } from "../components/ui/Loader";
import { useApi } from "../hooks/useApi";
import { orderService } from "../services/orderService";
import { formatPrice, formatTime, pluralize } from "../utils/format";

const TONE = { DELIVERED: "green", CANCELLED: "grey" };

export default function OrdersPage() {
  const { data: orders, loading, error, reload } = useApi((signal) => orderService.list({ signal }), []);

  if (loading) return <PageLoader text="Loading your orders..." />;
  if (error) return <ErrorState error={error} onRetry={reload} title="Could not load your orders" />;
  if (orders.length === 0) {
    return (
      <EmptyState icon="📦" title="No orders yet" text="Your orders will appear here.">
        <Link to="/" className="btn btn-primary btn-md">Start shopping</Link>
      </EmptyState>
    );
  }
  return (
    <section className="panel">
      <div className="order-head">
        <h1>My Orders</h1>
        <button className="link" onClick={reload}>↻ Refresh</button>
      </div>
      <ul className="order-list">
        {orders.map((o) => (
          <li key={o.id}>
            <Link to={`/orders/${o.id}`} className="order-row">
              <span className="order-icons" aria-hidden="true">{o.items.slice(0, 3).map((i) => i.image).join(" ")}</span>
              <span><b>{o.id}</b><br /><small className="muted">{formatTime(o.createdAt)} · {pluralize(o.bill.itemCount, "item")}</small></span>
              <Badge tone={TONE[o.status] ?? "yellow"}>{o.statusLabel}</Badge>
              <b>{formatPrice(o.bill.total)}</b>
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}
