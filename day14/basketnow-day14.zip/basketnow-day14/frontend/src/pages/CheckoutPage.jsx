import { useEffect, useRef, useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import BillDetails from "../components/BillDetails";
import Button from "../components/ui/Button";
import OptionCards from "../components/ui/OptionCards";
import TextField from "../components/ui/TextField";
import { useCart } from "../context/CartContext";
import { useForm } from "../hooks/useForm";
import { friendlyMessage } from "../services/ApiError";
import { orderService } from "../services/orderService";
import { formatPrice } from "../utils/format";
import { newId } from "../utils/id";
import { COD_LIMIT, DELIVERY_SLOTS } from "../utils/rules";
import { onlyDigits, validateCheckout } from "../utils/validation";

const INITIAL_VALUES = {
  fullName: "", phone: "", pincode: "", houseNo: "", area: "", landmark: "",
  addressType: "Home", slot: "asap", paymentMethod: "UPI", upiId: "", instructions: "", agree: false,
};

export default function CheckoutPage() {
  const cart = useCart();
  const navigate = useNavigate();
  const [pincodeCheck, setPincodeCheck] = useState({ status: "idle", city: "" });
  const [banner, setBanner] = useState(null);                 // error message shown above the form
  const idempotencyKey = useRef(newId("checkout-"));          // SAME key for every retry of this checkout
  const bannerRef = useRef(null);

  const form = useForm({
    initialValues: INITIAL_VALUES,
    validate: (values) => validateCheckout(values, { pincodeStatus: pincodeCheck.status, total: cart.bill.total }),
    transform: { phone: (v) => onlyDigits(v, 10), pincode: (v) => onlyDigits(v, 6) },   // INPUT HANDLING
    onSubmit: placeOrder,
  });
  const { values } = form;

  // As soon as 6 digits are typed, ask the server if we deliver there.
  useEffect(() => {
    if (values.pincode.length !== 6) {
      setPincodeCheck({ status: "idle", city: "" });
      return undefined;
    }
    const controller = new AbortController();
    setPincodeCheck({ status: "checking", city: "" });
    orderService.checkPincode(values.pincode, { signal: controller.signal })
      .then((r) => setPincodeCheck({ status: r.serviceable ? "ok" : "not-serviceable", city: r.city ?? "" }))
      .catch((e) => e.code !== "CANCELLED" && setPincodeCheck({ status: "error", city: "" }));
    return () => controller.abort();                          // user typed again -> cancel the old check
  }, [values.pincode]);

  // When an error banner appears, scroll it into view - the user may be at the bottom of the form.
  useEffect(() => {
    if (banner) bannerRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
  }, [banner]);

  async function placeOrder(formValues, { setServerErrors }) {
    setBanner(null);
    const request = {
      items: cart.items.map(({ variantId, qty }) => ({ variantId, qty })),
      couponCode: cart.couponCode ?? undefined,
      customer: {
        fullName: formValues.fullName.trim(), phone: formValues.phone, pincode: formValues.pincode,
        houseNo: formValues.houseNo.trim(), area: formValues.area.trim(),
        landmark: formValues.landmark.trim(), addressType: formValues.addressType,
      },
      slot: formValues.slot,
      payment: { method: formValues.paymentMethod, upiId: formValues.paymentMethod === "UPI" ? formValues.upiId.trim() : undefined },
      instructions: formValues.instructions.trim(),
    };
    try {
      const order = await orderService.place(request, idempotencyKey.current);
      // replace: pressing Back must NOT come back to a filled checkout form
      navigate(`/orders/${order.id}`, { replace: true, state: { justPlaced: true } });
      cart.clearCart();
    } catch (error) {
      if (error.code === "VALIDATION_ERROR") {
        setServerErrors(error.fields);                         // show the server's messages next to fields
        setBanner(error.message);
      } else if (error.code === "OUT_OF_STOCK") {
        const names = error.details.items.map((p) => {
          const item = cart.items.find((i) => i.variantId === p.variantId);
          return `${item?.name ?? p.variantId} (only ${p.available} left)`;
        });
        setBanner(`Some items just sold out: ${names.join(", ")}. Please update your cart.`);
      } else {
        setBanner(friendlyMessage(error));                     // keep everything the user typed!
      }
    }
  }

  // Route guard: nothing to check out -> send the user to the cart page.
  if (cart.items.length === 0) return <Navigate to="/cart" replace />;

  const codDisabled = cart.bill.total > COD_LIMIT;
  const field = (name) => ({ name, value: values[name], onChange: form.handleChange, onBlur: form.handleBlur, error: form.errorFor(name) });

  return (
    <section className="two-col">
      <form ref={form.formRef} className="panel checkout-form" onSubmit={form.handleSubmit} noValidate>
        <h1>Delivery details</h1>
        {banner && <div ref={bannerRef} className="banner error" role="alert">{banner}</div>}

        <div className="row-2">
          <TextField label="Full name" autoComplete="name" placeholder="Priya Sharma" {...field("fullName")} />
          <TextField label="Mobile number" type="tel" inputMode="numeric" autoComplete="tel" placeholder="98765 43210"
                     hint="We will call this number if the rider can't find you" {...field("phone")} />
        </div>
        <div className="row-2">
          <TextField label="Pincode" inputMode="numeric" placeholder="500081" {...field("pincode")}
                     hint={{ checking: "Checking delivery...", ok: `✓ Delivering to ${pincodeCheck.city} in 15 minutes`,
                             error: "Could not check pincode right now" }[pincodeCheck.status]} />
          <TextField label="House / Flat no." placeholder="Flat 302, Lake View Apts" {...field("houseNo")} />
        </div>
        <TextField label="Area / Street" placeholder="Madhapur Main Road" {...field("area")} />
        <TextField label="Landmark" optional placeholder="Near Metro pillar 1520" maxLength={60} {...field("landmark")} />

        <OptionCards legend="Save address as" name="addressType" value={values.addressType} onChange={form.handleChange}
                     options={["Home", "Work", "Other"].map((v) => ({ value: v, label: v }))} />
        <OptionCards legend="Delivery slot" name="slot" value={values.slot} onChange={form.handleChange} options={DELIVERY_SLOTS} />
        <OptionCards legend="Payment" name="paymentMethod" value={values.paymentMethod} onChange={form.handleChange}
                     error={form.errorFor("paymentMethod")}
                     options={[
                       { value: "UPI", label: "UPI", hint: "GPay, PhonePe, Paytm" },
                       { value: "CARD", label: "Card", hint: "Pay on the next screen" },
                       { value: "COD", label: "Cash on Delivery", hint: codDisabled ? `Only up to ₹${COD_LIMIT}` : "Pay the rider", disabled: codDisabled },
                     ]} />

        {/* CONDITIONAL FIELD: shown and validated only when UPI is selected */}
        {values.paymentMethod === "UPI" && (
          <TextField label="UPI ID" placeholder="priya@okaxis" autoComplete="off" {...field("upiId")} />
        )}

        <TextField label="Instructions for the rider" optional multiline rows={2} maxLength={120}
                   placeholder="Please don't ring the bell, baby sleeping" {...field("instructions")}
                   hint={`${values.instructions.length}/120 characters`} />

        <label className={`check ${form.errorFor("agree") ? "field-invalid" : ""}`}>
          <input type="checkbox" name="agree" checked={values.agree} onChange={form.handleChange} onBlur={form.handleBlur} />
          I agree to the terms and the cancellation policy
        </label>
        {form.errorFor("agree") && <p className="field-error" role="alert">{form.errorFor("agree")}</p>}

        <Button type="submit" className="block" loading={form.submitting}>
          {form.submitting ? "Placing your order..." : `Place order · ${formatPrice(cart.bill.total)}`}
        </Button>
        {form.submitted && !form.isValid && <p className="field-error">Please fix the highlighted fields.</p>}
      </form>

      <aside className="panel">
        <h3>Order summary</h3>
        <ul className="summary-lines">
          {cart.items.map((i) => <li key={i.variantId}><span>{i.image} {i.name} × {i.qty}</span><span>{formatPrice(i.price * i.qty)}</span></li>)}
        </ul>
        <BillDetails bill={cart.bill} couponCode={cart.couponCode} />
        <p className="muted small">Prices are checked again by the server when you place the order.</p>
      </aside>
    </section>
  );
}
