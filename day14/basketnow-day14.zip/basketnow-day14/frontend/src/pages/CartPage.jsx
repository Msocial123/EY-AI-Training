import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import BillDetails from "../components/BillDetails";
import Button from "../components/ui/Button";
import EmptyState from "../components/ui/EmptyState";
import QuantityStepper from "../components/ui/QuantityStepper";
import { useCart } from "../context/CartContext";
import { friendlyMessage } from "../services/ApiError";
import { orderService } from "../services/orderService";
import { formatPrice } from "../utils/format";
import { COUPONS } from "../utils/rules";

export default function CartPage() {
  const cart = useCart();
  const navigate = useNavigate();

  if (cart.items.length === 0) {
    return (
      <EmptyState title="Your cart is empty" text="Add milk, fruits and more - delivered in 15 minutes.">
        <Link to="/" className="btn btn-primary btn-md">Start shopping</Link>
      </EmptyState>
    );
  }

  return (
    <section className="two-col">
      <div className="panel">
        <h1>My Cart</h1>
        {cart.bill.toFreeDelivery > 0 ? (
          <p className="notice">Add {formatPrice(cart.bill.toFreeDelivery)} more for FREE delivery</p>
        ) : (
          <p className="notice ok">🎉 You get FREE delivery</p>
        )}
        <ul className="cart-lines">
          {cart.items.map((item) => (
            <li key={item.variantId} className="cart-line">
              <span className="line-img" aria-hidden="true">{item.image}</span>
              <div>
                <Link to={`/product/${item.productId}`}><b>{item.name}</b></Link>
                <small className="muted"> {item.label}</small>
                <div>{formatPrice(item.price)} {item.mrp > item.price && <s className="muted">{formatPrice(item.mrp)}</s>}</div>
              </div>
              <QuantityStepper qty={item.qty} max={item.maxQty} onChange={(n) => cart.setQty(item.variantId, n)} />
              <b className="line-total">{formatPrice(item.price * item.qty)}</b>
            </li>
          ))}
        </ul>
      </div>
      <aside className="panel">
        <CouponBox />
        <BillDetails bill={cart.bill} couponCode={cart.couponCode} />
        <Button className="block" onClick={() => navigate("/checkout")}>Proceed to checkout · {formatPrice(cart.bill.total)}</Button>
      </aside>
    </section>
  );
}

// A small CONTROLLED form. The server decides if a coupon is valid (rules can change any time).
function CouponBox() {
  const { items, couponCode, applyCoupon, removeCoupon, bill } = useCart();
  const [code, setCode] = useState("");
  const [status, setStatus] = useState({ loading: false, error: "" });

  async function handleApply(event) {
    event.preventDefault();
    setStatus({ loading: true, error: "" });
    try {
      await orderService.quote(items, code);          // 200 = valid, 400 = invalid with a reason
      applyCoupon(code);
      setCode("");
      setStatus({ loading: false, error: "" });
    } catch (error) {
      setStatus({ loading: false, error: error.fields?.couponCode ?? friendlyMessage(error) });
    }
  }

  if (couponCode) {
    return (
      <div className="coupon applied">
        <span>🏷️ <b>{couponCode}</b> applied {bill.couponError ? <em className="field-error">({bill.couponError})</em> : `· you save ${formatPrice(bill.couponDiscount)}`}</span>
        <button className="link" onClick={removeCoupon}>Remove</button>
      </div>
    );
  }
  return (
    <form className="coupon" onSubmit={handleApply}>
      <div className="coupon-row">
        <input value={code} onChange={(e) => setCode(e.target.value.toUpperCase().replace(/\s/g, ""))}
               placeholder="Enter coupon code" aria-label="Coupon code" maxLength={12} />
        <Button type="submit" size="sm" variant="outline" loading={status.loading} disabled={code.length < 4}>Apply</Button>
      </div>
      {status.error && <p className="field-error" role="alert">{status.error}</p>}
      <div className="coupon-hints">
        {Object.entries(COUPONS).map(([c, rule]) => (
          <button type="button" key={c} className="chip small" onClick={() => setCode(c)} title={rule.text}>{c}</button>
        ))}
      </div>
    </form>
  );
}
