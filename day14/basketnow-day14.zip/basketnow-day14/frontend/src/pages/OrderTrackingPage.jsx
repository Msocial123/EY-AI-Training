import { useState } from "react";
import { Link, useLocation, useParams } from "react-router-dom";
import BillDetails from "../components/BillDetails";
import Badge from "../components/ui/Badge";
import Button from "../components/ui/Button";
import EmptyState from "../components/ui/EmptyState";
import ErrorState from "../components/ui/ErrorState";
import { PageLoader } from "../components/ui/Loader";
import { useApi } from "../hooks/useApi";
import { useOrderLive } from "../hooks/useOrderLive";
import { friendlyMessage } from "../services/ApiError";
import { orderService } from "../services/orderService";
import { formatTime } from "../utils/format";

const MODE_TEXT = {
  connecting: ["grey", "Connecting..."],
  live: ["green", "● Live (WebSocket)"],
  polling: ["yellow", "Updating every 5 s (REST polling)"],
  finished: ["grey", "Tracking finished"],
};

// Route: /orders/:orderId
export default function OrderTrackingPage() {
  const { orderId } = useParams();
  const location = useLocation();
  const justPlaced = location.state?.justPlaced;          // data passed by navigate() from checkout
  const loaded = useApi((signal) => orderService.getById(orderId, { signal }), [orderId]);
  const { order, mode, setOrder } = useOrderLive(orderId, loaded.data);
  const [confirming, setConfirming] = useState(false);
  const [cancel, setCancel] = useState({ loading: false, error: "" });

  if (loaded.loading) return <PageLoader text={`Loading order ${orderId}...`} />;
  if (loaded.error?.status === 404) {
    return (
      <EmptyState icon="📦" title="Order not found" text={`There is no order with id ${orderId}.`}>
        <Link to="/orders" className="btn btn-primary btn-md">See my orders</Link>
      </EmptyState>
    );
  }
  if (loaded.error) return <ErrorState error={loaded.error} onRetry={loaded.reload} />;
  if (!order) return null;

  async function handleCancel() {
    setCancel({ loading: true, error: "" });
    try {
      setOrder(await orderService.cancel(orderId));
      setConfirming(false);
      setCancel({ loading: false, error: "" });
    } catch (error) {
      setCancel({ loading: false, error: friendlyMessage(error) });   // e.g. 409: already out for delivery
    }
  }

  const [tone, text] = MODE_TEXT[mode];
  return (
    <section className="two-col">
      <div className="panel">
        {justPlaced && <div className="banner success">🎉 Order placed! Your groceries are on the way.</div>}
        <div className="order-head">
          <h1>Order {order.id}</h1>
          <Badge tone={tone}>{text}</Badge>
        </div>
        <p className="muted">Placed {formatTime(order.createdAt)} · {order.slot} · {order.city}</p>

        {order.status === "CANCELLED" ? (
          <div className="banner error">This order was cancelled. The amount will be refunded in 3-5 days.</div>
        ) : (
          <>
            <h2 className="status-now">{order.statusLabel}{order.etaMinutes > 0 && <small> · arriving in about {Math.ceil(order.etaMinutes)} min</small>}</h2>
            <ol className="steps">
              {order.steps.map((step) => (
                <li key={step.key} className={step.current ? "current" : step.done ? "done" : ""}>{step.label}</li>
              ))}
            </ol>
          </>
        )}

        {order.canCancel && (
          confirming ? (
            <div className="confirm-row">
              <span>Cancel this order?</span>
              <Button variant="danger" size="sm" loading={cancel.loading} onClick={handleCancel}>Yes, cancel</Button>
              <Button variant="ghost" size="sm" onClick={() => setConfirming(false)}>No</Button>
            </div>
          ) : (
            <Button variant="ghost" onClick={() => setConfirming(true)}>Cancel order</Button>
          )
        )}
        {cancel.error && <p className="field-error" role="alert">{cancel.error}</p>}
      </div>

      <aside className="panel">
        <h3>Items</h3>
        <ul className="summary-lines">
          {order.items.map((i) => <li key={i.variantId}><span>{i.image} {i.name} ({i.label}) × {i.qty}</span><span>₹{i.price * i.qty}</span></li>)}
        </ul>
        <BillDetails bill={order.bill} couponCode={order.bill.couponCode} />
        <h3>Deliver to</h3>
        <p>{order.customer.fullName} · {order.customer.phone}<br />{order.customer.houseNo}, {order.customer.area}, {order.city} {order.customer.pincode}</p>
        <p className="muted">Payment: {order.payment.method}</p>
      </aside>
    </section>
  );
}
