import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import Badge from "../components/ui/Badge";
import Button from "../components/ui/Button";
import EmptyState from "../components/ui/EmptyState";
import ErrorState from "../components/ui/ErrorState";
import { PageLoader } from "../components/ui/Loader";
import PriceTag from "../components/ui/PriceTag";
import QuantityStepper from "../components/ui/QuantityStepper";
import { useCart } from "../context/CartContext";
import { useApi } from "../hooks/useApi";
import { productService } from "../services/productService";

// Route: /product/:productId   e.g. /product/p201
export default function ProductPage() {
  const { productId } = useParams();                      // read the :productId part of the URL
  const navigate = useNavigate();
  const { qtyOf, addItem, setQty } = useCart();
  const { data: product, loading, error, reload } = useApi(
    (signal) => productService.getById(productId, { signal }), [productId]
  );
  const [chosenId, setChosenId] = useState(null);

  if (loading) return <PageLoader text="Loading product..." />;
  if (error?.status === 404) {
    return (
      <EmptyState icon="🔍" title="Product not found" text={`We could not find a product with id "${productId}".`}>
        <Link to="/" className="btn btn-primary btn-md">Back to shop</Link>
      </EmptyState>
    );
  }
  if (error) return <ErrorState error={error} onRetry={reload} />;

  const variant = product.variants.find((v) => v.id === chosenId)
    ?? product.variants.find((v) => v.stock > 0) ?? product.variants[0];
  const qty = qtyOf(variant.id);

  return (
    <section className="product-page">
      <nav className="breadcrumb" aria-label="Breadcrumb">
        <button className="link" onClick={() => navigate(-1)}>← Back</button>
        <Link to="/">Home</Link> / <Link to={`/category/${product.category}`}>{product.category.replace("-", " & ")}</Link> / <span>{product.name}</span>
      </nav>
      <div className="product-detail">
        <div className="product-hero" aria-hidden="true">{product.image}</div>
        <div>
          <small className="muted">{product.brand}</small>
          <h1>{product.name}</h1>
          <p>★ {product.rating} {product.tags.map((t) => <Badge key={t} tone="yellow">{t}</Badge>)}</p>
          <h4>Choose a pack size</h4>
          <div className="option-row">
            {product.variants.map((v) => (
              <button key={v.id} type="button" disabled={v.stock === 0} onClick={() => setChosenId(v.id)}
                      className={`option ${v.id === variant.id ? "selected" : ""} ${v.stock === 0 ? "disabled" : ""}`}>
                <b>{v.label}</b>
                <small>{v.stock === 0 ? "Sold out" : `₹${v.price}`}</small>
              </button>
            ))}
          </div>
          <div className="buy-row">
            <PriceTag price={variant.price} mrp={variant.mrp} size="lg" />
            {variant.stock === 0 ? <Badge tone="grey">Out of stock</Badge>
              : qty > 0 ? <QuantityStepper qty={qty} max={variant.stock} onChange={(n) => setQty(variant.id, n)} />
              : <Button onClick={() => addItem(product, variant)}>Add to cart</Button>}
          </div>
          {qty > 0 && <Button variant="secondary" onClick={() => navigate("/cart")}>Go to cart →</Button>}
          <p className="muted">{variant.stock} in stock at your nearest store · Free delivery above ₹199</p>
        </div>
      </div>
    </section>
  );
}
