import { NavLink, Outlet } from "react-router-dom";

// NESTED ROUTES: /lab is the parent, /lab/shared-state etc. are children drawn in <Outlet />.
export const LABS = [
  { path: "shared-state", title: "1. Prop drilling vs Context", module: "Module 1" },
  { path: "controlled", title: "2. Controlled vs uncontrolled inputs", module: "Module 2" },
  { path: "fetch-vs-axios", title: "3. fetch vs axios", module: "Module 5" },
  { path: "json", title: "4. JSON playground", module: "Module 5" },
];

export default function LabLayout() {
  return (
    <section className="lab">
      <aside className="lab-nav">
        <h3>Learning Lab</h3>
        {LABS.map((lab) => (
          <NavLink key={lab.path} to={lab.path} className="lab-link">
            {lab.title}<small>{lab.module}</small>
          </NavLink>
        ))}
      </aside>
      <div className="panel lab-body">
        <Outlet />
      </div>
    </section>
  );
}

export function LabHome() {
  return (
    <div>
      <h1>Learning Lab</h1>
      <p>Small, focused experiments for today's concepts. Each one is a single file in <code>src/labs/</code>.</p>
      <ul>{LABS.map((l) => <li key={l.path}><NavLink to={l.path}>{l.title}</NavLink> - {l.module}</li>)}</ul>
    </div>
  );
}
