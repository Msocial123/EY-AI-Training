import axios from "axios";
import { useState } from "react";

// LAB 3 - The same two calls with fetch and with axios. Watch how a 404 behaves.
export default function FetchVsAxiosLab() {
  const [log, setLog] = useState([]);
  const write = (line) => setLog((l) => [...l, line]);

  async function withFetch(id) {
    write(`fetch("/api/products/${id}")`);
    try {
      const response = await fetch(`/api/products/${id}`);
      write(`  -> no exception. response.ok = ${response.ok}, status = ${response.status}`);
      const data = await response.json();                      // step 2: read the body yourself
      write(response.ok ? `  -> name: ${data.name}` : `  -> error body: ${JSON.stringify(data.error)}`);
    } catch (error) {
      write(`  -> exception: ${error.message} (only for network problems)`);
    }
  }

  async function withAxios(id) {
    write(`axios.get("/api/products/${id}")`);
    try {
      const response = await axios.get(`/api/products/${id}`);
      write(`  -> status ${response.status}, response.data is already an object: ${response.data.name}`);
    } catch (error) {
      write(`  -> exception! error.response.status = ${error.response?.status}, code = ${error.response?.data?.error?.code}`);
    }
  }

  return (
    <div>
      <h1>fetch vs axios</h1>
      <div className="lab-buttons">
        <button className="btn btn-outline btn-sm" onClick={() => withFetch("p201")}>fetch p201</button>
        <button className="btn btn-outline btn-sm" onClick={() => withFetch("p999")}>fetch p999 (404)</button>
        <button className="btn btn-outline btn-sm" onClick={() => withAxios("p201")}>axios p201</button>
        <button className="btn btn-outline btn-sm" onClick={() => withAxios("p999")}>axios p999 (404)</button>
        <button className="btn btn-ghost btn-sm" onClick={() => setLog([])}>Clear</button>
      </div>
      <pre className="console">{log.join("\n") || "Click a button..."}</pre>
    </div>
  );
}
