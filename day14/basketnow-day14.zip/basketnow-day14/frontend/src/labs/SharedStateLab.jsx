import { createContext, useContext, useState } from "react";

// LAB 1 - The same feature built twice: "Delivering to <pincode>" shown deep inside a product card.
// Left: PROP DRILLING - every component in between must accept and pass the prop.
// Right: CONTEXT - only the component that needs the value reads it.

const LocationContext = createContext("500081");

export default function SharedStateLab() {
  const [pincode, setPincode] = useState("500081");
  return (
    <div>
      <h1>Prop drilling vs Context</h1>
      <label>Delivery pincode (state lives in the lab page):{" "}
        <select value={pincode} onChange={(e) => setPincode(e.target.value)}>
          <option>500081</option><option>516001</option><option>524001</option>
        </select>
      </label>
      <div className="row-2 lab-compare">
        <div className="lab-box">
          <h3>Prop drilling</h3>
          <PageA pincode={pincode} />
        </div>
        <div className="lab-box">
          <h3>Context</h3>
          <LocationContext.Provider value={pincode}>
            <PageB />
          </LocationContext.Provider>
        </div>
      </div>
    </div>
  );
}

// ---------- prop drilling: pincode passes through 3 components that do not use it ----------
const PageA = ({ pincode }) => <Box name="ProductPage" passes><GridA pincode={pincode} /></Box>;
const GridA = ({ pincode }) => <Box name="ProductGrid" passes><CardA pincode={pincode} /></Box>;
const CardA = ({ pincode }) => <Box name="ProductCard" passes><DeliveryBadgeA pincode={pincode} /></Box>;
const DeliveryBadgeA = ({ pincode }) => <Box name="DeliveryBadge" uses>🚚 Delivering to {pincode}</Box>;

// ---------- context: the middle components know nothing about pincode ----------
const PageB = () => <Box name="ProductPage"><GridB /></Box>;
const GridB = () => <Box name="ProductGrid"><CardB /></Box>;
const CardB = () => <Box name="ProductCard"><DeliveryBadgeB /></Box>;
function DeliveryBadgeB() {
  const pincode = useContext(LocationContext);        // read directly - no props
  return <Box name="DeliveryBadge" uses>🚚 Delivering to {pincode}</Box>;
}

function Box({ name, passes, uses, children }) {
  return (
    <div className={`tree-box ${passes ? "passes" : ""} ${uses ? "uses" : ""}`}>
      <small>{name}{passes && " - only passes pincode down"}{uses && " - uses pincode"}</small>
      {children}
    </div>
  );
}
