import { useRef, useState } from "react";

// LAB 2 - Two ways to read an input.
// CONTROLLED: React state is the single source of truth; we can react to EVERY keystroke.
// UNCONTROLLED: the DOM keeps the value; we read it once (on submit) with a ref.
export default function ControlledLab() {
  const [code, setCode] = useState("");
  const [controlledResult, setControlledResult] = useState("");
  const uncontrolledRef = useRef(null);
  const [uncontrolledResult, setUncontrolledResult] = useState("");

  return (
    <div>
      <h1>Controlled vs uncontrolled inputs</h1>
      <div className="row-2 lab-compare">
        <form className="lab-box" onSubmit={(e) => { e.preventDefault(); setControlledResult(`Applying ${code}`); }}>
          <h3>Controlled</h3>
          <input value={code} onChange={(e) => setCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ""))}
                 placeholder="coupon code" maxLength={10} />
          <p className="muted">Live: “{code}” · {code.length}/10 · {code.length >= 4 ? "✓ looks OK" : "type at least 4"}</p>
          <button className="btn btn-primary btn-sm" disabled={code.length < 4}>Apply</button>
          <p>{controlledResult}</p>
        </form>
        <form className="lab-box" onSubmit={(e) => { e.preventDefault(); setUncontrolledResult(`Applying ${uncontrolledRef.current.value}`); }}>
          <h3>Uncontrolled</h3>
          <input ref={uncontrolledRef} defaultValue="" placeholder="coupon code" />
          <p className="muted">React does not know the value until you press Apply.</p>
          <button className="btn btn-primary btn-sm">Apply</button>
          <p>{uncontrolledResult}</p>
        </form>
      </div>
      <p>Try typing <code>save 10!</code> in both. Only the controlled box can clean the text while you type.</p>
    </div>
  );
}
