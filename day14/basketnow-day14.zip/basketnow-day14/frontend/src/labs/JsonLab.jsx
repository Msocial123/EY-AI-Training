import { useState } from "react";
import { useCart } from "../context/CartContext";

// LAB 4 - Working with JSON: parse safely, read nested data, transform it, stringify it.
const SAMPLE = `{
  "id": "BN-1001",
  "items": [
    {"name": "Toned Milk", "category": "dairy-bakery", "price": 55, "qty": 2},
    {"name": "Fresh Tomato", "category": "fruits-vegetables", "price": 45, "qty": 1},
    {"name": "Fresh Paneer", "category": "dairy-bakery", "price": 89, "qty": 1}
  ],
  "customer": {"fullName": "Priya Sharma", "pincode": "500081"},
  "bill": {"total": 248, "couponCode": null}
}`;

export default function JsonLab() {
  const [text, setText] = useState(SAMPLE);
  const cart = useCart();

  let parsed = null;
  let parseError = "";
  try {
    parsed = JSON.parse(text);                              // text -> JavaScript object
  } catch (error) {
    parseError = error.message;                             // e.g. Unexpected token } in JSON
  }

  // Transform: group the items by category and total each group (what a "category summary" needs)
  const byCategory = parsed?.items?.reduce((groups, item) => {
    groups[item.category] = (groups[item.category] ?? 0) + item.price * item.qty;
    return groups;
  }, {});

  return (
    <div>
      <h1>JSON playground</h1>
      <div className="row-2">
        <div>
          <h3>API response (edit me - try deleting a comma)</h3>
          <textarea className="json-input" value={text} onChange={(e) => setText(e.target.value)} rows={14} spellCheck={false} />
        </div>
        <div>
          <h3>What JavaScript sees</h3>
          {parseError ? (
            <p className="field-error">JSON.parse failed: {parseError}</p>
          ) : (
            <ul>
              <li>Customer: <b>{parsed.customer?.fullName ?? "(missing)"}</b> - optional chaining <code>?.</code> avoids a crash</li>
              <li>Pincode as <code>{typeof parsed.customer?.pincode}</code>: {parsed.customer?.pincode} (keep pincodes as strings!)</li>
              <li>Item count: {parsed.items?.length ?? 0}</li>
              <li>Coupon: {parsed.bill?.couponCode ?? "none"} (<code>null</code> in JSON → <code>null</code> in JS)</li>
              <li>By category: <code>{JSON.stringify(byCategory)}</code></li>
            </ul>
          )}
          <h3>Your cart as JSON (from Context)</h3>
          <pre className="console small">{JSON.stringify({ items: cart.items.map(({ variantId, qty }) => ({ variantId, qty })), couponCode: cart.couponCode }, null, 2)}</pre>
        </div>
      </div>
    </div>
  );
}
