"""
MiniBroker - a tiny in-memory message broker for learning (no install, no Docker).

It copies the IDEAS of RabbitMQ / Azure Service Bus so you can see every pattern
on your laptop in one terminal:

  queue        a waiting line of messages; each message goes to ONE consumer
  exchange     a post office that decides which queues get a copy
               "direct" -> queue whose binding key == routing key
               "fanout" -> EVERY bound queue gets a copy
               "topic"  -> pattern match: "order.*" or "price.drop.#"
  ack          consumer says "done, delete it"  (handler returns normally)
  nack         consumer says "failed"            (handler raises) -> delivered again
  dead letter  after max_deliveries failures the message moves to a dead-letter queue

Do NOT use this in production - it loses everything when the program stops.
"""
import queue
import re
import threading
import time
import uuid
from dataclasses import dataclass, field

_START = time.time()


_PRINT_LOCK = threading.Lock()


def stamp():
    """Milliseconds since the program started - makes the order of events easy to read."""
    return f"[{(time.time() - _START) * 1000:6.0f} ms]"


def say(text):
    """print() from many threads at once can mix lines; a lock keeps each line whole."""
    with _PRINT_LOCK:
        print(f"{stamp()} {text}", flush=True)


@dataclass
class Message:
    body: dict
    routing_key: str = ""
    message_id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    correlation_id: str | None = None
    reply_to: str | None = None
    headers: dict = field(default_factory=dict)
    delivery_count: int = 0


class _Queue:
    def __init__(self, name, dead_letter_queue=None, max_deliveries=3):
        self.name = name
        self.items = queue.Queue()
        self.dead_letter_queue = dead_letter_queue
        self.max_deliveries = max_deliveries


class MiniBroker:
    def __init__(self):
        self.queues = {}
        self.exchanges = {}            # name -> {"type": ..., "bindings": [(queue, key)]}
        self._threads = []
        self._running = True
        self._consumed = set()                # queues that have workers
        self.stats = {"published": 0, "delivered": 0, "acked": 0, "failed": 0, "dead_lettered": 0}

    # ------------------------------------------------------------ topology
    def declare_queue(self, name, dead_letter_queue=None, max_deliveries=3):
        if dead_letter_queue and dead_letter_queue not in self.queues:
            self.queues[dead_letter_queue] = _Queue(dead_letter_queue)
        self.queues.setdefault(name, _Queue(name, dead_letter_queue, max_deliveries))

    def declare_exchange(self, name, exchange_type):
        assert exchange_type in ("direct", "fanout", "topic")
        self.exchanges.setdefault(name, {"type": exchange_type, "bindings": []})

    def bind(self, exchange, queue_name, binding_key=""):
        self.exchanges[exchange]["bindings"].append((queue_name, binding_key))

    @staticmethod
    def topic_matches(pattern, routing_key):
        """'*' = exactly one word, '#' = zero or more words. Words are separated by dots."""
        regex = re.escape(pattern).replace(r"\*", r"[^.]+").replace(r"\#", r".*")
        regex = regex.replace(r"\..*", r"(\..*)?")        # "price.#" also matches "price"
        return re.fullmatch(regex, routing_key) is not None

    # ------------------------------------------------------------ publishing
    def publish(self, exchange, routing_key, body, **props):
        """exchange="" means: put it straight into the queue called routing_key."""
        self.stats["published"] += 1
        if exchange == "":
            targets = [routing_key]
        else:
            ex = self.exchanges[exchange]
            if ex["type"] == "fanout":
                targets = [q for q, _ in ex["bindings"]]
            elif ex["type"] == "direct":
                targets = [q for q, key in ex["bindings"] if key == routing_key]
            else:
                targets = [q for q, key in ex["bindings"] if self.topic_matches(key, routing_key)]
        for name in dict.fromkeys(targets):              # unique, keep order
            # every queue gets its OWN copy of the message
            self.queues[name].items.put(Message(body=dict(body), routing_key=routing_key, **props))
        return targets

    def get(self, queue_name, timeout=None):
        """Pull one message (used by request-reply clients). Returns None on timeout."""
        items = self.queues[queue_name].items
        try:
            msg = items.get(timeout=timeout)
        except queue.Empty:
            return None
        items.task_done()
        return msg

    # ------------------------------------------------------------ consuming
    def consume(self, queue_name, handler, workers=1, name=None):
        """Start background worker(s). handler(message) -> return = ack, raise = nack."""
        q = self.queues[queue_name]
        self._consumed.add(queue_name)

        def loop(worker_name):
            while self._running:
                try:
                    msg = q.items.get(timeout=0.05)
                except queue.Empty:
                    continue
                msg.delivery_count += 1
                self.stats["delivered"] += 1
                try:
                    handler(msg, worker_name)
                    self.stats["acked"] += 1                         # ACK
                except Exception as error:                           # NACK
                    self.stats["failed"] += 1
                    if q.dead_letter_queue and msg.delivery_count >= q.max_deliveries:
                        msg.headers["dead_letter_reason"] = f"{type(error).__name__}: {error}"
                        msg.headers["failed_attempts"] = msg.delivery_count
                        self.queues[q.dead_letter_queue].items.put(msg)
                        self.stats["dead_lettered"] += 1
                        say(f"[broker] {msg.message_id} moved to {q.dead_letter_queue} "
                            f"after {msg.delivery_count} attempts")
                    else:
                        time.sleep(0.05 * msg.delivery_count)        # small back-off before retry
                        q.items.put(msg)                             # redeliver
                finally:
                    q.items.task_done()

        for i in range(workers):
            worker_name = name or queue_name
            if workers > 1:
                worker_name = f"{worker_name}#{i + 1}"
            t = threading.Thread(target=loop, args=(worker_name,), daemon=True)
            t.start()
            self._threads.append(t)

    def wait_until_idle(self, *queue_names, timeout=10):
        """Block until the given queues have no waiting or in-progress messages."""
        deadline = time.time() + timeout
        for name in queue_names or sorted(self._consumed):
            q = self.queues[name].items
            while q.unfinished_tasks and time.time() < deadline:
                time.sleep(0.02)

    def depth(self, queue_name):
        return self.queues[queue_name].items.qsize()

    def stop(self):
        self._running = False
        for t in self._threads:
            t.join(timeout=1)
