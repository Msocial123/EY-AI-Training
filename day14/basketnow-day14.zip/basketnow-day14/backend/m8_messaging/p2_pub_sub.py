"""
Pattern 2 - PUBLISH-SUBSCRIBE with a TOPIC exchange.

The publisher does not know who is listening. It only says WHAT happened
("order.placed", "price.drop.dairy"). Each service SUBSCRIBES to the topics it cares about:

   *  = exactly one word        order.*      -> order.placed, order.cancelled
   #  = zero or more words      price.drop.# -> price.drop.dairy, price.drop.fruits.apple
"""
from minibroker import MiniBroker, say

broker = MiniBroker()
broker.declare_exchange("basketnow.events", "topic")

SUBSCRIPTIONS = {
    # queue (one per service)       topics it listens to
    "notification-service": ["order.*", "payment.failed"],
    "inventory-service": ["order.placed", "order.cancelled"],
    "price-alert-service": ["price.drop.#"],
    "analytics-service": ["#"],                       # analytics wants EVERYTHING
}
for service, patterns in SUBSCRIPTIONS.items():
    broker.declare_queue(service)
    for pattern in patterns:
        broker.bind("basketnow.events", service, pattern)


def make_handler(service):
    def handle(msg, worker):
        say(f"  -> {service:<21} got {msg.routing_key:<18} {msg.body}")
    return handle


for service in SUBSCRIPTIONS:
    broker.consume(service, make_handler(service))

EVENTS = [
    ("order.placed", {"orderId": "BN-1001", "total": 214}),
    ("order.cancelled", {"orderId": "BN-0998"}),
    ("price.drop.dairy", {"variantId": "p202-200g", "newPrice": 79}),
    ("payment.failed", {"orderId": "BN-1002", "reason": "UPI timeout"}),
    ("store.opened", {"storeId": 42}),
]

if __name__ == "__main__":
    for routing_key, body in EVENTS:
        say(f"PUBLISH {routing_key}")
        targets = broker.publish("basketnow.events", routing_key, body)
        broker.wait_until_idle()
        say(f"        {routing_key} reached {len(targets)} queue(s)\n")
    broker.stop()
    print("\nNotice: the publisher code never changed when we added the price-alert service.")
