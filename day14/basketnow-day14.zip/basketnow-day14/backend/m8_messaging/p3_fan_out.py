"""
Pattern 3 - FAN-OUT (one event, EVERY subscriber gets a copy)
           vs COMPETING CONSUMERS (many workers share ONE queue, each job done once).

Story part A: one "order placed" must reach inventory, SMS, analytics and loyalty points.
Story part B: 9 invoices must be generated as PDFs; 3 workers share the work.
"""
import threading
import time
from collections import Counter

from minibroker import MiniBroker, say

broker = MiniBroker()

# ---------------- A. Fan-out ----------------
broker.declare_exchange("order.placed.fanout", "fanout")
SERVICES = ["inventory", "notification", "analytics", "loyalty"]
ACTIONS = {
    "inventory": lambda o: f"reserve {o['items']} items",
    "notification": lambda o: f"SMS 'Order {o['orderId']} confirmed'",
    "analytics": lambda o: f"add Rs. {o['total']} to today's sales",
    "loyalty": lambda o: f"give {o['total'] // 100} points",
}
for name in SERVICES:
    broker.declare_queue(f"{name}.q")
    broker.bind("order.placed.fanout", f"{name}.q")            # no key needed for fanout
    broker.consume(f"{name}.q", lambda msg, w, n=name: say(f"  {n:<13}: {ACTIONS[n](msg.body)}"))

print("A. FAN-OUT: publish ONE order.placed event")
targets = broker.publish("order.placed.fanout", "", {"orderId": "BN-1001", "total": 548, "items": 4})
say(f"broker made {len(targets)} copies -> {targets}")
broker.wait_until_idle()

# ---------------- B. Competing consumers (work queue) ----------------
print("\nB. COMPETING CONSUMERS: 9 invoice jobs, 3 workers on ONE queue")
broker.declare_queue("invoice.jobs")
done_by = Counter()
lock = threading.Lock()


def make_invoice(msg, worker):
    time.sleep(0.15)                                            # PDF generation takes time
    with lock:
        done_by[worker] += 1
    say(f"  {worker:<16} made invoice for {msg.body['orderId']}")


broker.consume("invoice.jobs", make_invoice, workers=3, name="invoice-worker")
start = time.time()
for n in range(1001, 1010):
    broker.publish("", "invoice.jobs", {"orderId": f"BN-{n}"})
broker.wait_until_idle("invoice.jobs")
broker.stop()

print(f"\nEach invoice was made exactly once. Jobs per worker: {dict(sorted(done_by.items()))}")
print(f"Time with 3 workers: {time.time() - start:.2f}s (one worker would need about {9 * 0.15:.2f}s)")
