"""
Look inside the dead-letter queue (inventory.orders.dlq).

    python dlq_inspect.py            -> show messages (they stay in the DLQ)
    python dlq_inspect.py --purge    -> show and remove them
"""
import sys

from common import connect, declare_topology

with connect() as connection:
    channel = connection.channel()
    declare_topology(channel)
    count, last_tag = 0, None
    while True:
        method, properties, body = channel.basic_get(queue="inventory.orders.dlq", auto_ack=False)
        if method is None:
            break
        count += 1
        death = (properties.headers or {}).get("x-death", [{}])[0]     # added by RabbitMQ
        print(f"#{count} body   : {body.decode(errors='replace')}")
        print(f"    from   : queue={death.get('queue')} reason={death.get('reason')} count={death.get('count')}")
        last_tag = method.delivery_tag
    if last_tag is not None:
        if "--purge" in sys.argv:
            channel.basic_ack(last_tag, multiple=True)                 # delete all we read
        else:
            channel.basic_nack(last_tag, multiple=True, requeue=True)  # put them all back
    print(f"{count} message(s) shown" if count else "Dead-letter queue is empty")
