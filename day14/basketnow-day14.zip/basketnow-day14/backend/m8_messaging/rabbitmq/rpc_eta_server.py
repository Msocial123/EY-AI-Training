"""
REQUEST-REPLY with RabbitMQ: the Delivery-ETA service.

    python rpc_eta_server.py        then in another terminal:   python rpc_eta_client.py 500081 3
"""
import json

import pika

from common import connect

STORE_LOAD = {"500081": 4, "516001": 9}

with connect() as connection:
    channel = connection.channel()
    channel.queue_declare(queue="eta.requests")

    def on_request(ch, method, props, body):
        request = json.loads(body)
        load = STORE_LOAD.get(request["pincode"])
        reply = ({"ok": True, "etaMinutes": 10 + load + request["items"]} if load is not None
                 else {"ok": False, "reason": "pincode not serviceable"})
        print(f"request {props.correlation_id}: {request} -> {reply}")
        ch.basic_publish(exchange="", routing_key=props.reply_to, body=json.dumps(reply),
                         properties=pika.BasicProperties(correlation_id=props.correlation_id))
        ch.basic_ack(delivery_tag=method.delivery_tag)

    channel.basic_qos(prefetch_count=1)
    channel.basic_consume(queue="eta.requests", on_message_callback=on_request)
    print("ETA service waiting for requests. Ctrl+C to stop.")
    try:
        channel.start_consuming()
    except KeyboardInterrupt:
        pass
