"""
A RabbitMQ consumer = one BasketNow microservice.

    python consumer.py inventory        (reads queue inventory.orders)
    python consumer.py notification     (reads queue notification.orders)

Open the same command in TWO terminals -> competing consumers: RabbitMQ shares the
messages between them (round robin), each message is handled once.
"""
import json
import sys
import time

from common import connect, declare_topology

SERVICE = sys.argv[1] if len(sys.argv) > 1 else "inventory"
QUEUE = f"{SERVICE}.orders"


def handle(event, routing_key):
    if SERVICE == "inventory":
        sign = "-" if routing_key == "order.placed" else "+"
        for item in event.get("items", []):
            print(f"   stock {item['variantId']} {sign}{item['qty']}")
        if routing_key == "order.cancelled":
            print(f"   restock everything from {event['orderId']}")
    else:
        print(f"   SMS to ******{event['phone'][-4:]}: your order {event['orderId']} is "
              f"{routing_key.split('.')[1]} (Rs. {event['total']})")


def on_message(channel, method, properties, body):
    print(f"[{SERVICE}] {method.routing_key} delivery_tag={method.delivery_tag}")
    try:
        event = json.loads(body)
        handle(event, method.routing_key)
        time.sleep(0.5)                                         # pretend work
        channel.basic_ack(delivery_tag=method.delivery_tag)     # done -> RabbitMQ deletes it
    except (json.JSONDecodeError, KeyError) as error:
        print(f"   cannot process ({error}) -> reject, send to dead-letter queue")
        channel.basic_nack(delivery_tag=method.delivery_tag, requeue=False)


with connect() as connection:
    channel = connection.channel()
    declare_topology(channel)
    channel.basic_qos(prefetch_count=1)          # give me ONE message at a time (fair sharing)
    channel.basic_consume(queue=QUEUE, on_message_callback=on_message)   # auto_ack is False
    print(f"[{SERVICE}] waiting for messages on '{QUEUE}'. Ctrl+C to stop.")
    try:
        channel.start_consuming()
    except KeyboardInterrupt:
        channel.stop_consuming()
