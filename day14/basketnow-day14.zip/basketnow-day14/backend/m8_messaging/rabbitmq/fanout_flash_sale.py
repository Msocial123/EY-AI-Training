"""
FAN-OUT with RabbitMQ: a flash-sale announcement must reach EVERY running app server
(each one clears its price cache). Every subscriber gets its own temporary queue.

Terminal 1 and 2:   python fanout_flash_sale.py listen app-server-1   (and app-server-2)
Terminal 3:         python fanout_flash_sale.py announce "Mango Drink 40% off for 15 minutes"
"""
import sys

from common import connect

EXCHANGE = "basketnow.flash-sales"
mode = sys.argv[1] if len(sys.argv) > 1 else "listen"

with connect() as connection:
    channel = connection.channel()
    channel.exchange_declare(exchange=EXCHANGE, exchange_type="fanout")

    if mode == "announce":
        text = sys.argv[2] if len(sys.argv) > 2 else "Flash sale started!"
        channel.basic_publish(exchange=EXCHANGE, routing_key="", body=text)
        print("announced:", text)
    else:
        name = sys.argv[2] if len(sys.argv) > 2 else "app-server"
        # queue name "" -> RabbitMQ creates a random name; exclusive -> deleted when we disconnect
        result = channel.queue_declare(queue="", exclusive=True)
        channel.queue_bind(exchange=EXCHANGE, queue=result.method.queue)
        print(f"[{name}] listening on temporary queue {result.method.queue}")

        def on_message(ch, method, props, body):
            print(f"[{name}] flash sale: {body.decode()} -> clearing my price cache")

        channel.basic_consume(queue=result.method.queue, on_message_callback=on_message, auto_ack=True)
        try:
            channel.start_consuming()
        except KeyboardInterrupt:
            pass
