"""
Shared RabbitMQ setup for BasketNow (pip install pika).

Topology (what exists inside RabbitMQ):

  exchange basketnow.events (topic) --order.placed / order.cancelled--> queue inventory.orders
                                    --order.*------------------------> queue notification.orders
  exchange basketnow.dlx (direct)   --inventory.orders---------------> queue inventory.orders.dlq

  inventory.orders has  x-dead-letter-exchange = basketnow.dlx
  -> a message that is REJECTED (nack, requeue=False) moves to inventory.orders.dlq automatically.
"""
import os

import pika

RABBITMQ_URL = os.getenv("RABBITMQ_URL", "amqp://guest:guest@localhost:5672/%2F")
EVENTS_EXCHANGE = "basketnow.events"
DLX = "basketnow.dlx"


def connect():
    return pika.BlockingConnection(pika.URLParameters(RABBITMQ_URL))


def declare_topology(channel):
    """Safe to call many times: declare = 'create if it does not exist'."""
    channel.exchange_declare(exchange=EVENTS_EXCHANGE, exchange_type="topic", durable=True)
    channel.exchange_declare(exchange=DLX, exchange_type="direct", durable=True)

    channel.queue_declare(queue="inventory.orders.dlq", durable=True)
    channel.queue_bind(queue="inventory.orders.dlq", exchange=DLX, routing_key="inventory.orders")

    channel.queue_declare(queue="inventory.orders", durable=True, arguments={
        "x-dead-letter-exchange": DLX,
        "x-dead-letter-routing-key": "inventory.orders",
    })
    for key in ("order.placed", "order.cancelled"):
        channel.queue_bind(queue="inventory.orders", exchange=EVENTS_EXCHANGE, routing_key=key)

    channel.queue_declare(queue="notification.orders", durable=True)
    channel.queue_bind(queue="notification.orders", exchange=EVENTS_EXCHANGE, routing_key="order.*")
