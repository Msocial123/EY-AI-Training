"""REQUEST-REPLY client:  python rpc_eta_client.py <pincode> <items>"""
import json
import sys
import time
import uuid

import pika

from common import connect

pincode = sys.argv[1] if len(sys.argv) > 1 else "500081"
items = int(sys.argv[2]) if len(sys.argv) > 2 else 3

with connect() as connection:
    channel = connection.channel()
    channel.queue_declare(queue="eta.requests")
    reply_queue = channel.queue_declare(queue="", exclusive=True).method.queue   # my private inbox
    correlation_id = str(uuid.uuid4())
    answer = {}

    def on_reply(ch, method, props, body):
        if props.correlation_id == correlation_id:
            answer["body"] = json.loads(body)

    channel.basic_consume(queue=reply_queue, on_message_callback=on_reply, auto_ack=True)
    channel.basic_publish(exchange="", routing_key="eta.requests",
                          body=json.dumps({"pincode": pincode, "items": items}),
                          properties=pika.BasicProperties(reply_to=reply_queue, correlation_id=correlation_id))
    print(f"asked ETA for {pincode} with {items} items ...")

    deadline = time.time() + 3                       # never wait forever
    while "body" not in answer and time.time() < deadline:
        connection.process_data_events(time_limit=0.2)
    print("answer:", answer.get("body", {"ok": False, "reason": "timeout, show default 30 min"}))
