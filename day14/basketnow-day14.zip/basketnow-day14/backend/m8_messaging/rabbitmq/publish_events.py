"""
Publish BasketNow events to RabbitMQ (topic exchange).

    python publish_events.py            -> 3 good events
    python publish_events.py --bad      -> also 1 broken message (goes to the DLQ)

The REST API can publish the same events for real orders:
    EVENT_BUS=rabbitmq python run_api.py         (from the backend/ folder)
"""
import json
import sys
import uuid

import pika

from common import EVENTS_EXCHANGE, connect, declare_topology

EVENTS = [
    ("order.placed", {"orderId": "BN-2001", "total": 214, "itemCount": 3, "phone": "9876543210",
                      "items": [{"variantId": "p201-1l", "qty": 2}, {"variantId": "p103-6pc", "qty": 1}]}),
    ("order.placed", {"orderId": "BN-2002", "total": 548, "itemCount": 2, "phone": "9123456780",
                      "items": [{"variantId": "p301-5kg", "qty": 1}, {"variantId": "p401-52g", "qty": 1}]}),
    ("order.cancelled", {"orderId": "BN-2001", "total": 214, "itemCount": 3, "phone": "9876543210"}),
]

with connect() as connection:
    channel = connection.channel()
    declare_topology(channel)
    channel.confirm_delivery()          # broker confirms every publish (no silent message loss)

    for routing_key, event in EVENTS:
        channel.basic_publish(
            exchange=EVENTS_EXCHANGE,
            routing_key=routing_key,
            body=json.dumps(event),
            properties=pika.BasicProperties(content_type="application/json", delivery_mode=2,
                                            message_id=str(uuid.uuid4())),
        )
        print(f"sent {routing_key:<16} {event['orderId']}")

    if "--bad" in sys.argv:
        channel.basic_publish(exchange=EVENTS_EXCHANGE, routing_key="order.placed",
                              body="{orderId: BN-2003, total: oops",          # not valid JSON
                              properties=pika.BasicProperties(delivery_mode=2))
        print("sent order.placed     <broken JSON>  (should end up in inventory.orders.dlq)")
