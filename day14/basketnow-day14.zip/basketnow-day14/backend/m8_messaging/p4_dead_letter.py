"""
Pattern 4 - RETRIES and the DEAD-LETTER QUEUE (DLQ).

Story: the payment gateway (Razorpay / PayU style) calls BasketNow with "payment captured"
webhooks. Our payment-service updates the order. Three kinds of trouble happen in real life:

  1. TEMPORARY failure  - our database is busy for a moment -> a retry fixes it
  2. POISON message     - the body is broken / unknown order -> retrying will NEVER fix it
  3. DUPLICATE message  - gateways send the same webhook twice -> must not credit twice

A poison message must not block the queue forever, so after 3 attempts it goes to
the DLQ, where a human (or a script) inspects it and replays it after a fix.
"""
from minibroker import MiniBroker, say

broker = MiniBroker()
broker.declare_queue("payment.webhooks", dead_letter_queue="payment.webhooks.dlq", max_deliveries=3)

KNOWN_ORDERS = {"BN-1001", "BN-1002", "BN-1003", "BN-1004"}
processed_payment_ids = set()          # remembers what we already handled (idempotency)
db_busy_once = {"BN-1002"}             # the DB will be busy the first time we touch BN-1002


class TemporaryError(Exception):
    pass


class PoisonMessageError(Exception):
    pass


def handle_webhook(msg, worker):
    body = msg.body
    pay_id = body.get("paymentId")
    say(f"[payment-service] attempt {msg.delivery_count} for {pay_id} ({body.get('orderId')})")

    if pay_id in processed_payment_ids:                          # 3. duplicate -> ack and ignore
        say(f"   duplicate {pay_id} ignored (already processed)")
        return
    if body.get("orderId") not in KNOWN_ORDERS or body.get("amount", 0) <= 0:
        raise PoisonMessageError(f"unknown order or bad amount in {body}")   # 2. poison
    if body["orderId"] in db_busy_once:
        db_busy_once.discard(body["orderId"])
        raise TemporaryError("database busy, try again")                    # 1. temporary

    processed_payment_ids.add(pay_id)
    say(f"   order {body['orderId']} marked PAID (Rs. {body['amount']})")


WEBHOOKS = [
    {"paymentId": "pay_A1", "orderId": "BN-1001", "amount": 214},
    {"paymentId": "pay_B2", "orderId": "BN-1002", "amount": 548},     # temporary failure first
    {"paymentId": "pay_X9", "orderId": "BN-10O4", "amount": 120},     # poison: letter O instead of zero
    {"paymentId": "pay_A1", "orderId": "BN-1001", "amount": 214},     # duplicate of the first one
    {"paymentId": "pay_C3", "orderId": "BN-1003", "amount": 99},
]

if __name__ == "__main__":
    broker.consume("payment.webhooks", handle_webhook, name="payment-service")
    for hook in WEBHOOKS:
        broker.publish("", "payment.webhooks", hook)
    broker.wait_until_idle("payment.webhooks")

    print(f"\nQueue 'payment.webhooks' now has {broker.depth('payment.webhooks')} messages.")
    print(f"Dead-letter queue has {broker.depth('payment.webhooks.dlq')} message(s):")
    dead = broker.get("payment.webhooks.dlq", timeout=0.1)
    print(f"  body   : {dead.body}")
    print(f"  reason : {dead.headers['dead_letter_reason']}")
    print(f"  tries  : {dead.headers['failed_attempts']}")

    print("\nSupport team finds the typo (letter O instead of zero): BN-10O4 -> BN-1004. Fix and REPLAY:")
    fixed = {**dead.body, "orderId": "BN-1004"}
    broker.publish("", "payment.webhooks", fixed)
    broker.wait_until_idle("payment.webhooks")
    broker.stop()
    print(f"\nStats: {broker.stats}")
