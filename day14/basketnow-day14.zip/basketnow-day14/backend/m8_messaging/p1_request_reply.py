"""
Pattern 1 - REQUEST-REPLY over a queue (also called RPC over messaging).

Story: at checkout, the Checkout API asks the Delivery-ETA service
"how many minutes to deliver 3 items to pincode 500081?" and WAITS for the answer.

How the reply finds its way back:
  reply_to       = the queue where the caller is listening ("replies.checkout-api")
  correlation_id = a unique id, so the caller can match the reply to ITS question
Always use a TIMEOUT: if the ETA service is down, show a safe default instead of hanging.
"""
import time
import uuid

from minibroker import MiniBroker, say

broker = MiniBroker()
broker.declare_queue("eta.requests")
broker.declare_queue("replies.checkout-api")

STORE_LOAD = {"500081": 4, "516001": 9}          # pending orders at the nearest dark store


# ---------------- the Delivery-ETA service (the "server" side) ----------------
def eta_service(msg, worker):
    pincode, items = msg.body["pincode"], msg.body["items"]
    say(f"[{worker}] got request {msg.correlation_id}: pincode={pincode}, items={items}")
    time.sleep(0.1)                                           # pretend to calculate
    if pincode in STORE_LOAD:
        reply = {"ok": True, "etaMinutes": 10 + STORE_LOAD[pincode] + items}
    else:
        reply = {"ok": False, "reason": "pincode not serviceable"}
    broker.publish("", msg.reply_to, reply, correlation_id=msg.correlation_id)


# ---------------- the Checkout API (the "client" side) ----------------
def ask_eta(pincode, items, timeout=1.0):
    correlation_id = uuid.uuid4().hex[:6]
    broker.publish("", "eta.requests", {"pincode": pincode, "items": items},
                   reply_to="replies.checkout-api", correlation_id=correlation_id)
    say(f"[checkout-api] asked ETA for {pincode} (correlation_id={correlation_id})")

    deadline = time.time() + timeout
    while time.time() < deadline:
        reply = broker.get("replies.checkout-api", timeout=deadline - time.time())
        if reply is None:
            break
        if reply.correlation_id == correlation_id:            # is this the answer to MY question?
            return reply.body
        say(f"[checkout-api] ignoring a reply for someone else")
    return {"ok": False, "reason": "timeout - using default ETA of 30 minutes", "etaMinutes": 30}


if __name__ == "__main__":
    print("--- 1. ETA service is running ---")
    broker.consume("eta.requests", eta_service, name="eta-service")
    say(f"[checkout-api] answer: {ask_eta('500081', 3)}\n")
    say(f"[checkout-api] answer: {ask_eta('110001', 1)}\n")

    print("--- 2. ETA service crashes (we stop all consumers) ---")
    broker.stop()
    say(f"[checkout-api] answer: {ask_eta('516001', 2, timeout=0.5)}")
    print("\nCheckout still works - it showed a safe default instead of hanging forever.")
