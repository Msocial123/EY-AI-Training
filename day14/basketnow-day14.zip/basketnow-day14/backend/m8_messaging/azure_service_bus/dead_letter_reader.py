"""
Read the DEAD-LETTER sub-queue of "orders" ("orders/$deadletterqueue").

    python dead_letter_reader.py             -> show and remove
"""
from azure.servicebus import ServiceBusClient, ServiceBusSubQueue

from asb_common import CONNECTION_STRING, QUEUE_NAME

with ServiceBusClient.from_connection_string(CONNECTION_STRING) as client:
    with client.get_queue_receiver(queue_name=QUEUE_NAME, sub_queue=ServiceBusSubQueue.DEAD_LETTER,
                                   max_wait_time=5) as receiver:
        count = 0
        for msg in receiver:
            count += 1
            print(f"#{count} id={msg.message_id} body={str(msg)!r}")
            print(f"    reason={msg.dead_letter_reason} description={msg.dead_letter_error_description}")
            receiver.complete_message(msg)        # remove it from the DLQ after reading
        print(f"{count} dead-lettered message(s)")
