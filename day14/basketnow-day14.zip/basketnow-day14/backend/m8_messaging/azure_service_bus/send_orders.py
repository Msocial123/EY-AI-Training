"""
Send order messages to the Azure Service Bus QUEUE "orders".

    python send_orders.py            -> 3 good orders
    python send_orders.py --bad      -> plus one broken message (for the dead-letter demo)
"""
import json
import sys

from azure.servicebus import ServiceBusClient, ServiceBusMessage

from asb_common import CONNECTION_STRING, QUEUE_NAME

ORDERS = [
    {"orderId": "BN-3001", "total": 214, "city": "Hyderabad"},
    {"orderId": "BN-3002", "total": 1850, "city": "Kadapa"},
    {"orderId": "BN-3003", "total": 99, "city": "Nellore"},
]

with ServiceBusClient.from_connection_string(CONNECTION_STRING) as client:
    with client.get_queue_sender(queue_name=QUEUE_NAME) as sender:
        batch = sender.create_message_batch()            # one network call for many messages
        count = 0
        for order in ORDERS:
            batch.add_message(ServiceBusMessage(
                json.dumps(order),
                message_id=order["orderId"],              # duplicate detection uses this
                subject="order.placed",
                content_type="application/json",
                application_properties={"city": order["city"], "total": order["total"]},
            ))
            count += 1
        if "--bad" in sys.argv:
            batch.add_message(ServiceBusMessage("{broken json", message_id="BN-BAD", subject="order.placed"))
            count += 1
        sender.send_messages(batch)
        print(f"sent {count} message(s) to queue '{QUEUE_NAME}'")
