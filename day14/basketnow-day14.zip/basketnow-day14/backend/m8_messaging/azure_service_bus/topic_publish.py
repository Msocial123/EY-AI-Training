"""
PUBLISH-SUBSCRIBE in Azure Service Bus = a TOPIC with SUBSCRIPTIONS.
Every subscription gets its own copy (like a fan-out). A subscription can have a FILTER
(example in README: analytics only wants orders with total > 1000).

    python topic_publish.py
"""
import json

from azure.servicebus import ServiceBusClient, ServiceBusMessage

from asb_common import CONNECTION_STRING, TOPIC_NAME

EVENTS = [
    ("order.placed", {"orderId": "BN-3101", "total": 340}),
    ("order.placed", {"orderId": "BN-3102", "total": 2400}),
    ("order.cancelled", {"orderId": "BN-3101", "total": 340}),
]

with ServiceBusClient.from_connection_string(CONNECTION_STRING) as client:
    with client.get_topic_sender(topic_name=TOPIC_NAME) as sender:
        for subject, event in EVENTS:
            sender.send_messages(ServiceBusMessage(
                json.dumps(event), subject=subject,
                application_properties={"total": event["total"], "eventType": subject},
            ))
            print(f"published {subject:<16} {event}")
