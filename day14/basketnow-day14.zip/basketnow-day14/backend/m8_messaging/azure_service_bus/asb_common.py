"""
Azure Service Bus settings (pip install azure-servicebus python-dotenv).

Put your connection string in backend/.env (NEVER commit it):
    SERVICEBUS_CONNECTION_STRING=Endpoint=sb://<namespace>.servicebus.windows.net/;SharedAccessKeyName=...;SharedAccessKey=...
Names used by the scripts (create them in the Azure portal, see README.md):
    queue  "orders"
    topic  "order-events"  with subscriptions "notification" and "analytics"
"""
import os
import sys
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[2] / ".env")       # backend/.env

CONNECTION_STRING = os.getenv("SERVICEBUS_CONNECTION_STRING")
QUEUE_NAME = os.getenv("SERVICEBUS_QUEUE", "orders")
TOPIC_NAME = os.getenv("SERVICEBUS_TOPIC", "order-events")

if not CONNECTION_STRING:
    sys.exit("SERVICEBUS_CONNECTION_STRING is missing. Copy backend/.env.example to backend/.env and fill it in.")
