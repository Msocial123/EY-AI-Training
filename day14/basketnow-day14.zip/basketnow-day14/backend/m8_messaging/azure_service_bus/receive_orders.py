"""
Receive from the "orders" queue with PEEK-LOCK (the default and the safe mode):

  receive  -> the message is LOCKED (hidden from other receivers), not deleted
  complete -> done, delete it                  (like RabbitMQ ack)
  abandon  -> unlock it, try again later       (temporary problem; delivery_count goes up)
  dead_letter -> move to the dead-letter sub-queue with a reason (poison message)

After MaxDeliveryCount abandons (10 by default) Service Bus dead-letters it automatically.
"""
import json

from azure.servicebus import ServiceBusClient

from asb_common import CONNECTION_STRING, QUEUE_NAME

with ServiceBusClient.from_connection_string(CONNECTION_STRING) as client:
    with client.get_queue_receiver(queue_name=QUEUE_NAME, max_wait_time=5) as receiver:
        print(f"listening on '{QUEUE_NAME}' (stops after 5 s with no messages)")
        for msg in receiver:                               # iterates until max_wait_time passes
            print(f"\nmessage_id={msg.message_id} subject={msg.subject} delivery_count={msg.delivery_count}")
            try:
                order = json.loads(str(msg))
            except json.JSONDecodeError as error:
                receiver.dead_letter_message(msg, reason="InvalidJson", error_description=str(error))
                print("   broken JSON -> dead-lettered")
                continue

            if order["total"] > 1500 and msg.delivery_count < 2:
                # pretend the fraud-check service timed out the first time
                receiver.abandon_message(msg)
                print("   fraud check timed out -> abandoned, will come back")
                continue

            print(f"   processing {order['orderId']} for Rs. {order['total']} ({order['city']})")
            receiver.complete_message(msg)
            print("   completed")
