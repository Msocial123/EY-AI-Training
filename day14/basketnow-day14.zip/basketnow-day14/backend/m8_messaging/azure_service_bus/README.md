# Azure Service Bus - BasketNow examples

## One-time setup in the Azure portal (10 minutes)

1. Create a resource -> **Service Bus** -> pricing tier **Standard** (topics need Standard or Premium).
2. In the namespace: **Queues** -> **+ Queue** -> name `orders` (keep Max delivery count = 10).
3. **Topics** -> **+ Topic** -> name `order-events`.
   Inside it: **+ Subscription** `notification`, and **+ Subscription** `analytics`.
4. Optional filter: open subscription `analytics` -> **Filters** -> replace the default rule with
   SQL filter `total > 1000` (only big orders reach analytics).
5. Namespace -> **Shared access policies** -> `RootManageSharedAccessKey` -> copy the
   **Primary Connection String** into `backend/.env`:

```
SERVICEBUS_CONNECTION_STRING=Endpoint=sb://....servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=...
```

In company projects you would use Managed Identity / `DefaultAzureCredential` instead of a key.

## Run

```
python send_orders.py --bad
python receive_orders.py
python dead_letter_reader.py
python topic_publish.py
python topic_subscribe.py notification
python topic_subscribe.py analytics
```

## RabbitMQ word -> Azure Service Bus word

| RabbitMQ | Azure Service Bus |
|---|---|
| queue | queue |
| topic / fanout exchange + bound queues | topic + subscriptions |
| binding key / pattern | subscription filter (SQL or correlation) |
| ack | complete_message |
| nack requeue=True | abandon_message |
| nack requeue=False + DLX | dead_letter_message / automatic after MaxDeliveryCount |
| dead-letter queue | `<queue>/$deadletterqueue` sub-queue |
