"""
Read one subscription of the topic.

    python topic_subscribe.py notification
    python topic_subscribe.py analytics
"""
import json
import sys

from azure.servicebus import ServiceBusClient

from asb_common import CONNECTION_STRING, TOPIC_NAME

subscription = sys.argv[1] if len(sys.argv) > 1 else "notification"

with ServiceBusClient.from_connection_string(CONNECTION_STRING) as client:
    with client.get_subscription_receiver(topic_name=TOPIC_NAME, subscription_name=subscription,
                                          max_wait_time=5) as receiver:
        print(f"[{subscription}] reading '{TOPIC_NAME}' ...")
        for msg in receiver:
            print(f"[{subscription}] {msg.subject}: {json.loads(str(msg))}")
            receiver.complete_message(msg)
        print(f"[{subscription}] no more messages")
