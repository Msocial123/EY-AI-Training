"""
Module 7.4 - WebSocket client (what the BasketNow app does, but in a terminal).

    python m7_protocols/ws_client.py BN-1001
"""
import asyncio
import json
import sys

from websockets.asyncio.client import connect
from websockets.exceptions import ConnectionClosed


async def follow(order_id):
    url = f"ws://localhost:8765/orders/{order_id}"
    print(f"Connecting to {url} ...")
    try:
        async with connect(url) as websocket:
            async for raw in websocket:                 # waits for the server to push
                message = json.loads(raw)
                if message["type"] == "order":
                    o = message["order"]
                    print(f"  {o['status']:<17} {o['statusLabel']:<20} ETA {o['etaMinutes']} min")
                else:
                    print("  server says:", message["message"])
        print("Connection closed normally - tracking finished.")
    except ConnectionClosed as e:
        print(f"Connection closed: code={e.rcvd.code if e.rcvd else '-'} reason={e.rcvd.reason if e.rcvd else '-'}")
    except OSError:
        print("Could not connect. Is ws_server.py running?")


if __name__ == "__main__":
    asyncio.run(follow(sys.argv[1] if len(sys.argv) > 1 else "BN-1001"))
