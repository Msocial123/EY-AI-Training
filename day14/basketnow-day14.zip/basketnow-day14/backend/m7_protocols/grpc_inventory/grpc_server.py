"""
Module 7.5 - gRPC inventory service (service-to-service, fast, typed).

Needs:  pip install grpcio grpcio-tools
Generate code from the contract (once, inside this folder):
    python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. inventory.proto
Run:
    python grpc_server.py
"""
import sys
import time
from concurrent import futures
from pathlib import Path

import grpc

import inventory_pb2           # generated: the messages
import inventory_pb2_grpc      # generated: the service base class and stub

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))   # the backend/ folder
from api import db  # noqa: E402  (same SQLite stock as the REST API)


class InventoryService(inventory_pb2_grpc.InventoryServicer):

    def CheckStock(self, request, context):
        stock = db.get_stock_map()
        if request.variant_id not in stock:
            context.abort(grpc.StatusCode.NOT_FOUND, f"Unknown variant {request.variant_id}")
        qty = stock[request.variant_id]
        print(f"CheckStock({request.variant_id}) -> {qty}")
        return inventory_pb2.StockReply(variant_id=request.variant_id, available=qty, in_stock=qty > 0)

    def WatchStock(self, request, context):
        print(f"WatchStock started for {list(request.variant_ids)}")
        last = {}
        while context.is_active():                       # until the client disconnects / times out
            stock = db.get_stock_map()
            for vid in request.variant_ids:
                qty = stock.get(vid, 0)
                if last.get(vid) != qty:
                    reason = "current stock" if vid not in last else "stock changed"
                    last[vid] = qty
                    yield inventory_pb2.StockUpdate(variant_id=vid, available=qty, reason=reason)
            time.sleep(1)
        print("WatchStock finished")


def serve():
    db.init_db()
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    inventory_pb2_grpc.add_InventoryServicer_to_server(InventoryService(), server)
    server.add_insecure_port("[::]:50051")
    server.start()
    print("gRPC Inventory service on localhost:50051  (Ctrl+C to stop)")
    server.wait_for_termination()


if __name__ == "__main__":
    try:
        serve()
    except KeyboardInterrupt:
        print("\nstopped")
