"""
Module 7.5 - gRPC client: how the order service would ask the inventory service.

    python grpc_client.py
While the "watch" part runs, place an order in the React app or with rest_client.py
and watch the stock change arrive here.
"""
import grpc

import inventory_pb2
import inventory_pb2_grpc

with grpc.insecure_channel("localhost:50051") as channel:
    stub = inventory_pb2_grpc.InventoryStub(channel)

    # 1. Unary call - feels like calling a local function
    reply = stub.CheckStock(inventory_pb2.StockRequest(variant_id="p201-1l"), timeout=2)
    print(f"Toned Milk 1 L: available={reply.available} in_stock={reply.in_stock}")

    # 2. Errors come back as status codes (like HTTP status codes)
    try:
        stub.CheckStock(inventory_pb2.StockRequest(variant_id="p999"), timeout=2)
    except grpc.RpcError as e:
        print(f"Error: {e.code().name} - {e.details()}")

    # 3. Server streaming - updates arrive as they happen, for 20 seconds
    print("Watching stock for 20 seconds...")
    request = inventory_pb2.WatchRequest(variant_ids=["p201-1l", "p403-100g"])
    try:
        for update in stub.WatchStock(request, timeout=20):
            print(f"  {update.variant_id:<10} available={update.available:<3} ({update.reason})")
    except grpc.RpcError as e:
        if e.code() == grpc.StatusCode.DEADLINE_EXCEEDED:
            print("Done watching (20 s deadline reached).")
        else:
            raise
