"""
Module 7.2 - Why gRPC is faster: text (JSON) vs binary (Protocol Buffers idea).

No install needed. We encode the same stock update in two ways and compare sizes.
(Real gRPC uses Protocol Buffers, which works like the binary version below:
 field numbers + compact numbers instead of repeating key names as text.)
"""
import json
import struct

update = {"variantId": "p201-1l", "storeId": 42, "available": 28, "reserved": 2, "price": 55.0}

# 1. JSON: human readable, every message repeats every key name as text
json_bytes = json.dumps(update).encode("utf-8")

# 2. Binary: both sides already know the field order from a shared contract (.proto file)
#    format: 1-byte text length + text, then int32, int32, int32, float32
vid = update["variantId"].encode()
binary_bytes = struct.pack(f"<B{len(vid)}siiif", len(vid), vid, update["storeId"],
                           update["available"], update["reserved"], update["price"])

print("JSON   :", json_bytes.decode())
print("Binary :", binary_bytes.hex(" "))
print(f"\nJSON size   : {len(json_bytes):>3} bytes")
print(f"Binary size : {len(binary_bytes):>3} bytes  ({len(binary_bytes) / len(json_bytes):.0%} of JSON)")

# What it means at scale: 2,000 dark stores send a stock update every second
per_day = 2000 * 60 * 60 * 24
print(f"\nPer day with {per_day:,} updates:")
print(f"  JSON   : {len(json_bytes) * per_day / 1e9:.1f} GB")
print(f"  Binary : {len(binary_bytes) * per_day / 1e9:.1f} GB")

# Decoding the binary needs the contract - without it the bytes mean nothing
size = binary_bytes[0]
text, store, avail, reserved, price = struct.unpack(f"<{size}siiif", binary_bytes[1:])
print("\nDecoded binary back:", text.decode(), store, avail, reserved, price)
