"""
Module 7.1 - Calling the BasketNow REST API from Python (another service, a script, a test).

Start the API first (other terminal):  python run_api.py --reset
Then:                                  python m7_protocols/rest_client.py
"""
import time
import uuid

import requests

BASE_URL = "http://localhost:8000/api"
TIMEOUT = 5          # seconds - ALWAYS set a timeout, or one slow server freezes your program


def show(title, res):
    print(f"\n=== {title} ===")
    print(f"{res.request.method} {res.url.replace(BASE_URL, '/api')} -> HTTP {res.status_code} "
          f"(served by {res.headers.get('X-Served-By')})")


def get_with_retry(url, retries=3, **kwargs):
    """Retry only TEMPORARY problems (503 / network), with a growing wait (backoff)."""
    for attempt in range(1, retries + 1):
        try:
            res = requests.get(url, timeout=TIMEOUT, **kwargs)
            if res.status_code != 503:
                return res
            print(f"  attempt {attempt}: 503 busy")
        except requests.ConnectionError:
            print(f"  attempt {attempt}: cannot connect")
        if attempt < retries:
            print(f"  waiting {attempt * 0.5}s before the next try")
            time.sleep(attempt * 0.5)
    raise RuntimeError(f"Gave up after {retries} attempts: {url}")


if __name__ == "__main__":
    # 1. GET a collection with query parameters
    res = requests.get(f"{BASE_URL}/products", params={"category": "dairy-bakery", "sort": "price_asc"},
                       timeout=TIMEOUT)
    show("GET products in Dairy & Bakery, cheapest first", res)
    for p in res.json()["items"]:
        cheapest = min(v["price"] for v in p["variants"])
        print(f"  {p['id']}  {p['name']:<18} from Rs. {cheapest}")

    # 2. GET one resource that does not exist -> 404 with our error JSON
    res = requests.get(f"{BASE_URL}/products/p999", timeout=TIMEOUT)
    show("GET unknown product", res)
    print("  error:", res.json()["error"])

    # 3. POST with a JSON body -> 201 Created
    order = {
        "items": [{"variantId": "p201-1l", "qty": 2}, {"variantId": "p103-6pc", "qty": 1}],
        "customer": {"fullName": "Ravi Kumar", "phone": "9123456780", "pincode": "516001",
                     "houseNo": "12-3-45", "area": "RS Road, Kadapa", "addressType": "Home"},
        "slot": "asap", "payment": {"method": "COD"},
    }
    res = requests.post(f"{BASE_URL}/orders", json=order, timeout=TIMEOUT,
                        headers={"Idempotency-Key": str(uuid.uuid4())})
    show("POST a new order", res)
    created = res.json()
    print(f"  order {created['id']} | status {created['status']} | total Rs. {created['bill']['total']}")

    # 4. POST bad data -> 400 with an error per field
    order["customer"]["phone"] = "98765"
    res = requests.post(f"{BASE_URL}/orders", json=order, timeout=TIMEOUT)
    show("POST with a wrong phone number", res)
    print("  fields:", res.json()["error"]["fields"])

    # 5. Retry a temporarily failing call (we ask the server to fail on purpose)
    print("\n=== GET with retry while the server is 'busy' ===")
    try:
        get_with_retry(f"{BASE_URL}/products", headers={"X-Simulate-Error": "1"})
    except RuntimeError as e:
        print(" ", e)
