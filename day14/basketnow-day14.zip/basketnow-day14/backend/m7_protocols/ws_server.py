"""
Module 7.4 - WebSocket server: live order tracking for BasketNow.

The browser opens ONE connection:  ws://localhost:8765/orders/BN-1001
and the server PUSHES a message every time the order status changes.

Needs:  pip install websockets   (version 13 or newer)
Start the REST API first (python run_api.py), then:  python m7_protocols/ws_server.py

Note: to keep the demo small, this server asks the REST API for the status once a second.
In a real company it would listen to "order.status_changed" events from a message queue
(Module 8) instead - no polling anywhere.
"""
import asyncio
import json
import logging
import os
import urllib.error
import urllib.request

from websockets.asyncio.server import serve
from websockets.exceptions import ConnectionClosed

API_URL = os.getenv("API_URL", "http://localhost:8000/api")   # Module 9: http://localhost:8080/api
HOST, PORT = "localhost", 8765
FINAL_STATUSES = {"DELIVERED", "CANCELLED"}

logging.basicConfig(level=logging.INFO, format="%(asctime)s [ws] %(message)s", datefmt="%H:%M:%S")
log = logging.getLogger()
open_connections = set()


def fetch_order(order_id):
    """Normal blocking HTTP call. Returns the order dict, or None for 404."""
    try:
        with urllib.request.urlopen(f"{API_URL}/orders/{order_id}", timeout=3) as res:
            return json.loads(res.read())
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        raise


async def track_order(websocket, order_id):
    last_status = None
    while True:
        # run the blocking HTTP call in a thread so other customers are not blocked
        order = await asyncio.to_thread(fetch_order, order_id)
        if order is None:
            await websocket.send(json.dumps({"type": "error", "message": f"Order {order_id} not found"}))
            await websocket.close(code=4404, reason="order not found")
            return
        if order["status"] != last_status:
            last_status = order["status"]
            await websocket.send(json.dumps({"type": "order", "order": order}))     # PUSH
            log.info("pushed %s -> %s to %d client(s) online", order_id, last_status, len(open_connections))
        if last_status in FINAL_STATUSES:
            await websocket.close(code=1000, reason="tracking finished")
            return
        await asyncio.sleep(1)


async def handler(websocket):
    path = websocket.request.path                       # e.g. "/orders/BN-1001"
    parts = path.strip("/").split("/")
    if len(parts) != 2 or parts[0] != "orders":
        await websocket.close(code=4400, reason="use /orders/<orderId>")
        return

    open_connections.add(websocket)
    log.info("customer connected for %s (%d online)", parts[1], len(open_connections))
    try:
        await track_order(websocket, parts[1])
    except ConnectionClosed:
        log.info("customer closed the page for %s", parts[1])
    except urllib.error.URLError:
        await websocket.send(json.dumps({"type": "error", "message": "Order service is not reachable"}))
        await websocket.close(code=1011, reason="upstream down")
    finally:
        open_connections.discard(websocket)


async def main():
    async with serve(handler, HOST, PORT):
        log.info("WebSocket server on ws://%s:%d/orders/<orderId>  (Ctrl+C to stop)", HOST, PORT)
        await asyncio.get_running_loop().create_future()      # run forever


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nWebSocket server stopped")
