"""
Module 7.3 - Order tracking: REST polling vs WebSocket push (a simulation, no install needed).

A real 15-minute order: PLACED -> CONFIRMED -> PACKED -> OUT_FOR_DELIVERY -> DELIVERED.
How many messages does each approach need, and how late does the customer see each change?
"""
# (second when it happened, status)
STATUS_CHANGES = [(0, "PLACED"), (37, "CONFIRMED"), (262, "PACKED"), (411, "OUT_FOR_DELIVERY"), (893, "DELIVERED")]


def status_at(second):
    current = "PLACED"
    for at, status in STATUS_CHANGES:
        if second >= at:
            current = status
    return current


def polling(every_seconds):
    requests_sent, useful, delays, last_seen, second = 0, 0, [], None, 0
    while last_seen != "DELIVERED":
        requests_sent += 1                     # the app asks: "any change?"
        status = status_at(second)
        if status != last_seen:
            useful += 1
            changed_at = max(at for at, s in STATUS_CHANGES if s == status)
            delays.append(second - changed_at)
            last_seen = status
        second += every_seconds
    return requests_sent, useful, max(delays)


print(f"{'Approach':<28}{'Messages':>10}{'Useful':>8}{'Wasted':>8}{'Worst delay':>13}")
for every in (3, 10, 60):
    sent, useful, worst = polling(every)
    print(f"{'REST polling every ' + str(every) + 's':<28}{sent:>10}{useful:>8}{sent - useful:>8}{worst:>12}s")

# WebSocket push: one connection, the SERVER sends a message only when something changes
pushed = len(STATUS_CHANGES)
print(f"{'WebSocket push':<28}{pushed:>10}{pushed:>8}{0:>8}{0:>12}s")

print("\nNow multiply by 50,000 customers tracking orders at dinner time:")
sent, _, _ = polling(3)
print(f"  polling every 3s : {sent * 50_000:,} HTTP requests")
print(f"  WebSocket push   : {pushed * 50_000:,} small messages over open connections")
