"""
Start the BasketNow API.

    python run_api.py                         -> http://localhost:8000  (name api-1)
    python run_api.py --port 8001 --name api-1  (Module 9: three copies behind a load balancer)
    python run_api.py --reset                 -> fresh stock, no orders
    python run_api.py --port 8001 --name api-1 --one-worker   (a small server: one request at a time)
"""
import argparse
import logging

from api import db
from api.app import create_app

parser = argparse.ArgumentParser(description="BasketNow REST API")
parser.add_argument("--port", type=int, default=8000)
parser.add_argument("--name", default="api-1", help="instance name shown in the X-Served-By header")
parser.add_argument("--reset", action="store_true", help="delete all orders and reload stock")
parser.add_argument("--one-worker", action="store_true",
                    help="handle one request at a time (like a small, busy server) - used in Module 9")
args = parser.parse_args()

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)-5s [%(name)s] %(message)s",
                    datefmt="%H:%M:%S")
logging.getLogger("werkzeug").setLevel(logging.WARNING)     # hide Flask's own access log; we log ourselves

if args.reset:
    db.init_db(reset=True)
    print("Database reset: stock reloaded from products.json, orders deleted.")

app = create_app(args.name)
print(f"BasketNow API '{args.name}' running on http://localhost:{args.port}  (Ctrl+C to stop)")
app.run(host="0.0.0.0", port=args.port, debug=False, threaded=not args.one_worker)
