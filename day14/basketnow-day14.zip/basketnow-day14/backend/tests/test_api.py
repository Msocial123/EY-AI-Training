"""Automated tests for the BasketNow API. Run:  python -m pytest -v"""
import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


@pytest.fixture
def client(tmp_path, monkeypatch):
    # Each test gets its own fresh database file.
    monkeypatch.setattr("api.config.DB_FILE", tmp_path / "test.db")
    monkeypatch.setattr("api.db.DB_FILE", tmp_path / "test.db")
    from api.app import create_app
    app = create_app("test")
    return app.test_client()


GOOD_ORDER = {
    "items": [{"variantId": "p201-1l", "qty": 2}, {"variantId": "p101-1kg", "qty": 1}],
    "customer": {"fullName": "Priya Sharma", "phone": "9876543210", "pincode": "500081",
                 "houseNo": "Flat 302", "area": "Madhapur Main Road", "addressType": "Home"},
    "slot": "asap",
    "payment": {"method": "UPI", "upiId": "priya@okaxis"},
}


def test_health(client):
    assert client.get("/api/health").get_json()["status"] == "UP"


def test_products_filter_by_category(client):
    data = client.get("/api/products?category=staples").get_json()
    assert data["total"] == 4


def test_unknown_product_is_404(client):
    res = client.get("/api/products/p999")
    assert res.status_code == 404
    assert res.get_json()["error"]["code"] == "PRODUCT_NOT_FOUND"


def test_pincode_check(client):
    assert client.get("/api/pincodes/500081").get_json()["city"] == "Hyderabad"
    assert client.get("/api/pincodes/110001").get_json()["serviceable"] is False
    assert client.get("/api/pincodes/12ab").status_code == 400


def test_quote_uses_server_prices(client):
    res = client.post("/api/cart/quote", json={"items": [{"variantId": "p201-1l", "qty": 2, "price": 1}]})
    assert res.get_json()["bill"]["subtotal"] == 110          # 2 x 55, the fake price 1 is ignored


def test_invalid_coupon_is_400(client):
    res = client.post("/api/cart/quote", json={"items": [{"variantId": "p201-1l", "qty": 1}], "couponCode": "SAVE10"})
    assert res.status_code == 400
    assert "more to use SAVE10" in res.get_json()["error"]["fields"]["couponCode"]


def test_place_order_201_and_stock_reduces(client):
    res = client.post("/api/orders", json=GOOD_ORDER)
    assert res.status_code == 201
    order = res.get_json()
    assert order["id"] == "BN-1001" and order["status"] == "PLACED"
    product = client.get("/api/products/p201").get_json()
    assert product["variants"][1]["stock"] == 28


def test_validation_errors_per_field(client):
    bad = {**GOOD_ORDER, "customer": {**GOOD_ORDER["customer"], "phone": "12345", "pincode": "110001"}}
    res = client.post("/api/orders", json=bad)
    assert res.status_code == 400
    fields = res.get_json()["error"]["fields"]
    assert set(fields) == {"phone", "pincode"}


def test_out_of_stock_is_409(client):
    order = {**GOOD_ORDER, "items": [{"variantId": "p403-100g", "qty": 3}]}   # only 2 chocolates
    res = client.post("/api/orders", json=order)
    assert res.status_code == 409
    assert res.get_json()["error"]["items"][0]["available"] == 2


def test_idempotency_key_prevents_duplicate_orders(client):
    headers = {"Idempotency-Key": "checkout-abc-123"}
    first = client.post("/api/orders", json=GOOD_ORDER, headers=headers)
    second = client.post("/api/orders", json=GOOD_ORDER, headers=headers)
    assert first.status_code == 201 and second.status_code == 200
    assert first.get_json()["id"] == second.get_json()["id"]
    assert len(client.get("/api/orders").get_json()) == 1


def test_cancel_then_cannot_cancel_again(client):
    order_id = client.post("/api/orders", json=GOOD_ORDER).get_json()["id"]
    assert client.patch(f"/api/orders/{order_id}/cancel").get_json()["status"] == "CANCELLED"
    assert client.patch(f"/api/orders/{order_id}/cancel").status_code == 409


def test_simulated_error_header(client):
    res = client.get("/api/products", headers={"X-Simulate-Error": "1"})
    assert res.status_code == 503
