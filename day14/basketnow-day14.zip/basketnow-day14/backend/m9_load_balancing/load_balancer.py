"""
Module 9.2 - A real (small) HTTP load balancer in pure Python.

Start three copies of the BasketNow API (three terminals, from backend/):
    python run_api.py --port 8001 --name api-1
    python run_api.py --port 8002 --name api-2
    python run_api.py --port 8003 --name api-3
Then start the load balancer:
    python m9_load_balancing/load_balancer.py --strategy round_robin
    python m9_load_balancing/load_balancer.py --strategy least_connections

Clients now call ONLY http://localhost:8080 - they never know how many servers exist.
Features: two strategies, health checks every 2 s, retry of GET on another server, /lb/stats.
"""
import argparse
import http.client
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

HOP_BY_HOP = {"connection", "keep-alive", "transfer-encoding", "te", "trailer", "upgrade",
              "proxy-authorization", "proxy-authenticate", "host", "content-length"}


class Backend:
    def __init__(self, url):
        parsed = urlparse(url)
        self.url, self.host, self.port = url, parsed.hostname, parsed.port
        self.active = 0           # requests being handled right now
        self.served = 0           # total requests sent here
        self.healthy = True
        self.failed_checks = 0    # health checks failed in a row


class Pool:
    def __init__(self, urls, strategy):
        self.backends = [Backend(u) for u in urls]
        self.strategy = strategy
        self.lock = threading.Lock()
        self.turn = 0

    def choose(self, exclude=()):
        with self.lock:
            healthy = [b for b in self.backends if b.healthy and b not in exclude]
            if not healthy:
                return None
            if self.strategy == "round_robin":
                backend = healthy[self.turn % len(healthy)]
                self.turn += 1
            else:                                             # least_connections
                backend = min(healthy, key=lambda b: b.active)
            backend.active += 1
            backend.served += 1
            return backend

    def release(self, backend):
        with self.lock:
            backend.active -= 1

    def snapshot(self):
        return " ".join(f"{b.port}:{b.active}{'' if b.healthy else '(DOWN)'}" for b in self.backends)


def health_checker(pool, every=2.0, fails_to_mark_down=2):
    """Ask every server GET /api/health. Take dead servers out, put recovered ones back.
    One slow answer is not enough to mark a server DOWN - it must fail 2 checks in a row."""
    while True:
        for b in pool.backends:
            try:
                conn = http.client.HTTPConnection(b.host, b.port, timeout=3)
                conn.request("GET", "/api/health")
                ok = conn.getresponse().status == 200
                conn.close()
            except OSError:
                ok = False
            b.failed_checks = 0 if ok else b.failed_checks + 1
            if ok and not b.healthy:
                b.healthy = True
                print(f"[health] {b.url} is UP again", flush=True)
            elif b.healthy and b.failed_checks >= fails_to_mark_down:
                b.healthy = False
                print(f"[health] {b.url} is DOWN ({b.failed_checks} failed checks)", flush=True)
        time.sleep(every)


class ProxyHandler(BaseHTTPRequestHandler):
    pool: Pool = None

    def log_message(self, *args):        # silence the default access log
        pass

    def _forward(self, backend, body):
        conn = http.client.HTTPConnection(backend.host, backend.port, timeout=15)
        headers = {k: v for k, v in self.headers.items() if k.lower() not in HOP_BY_HOP}
        headers["X-Forwarded-For"] = self.client_address[0]
        conn.request(self.command, self.path, body=body, headers=headers)
        res = conn.getresponse()
        return res.status, res.getheaders(), res.read()

    def _proxy(self):
        if self.path == "/lb/stats":
            data = [{"server": b.url, "healthy": b.healthy, "active": b.active, "served": b.served}
                    for b in self.pool.backends]
            return self._send(200, [("Content-Type", "application/json")], json.dumps(data, indent=2).encode())

        length = int(self.headers.get("Content-Length", 0) or 0)
        body = self.rfile.read(length) if length else None
        tried = []
        while True:
            backend = self.pool.choose(exclude=tried)
            if backend is None:
                return self._send(503, [("Content-Type", "application/json")],
                                  b'{"error": {"code": "NO_HEALTHY_SERVER", "message": "All servers are down"}}')
            print(f"{self.command:<6} {self.path:<32} -> {backend.port}   active [{self.pool.snapshot()}]", flush=True)
            try:
                status, headers, payload = self._forward(backend, body)
                return self._send(status, headers, payload)
            except OSError as error:
                backend.healthy = False
                print(f"[proxy] {backend.url} failed ({error.__class__.__name__}) -> marked DOWN", flush=True)
                tried.append(backend)
                if self.command != "GET":      # never auto-retry POST: it could create 2 orders
                    return self._send(502, [("Content-Type", "application/json")],
                                      b'{"error": {"code": "BAD_GATEWAY", "message": "Server failed, please retry"}}')
            finally:
                self.pool.release(backend)

    def _send(self, status, headers, payload):
        self.send_response(status)
        for key, value in headers:
            if key.lower() not in HOP_BY_HOP:
                self.send_header(key, value)
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("X-Load-Balancer", self.pool.strategy)
        self.end_headers()
        self.wfile.write(payload)

    do_GET = do_POST = do_PATCH = do_PUT = do_DELETE = do_OPTIONS = _proxy


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--strategy", choices=["round_robin", "least_connections"], default="round_robin")
    parser.add_argument("--backends", default="http://localhost:8001,http://localhost:8002,http://localhost:8003")
    args = parser.parse_args()

    ProxyHandler.pool = Pool(args.backends.split(","), args.strategy)
    threading.Thread(target=health_checker, args=(ProxyHandler.pool,), daemon=True).start()
    ThreadingHTTPServer.request_queue_size = 128     # default is 5: bursts would wait 1 s to connect
    server = ThreadingHTTPServer(("0.0.0.0", args.port), ProxyHandler)
    print(f"Load balancer ({args.strategy}) on http://localhost:{args.port} -> {args.backends}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nload balancer stopped")


if __name__ == "__main__":
    main()
