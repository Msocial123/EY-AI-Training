"""
Module 9.1 - Round Robin vs Least Connections (simulation, no install needed).

3 identical API servers. 12 requests arrive, one per second. Most are quick (1 s),
but two are slow "monthly sales report" requests (8 s). Each server works on one
request at a time; extra requests wait in that server's line.

Round Robin       : next server in turn - 1, 2, 3, 1, 2, 3 ... (does not look at load)
Least Connections : the server with the fewest unfinished requests right now
"""
REQUESTS = [  # (name, seconds of work), request i arrives at second i
    ("search", 1), ("report", 8), ("search", 1), ("cart", 1), ("report", 8), ("search", 1),
    ("cart", 1), ("search", 1), ("checkout", 2), ("search", 1), ("cart", 1), ("search", 1),
]
SERVERS = ["api-1", "api-2", "api-3"]


def simulate(strategy):
    busy_until = {s: 0 for s in SERVERS}          # when the server's line becomes empty
    finish_times = {s: [] for s in SERVERS}       # to count unfinished requests
    rows, turn = [], 0
    for arrival, (name, work) in enumerate(REQUESTS):
        active = {s: sum(1 for f in finish_times[s] if f > arrival) for s in SERVERS}
        if strategy == "round_robin":
            server = SERVERS[turn % len(SERVERS)]
            turn += 1
        else:  # least_connections; tie -> first in the list
            server = min(SERVERS, key=lambda s: active[s])
        start = max(arrival, busy_until[server])
        done = start + work
        busy_until[server] = done
        finish_times[server].append(done)
        rows.append((arrival, name, server, active[server], start - arrival, done - arrival))
    return rows


def report(strategy):
    rows = simulate(strategy)
    print(f"\n=== {strategy.replace('_', ' ').title()} ===")
    print(f"{'t':>3} {'request':<9}{'server':<7}{'busy':>5}{'waited':>8}{'response':>10}")
    for t, name, server, active, waited, response in rows:
        flag = "  <- stuck behind a report" if waited >= 3 else ""
        print(f"{t:>3} {name:<9}{server:<7}{active:>5}{waited:>7}s{response:>9}s{flag}")
    quick = [r[5] for r in rows if r[1] != "report"]
    print(f"Average response for quick requests: {sum(quick) / len(quick):.1f}s   worst: {max(quick)}s")
    return sum(quick) / len(quick)


if __name__ == "__main__":
    rr = report("round_robin")
    lc = report("least_connections")
    print(f"\nLeast Connections made quick requests {rr / lc:.1f}x faster on average.")
