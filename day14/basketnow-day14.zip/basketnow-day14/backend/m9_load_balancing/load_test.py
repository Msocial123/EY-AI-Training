"""
Module 9.3 - Send many requests at once through the load balancer and see who served them.

    python m9_load_balancing/load_test.py                       30 requests, 3 at a time (3 shoppers, 3 servers)
    python m9_load_balancing/load_test.py --slow-every 4        every 4th request is slow (1.5 s)

Run it once with round_robin and once with least_connections and compare.
"""
import argparse
import json
import time
import urllib.request
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor

parser = argparse.ArgumentParser()
parser.add_argument("--url", default="http://localhost:8080/api/products")
parser.add_argument("--requests", type=int, default=30)
parser.add_argument("--concurrency", type=int, default=3, help="requests in flight at the same time")
parser.add_argument("--slow-every", type=int, default=0, help="every Nth request asks for a 1.5 s delay")
args = parser.parse_args()


def one_request(n):
    headers = {"X-Request-Id": f"load-{n}"}
    is_slow = args.slow_every and n % args.slow_every == 0
    if is_slow:
        headers["X-Simulate-Delay"] = "1500"          # the API sleeps 1.5 s (like a heavy report)
    start = time.time()
    with urllib.request.urlopen(urllib.request.Request(args.url, headers=headers), timeout=20) as res:
        res.read()
        return res.headers.get("X-Served-By"), time.time() - start, is_slow


start = time.time()
with ThreadPoolExecutor(max_workers=args.concurrency) as pool:
    results = list(pool.map(one_request, range(1, args.requests + 1)))
total = time.time() - start

by_server = defaultdict(list)
for server, seconds, is_slow in results:
    by_server[server].append((seconds, is_slow))

print(f"{args.requests} requests, {args.concurrency} at a time, finished in {total:.2f}s\n")
print(f"{'server':<8}{'requests':>9}{'slow':>6}{'avg time':>10}")
for server in sorted(by_server):
    items = by_server[server]
    slow = sum(1 for _, s in items if s)
    print(f"{server:<8}{len(items):>9}{slow:>6}{sum(t for t, _ in items) / len(items):>9.2f}s")

quick = [t for _, t, s in results if not s]
print(f"\nquick requests: average {sum(quick) / len(quick):.2f}s, worst {max(quick):.2f}s")

stats_url = args.url.split("/api/")[0] + "/lb/stats"
with urllib.request.urlopen(stats_url, timeout=5) as res:
    print("\nLoad balancer stats:", json.dumps(json.loads(res.read())))
