"""
Server-side validation for the checkout form.

The React form validates too (for a fast, friendly experience), but the server
MUST validate again: requests can come from Postman, curl, an old app version
or an attacker - not only from our nice form.
Errors are returned per field so the form can show them next to each input.
"""
import re

from .config import COD_LIMIT, DELIVERY_SLOTS, PAYMENT_METHODS, SERVICEABLE_PINCODES

NAME_RE = re.compile(r"^[A-Za-z][A-Za-z .]{1,49}$")
PHONE_RE = re.compile(r"^[6-9]\d{9}$")          # Indian mobile: 10 digits, starts 6-9
PINCODE_RE = re.compile(r"^\d{6}$")
UPI_RE = re.compile(r"^[\w.\-]{2,}@[A-Za-z]{2,}$")  # e.g. priya.s@okaxis


def validate_checkout(customer, payment, slot, total):
    errors = {}
    name = (customer.get("fullName") or "").strip()
    phone = (customer.get("phone") or "").strip()
    pincode = (customer.get("pincode") or "").strip()

    if not NAME_RE.match(name):
        errors["fullName"] = "Enter your full name (letters only, 2-50 characters)"
    if not PHONE_RE.match(phone):
        errors["phone"] = "Enter a valid 10-digit mobile number starting with 6-9"
    if not PINCODE_RE.match(pincode):
        errors["pincode"] = "Pincode must be exactly 6 digits"
    elif pincode not in SERVICEABLE_PINCODES:
        errors["pincode"] = "Sorry, we do not deliver to this pincode yet"
    if len((customer.get("houseNo") or "").strip()) < 1:
        errors["houseNo"] = "House / flat number is required"
    if len((customer.get("area") or "").strip()) < 5:
        errors["area"] = "Area / street must be at least 5 characters"
    if slot not in DELIVERY_SLOTS:
        errors["slot"] = "Choose a delivery slot"

    method = (payment or {}).get("method")
    if method not in PAYMENT_METHODS:
        errors["paymentMethod"] = "Choose a payment method"
    elif method == "UPI" and not UPI_RE.match((payment.get("upiId") or "").strip()):
        errors["upiId"] = "Enter a valid UPI ID, for example name@okaxis"
    elif method == "COD" and total > COD_LIMIT:
        errors["paymentMethod"] = f"Cash on Delivery is available only up to Rs. {COD_LIMIT}"
    return errors
