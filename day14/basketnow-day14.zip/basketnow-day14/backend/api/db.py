"""
Tiny SQLite "database" for BasketNow.

Why SQLite and not a Python list? In Module 9 we start THREE copies of this API
behind a load balancer. A Python list lives inside one process, so an order
placed on api-1 would be invisible on api-2. A database file is shared by all
copies - exactly like a real company shares one PostgreSQL / SQL Server.
"""
import json
import sqlite3
import time

from .config import DB_FILE, PRODUCTS_FILE


def connect():
    conn = sqlite3.connect(DB_FILE, timeout=10)
    conn.row_factory = sqlite3.Row          # rows behave like dicts: row["qty"]
    return conn


def init_db(reset=False):
    """Create tables and load starting stock from products.json (only once)."""
    with connect() as conn:
        if reset:
            conn.executescript("DROP TABLE IF EXISTS stock; DROP TABLE IF EXISTS orders;")
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS stock (
                variant_id TEXT PRIMARY KEY,
                qty        INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS orders (
                seq         INTEGER PRIMARY KEY AUTOINCREMENT,
                id          TEXT UNIQUE NOT NULL,
                created_at  REAL NOT NULL,
                cancelled   INTEGER NOT NULL DEFAULT 0,
                idem_key    TEXT UNIQUE,           -- Idempotency-Key sent by the client
                data_json   TEXT NOT NULL          -- the whole order as JSON text
            );
            """
        )
        if conn.execute("SELECT COUNT(*) FROM stock").fetchone()[0] == 0:
            catalogue = json.loads(PRODUCTS_FILE.read_text(encoding="utf-8"))
            rows = [(v["id"], v["stock"]) for p in catalogue["products"] for v in p["variants"]]
            conn.executemany("INSERT INTO stock (variant_id, qty) VALUES (?, ?)", rows)


def get_stock_map():
    with connect() as conn:
        return {r["variant_id"]: r["qty"] for r in conn.execute("SELECT * FROM stock")}


def reserve_stock_and_save_order(lines, build_order, idem_key=None):
    """
    Atomically: check stock for every line, reduce it, and save the order.
    Either everything happens or nothing happens (a transaction).
    Returns (order, None) or (None, problems).
    """
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")                  # lock: no one else changes stock now
        problems = []
        for line in lines:
            row = conn.execute("SELECT qty FROM stock WHERE variant_id = ?", (line["variantId"],)).fetchone()
            available = row["qty"] if row else 0
            if line["qty"] > available:
                problems.append({"variantId": line["variantId"], "requested": line["qty"], "available": available})
        if problems:
            conn.rollback()
            return None, problems

        for line in lines:
            conn.execute("UPDATE stock SET qty = qty - ? WHERE variant_id = ?", (line["qty"], line["variantId"]))
        seq = conn.execute("SELECT COALESCE(MAX(seq), 1000) + 1 FROM orders").fetchone()[0]
        order = build_order(f"BN-{seq}", time.time())
        conn.execute(
            "INSERT INTO orders (seq, id, created_at, idem_key, data_json) VALUES (?, ?, ?, ?, ?)",
            (seq, order["id"], order["createdAt"], idem_key, json.dumps(order)),
        )
        conn.commit()
        return order, None


def _row_to_order(row):
    order = json.loads(row["data_json"])                 # JSON text -> Python dict
    order["cancelled"] = bool(row["cancelled"])
    return order


def get_order(order_id):
    with connect() as conn:
        row = conn.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
        return _row_to_order(row) if row else None


def get_order_by_idempotency_key(key):
    if not key:
        return None
    with connect() as conn:
        row = conn.execute("SELECT * FROM orders WHERE idem_key = ?", (key,)).fetchone()
        return _row_to_order(row) if row else None


def list_orders(limit=20):
    with connect() as conn:
        rows = conn.execute("SELECT * FROM orders ORDER BY seq DESC LIMIT ?", (limit,)).fetchall()
        return [_row_to_order(r) for r in rows]


def cancel_order_and_restock(order):
    with connect() as conn:
        conn.execute("UPDATE orders SET cancelled = 1 WHERE id = ?", (order["id"],))
        for item in order["items"]:
            conn.execute("UPDATE stock SET qty = qty + ? WHERE variant_id = ?", (item["qty"], item["variantId"]))
        conn.commit()
