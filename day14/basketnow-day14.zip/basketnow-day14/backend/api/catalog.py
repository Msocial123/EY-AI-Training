"""Product catalogue: read products.json and attach the LIVE stock from the database."""
import json
from functools import lru_cache

from .config import PRODUCTS_FILE
from .db import get_stock_map


@lru_cache(maxsize=1)
def _catalogue():
    return json.loads(PRODUCTS_FILE.read_text(encoding="utf-8"))


def categories():
    return _catalogue()["categories"]


def _with_live_stock(product, stock):
    variants = [{**v, "stock": stock.get(v["id"], 0)} for v in product["variants"]]
    return {**product, "variants": variants, "inStock": any(v["stock"] > 0 for v in variants)}


def list_products(category=None, q=None, sort="relevance", in_stock_only=False):
    stock = get_stock_map()
    items = [_with_live_stock(p, stock) for p in _catalogue()["products"]]

    if category:
        items = [p for p in items if p["category"] == category]
    if q:
        text = q.strip().lower()
        items = [p for p in items if text in f"{p['name']} {p['brand']} {p['category']}".lower()]
    if in_stock_only:
        items = [p for p in items if p["inStock"]]

    cheapest = lambda p: min(v["price"] for v in p["variants"])   # noqa: E731
    if sort == "price_asc":
        items.sort(key=cheapest)
    elif sort == "price_desc":
        items.sort(key=cheapest, reverse=True)
    elif sort == "rating":
        items.sort(key=lambda p: p["rating"], reverse=True)
    return items


def get_product(product_id):
    stock = get_stock_map()
    for p in _catalogue()["products"]:
        if p["id"] == product_id:
            return _with_live_stock(p, stock)
    return None


def find_variant(variant_id):
    """Return (product, variant) for a variant id, or (None, None)."""
    for p in _catalogue()["products"]:
        for v in p["variants"]:
            if v["id"] == variant_id:
                return p, v
    return None, None
