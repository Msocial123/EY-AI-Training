"""
Bill calculation. The SERVER is the source of truth for prices.

Real life: never trust a price sent by the browser - anyone can edit it in DevTools.
The browser sends only {variantId, qty}; we look up the real price here.
"""
from .config import COUPONS, DELIVERY_FEE, FREE_DELIVERY_ABOVE, HANDLING_FEE


def coupon_discount(code, lines, subtotal):
    """Return (discount, error_message). lines = [{price, qty, category}, ...]"""
    if not code:
        return 0, None
    rule = COUPONS.get(code.strip().upper())
    if rule is None:
        return 0, "This coupon code does not exist"
    if subtotal < rule["min_cart"]:
        return 0, f"Add items worth Rs. {rule['min_cart'] - subtotal} more to use {code.upper()}"

    if rule["type"] == "flat":
        discount = rule["value"]
    elif rule["type"] == "percent":
        discount = min(round(subtotal * rule["value"] / 100), rule["max_off"])
    else:  # category_percent
        eligible = sum(l["price"] * l["qty"] for l in lines if l["category"] == rule["category"])
        if eligible == 0:
            return 0, "FRESH20 needs at least one fruit or vegetable in the cart"
        discount = min(round(eligible * rule["value"] / 100), rule["max_off"])
    return min(discount, subtotal), None


def compute_bill(lines, coupon_code=None):
    subtotal = sum(l["price"] * l["qty"] for l in lines)
    mrp_total = sum(l["mrp"] * l["qty"] for l in lines)
    discount, coupon_error = coupon_discount(coupon_code, lines, subtotal)
    after_discount = subtotal - discount
    delivery = 0 if after_discount >= FREE_DELIVERY_ABOVE else DELIVERY_FEE
    total = after_discount + delivery + HANDLING_FEE
    return {
        "itemCount": sum(l["qty"] for l in lines),
        "mrpTotal": mrp_total,
        "subtotal": subtotal,
        "productSavings": mrp_total - subtotal,
        "couponCode": coupon_code.upper() if coupon_code and not coupon_error else None,
        "couponDiscount": discount,
        "couponError": coupon_error,
        "deliveryFee": delivery,
        "handlingFee": HANDLING_FEE,
        "total": total,
    }
