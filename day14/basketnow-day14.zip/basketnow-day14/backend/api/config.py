"""
BasketNow business rules and settings - one place for every number.

Real life: marketing changes the free-delivery limit during a sale.
They change ONE line here, not ten places in the code.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent      # .../backend
PRODUCTS_FILE = BASE_DIR / "data" / "products.json"
DB_FILE = Path(os.getenv("BASKETNOW_DB", BASE_DIR / "data" / "basketnow.db"))

# ---- Bill rules (same numbers are used by the React cart preview) ----
FREE_DELIVERY_ABOVE = 199      # Rs. - below this we charge a delivery fee
DELIVERY_FEE = 25
HANDLING_FEE = 4
COD_LIMIT = 2000               # Cash on Delivery not allowed above this total
MAX_QTY_PER_ITEM = 5           # quick-commerce apps limit quantity per item

COUPONS = {
    "WELCOME50": {"type": "flat", "value": 50, "min_cart": 299,
                  "text": "Rs. 50 off on orders above Rs. 299"},
    "SAVE10": {"type": "percent", "value": 10, "max_off": 75, "min_cart": 199,
               "text": "10% off up to Rs. 75 on orders above Rs. 199"},
    "FRESH20": {"type": "category_percent", "value": 20, "max_off": 60,
                "category": "fruits-vegetables", "min_cart": 0,
                "text": "20% off on Fruits & Vegetables, up to Rs. 60"},
}

# pincode -> city. Anything else is "not serviceable".
SERVICEABLE_PINCODES = {
    "500081": "Hyderabad", "500032": "Hyderabad", "500072": "Hyderabad",
    "516001": "Kadapa", "524001": "Nellore", "530003": "Visakhapatnam",
}

DELIVERY_SLOTS = {
    "asap": "Express - 15 minutes",
    "evening": "Today 6 PM - 8 PM",
    "morning": "Tomorrow 7 AM - 9 AM",
}
PAYMENT_METHODS = {"UPI", "CARD", "COD"}

# ---- Order tracking timeline: status -> seconds after the order was placed ----
# TIMELINE_SCALE=0.5 makes the demo twice as fast, 2 makes it twice as slow.
TIMELINE_SCALE = float(os.getenv("TIMELINE_SCALE", "1"))
STATUS_FLOW = [
    ("PLACED", "Order placed", 0),
    ("CONFIRMED", "Confirmed by store", 10),
    ("PACKED", "Packed", 25),
    ("OUT_FOR_DELIVERY", "Out for delivery", 45),
    ("DELIVERED", "Delivered", 75),
]
CANCELLABLE = {"PLACED", "CONFIRMED", "PACKED"}   # not once the rider has left

# ---- Event bus used when an order is placed (Module 8) ----
EVENT_BUS = os.getenv("EVENT_BUS", "memory")      # "memory" or "rabbitmq"
RABBITMQ_URL = os.getenv("RABBITMQ_URL", "amqp://guest:guest@localhost:5672/%2F")
