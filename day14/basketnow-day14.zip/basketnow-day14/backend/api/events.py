"""
Publishing business events ("order.placed", "order.cancelled").

The API does NOT call the inventory, SMS and analytics services one by one.
It publishes ONE event and returns quickly. Whoever is interested listens.

EVENT_BUS=memory   (default) -> in-process subscribers that just log; no install needed
EVENT_BUS=rabbitmq           -> publish to RabbitMQ topic exchange "basketnow.events"
                                (start RabbitMQ first, see m8_messaging/rabbitmq/README.md)
"""
import json
import logging
import threading

from .config import EVENT_BUS, RABBITMQ_URL

log = logging.getLogger("events")
EXCHANGE = "basketnow.events"


class MemoryEventBus:
    """Good enough for local development: subscribers run in background threads."""

    def __init__(self):
        self.subscribers = []          # list of (routing_key_prefix, handler)

    def subscribe(self, prefix, handler):
        self.subscribers.append((prefix, handler))

    def publish(self, routing_key, payload):
        log.info("EVENT %s published (%d bytes)", routing_key, len(json.dumps(payload)))
        for prefix, handler in self.subscribers:
            if routing_key.startswith(prefix):
                threading.Thread(target=handler, args=(routing_key, payload), daemon=True).start()


class RabbitMQEventBus:
    """Publishes to a durable topic exchange. Consumers live in m8_messaging/rabbitmq/."""

    def __init__(self, url):
        import pika                    # imported here so 'memory' mode needs no pika install
        self.pika = pika
        self.params = pika.URLParameters(url)

    def publish(self, routing_key, payload):
        # A new short connection per event keeps the example simple and thread-safe.
        with self.pika.BlockingConnection(self.params) as conn:
            channel = conn.channel()
            channel.exchange_declare(exchange=EXCHANGE, exchange_type="topic", durable=True)
            channel.basic_publish(
                exchange=EXCHANGE,
                routing_key=routing_key,
                body=json.dumps(payload),
                properties=self.pika.BasicProperties(
                    content_type="application/json",
                    delivery_mode=2,                 # 2 = persistent: survives a broker restart
                    message_id=payload.get("orderId"),
                ),
            )
        log.info("EVENT %s sent to RabbitMQ exchange %s", routing_key, EXCHANGE)


def _demo_subscribers(bus):
    """What the other teams' services would do. Here they only write a log line."""
    bus.subscribe("order.placed", lambda k, e: log.info(
        "[inventory-service] reserve %d items for %s", e["itemCount"], e["orderId"]))
    bus.subscribe("order.placed", lambda k, e: log.info(
        "[notification-service] SMS to %s: Order %s confirmed, Rs. %s", e["phone"][-4:].rjust(10, "*"),
        e["orderId"], e["total"]))
    bus.subscribe("order.", lambda k, e: log.info("[analytics-service] recorded %s for %s", k, e["orderId"]))


def create_event_bus():
    if EVENT_BUS == "rabbitmq":
        return RabbitMQEventBus(RABBITMQ_URL)
    bus = MemoryEventBus()
    _demo_subscribers(bus)
    return bus
