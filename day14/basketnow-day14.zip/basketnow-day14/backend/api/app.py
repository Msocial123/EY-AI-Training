"""
BasketNow REST API (Flask).

Every URL is a RESOURCE (a noun), the HTTP METHOD is the action (a verb):
    GET    /api/health                  is this instance alive?
    GET    /api/categories              list categories with product counts
    GET    /api/products                list products  (?category=&q=&sort=&inStock=1)
    GET    /api/products/<id>           one product                     404 if unknown
    GET    /api/pincodes/<pincode>      can we deliver here?            400 if not 6 digits
    POST   /api/cart/quote              price a cart + coupon (server is the truth)
    POST   /api/orders                  place an order          201 / 400 / 409
    GET    /api/orders                  recent orders
    GET    /api/orders/<id>             one order with live status      404 if unknown
    PATCH  /api/orders/<id>/cancel      cancel before the rider leaves  409 if too late

Developer headers used by the React "Developer tools" footer:
    X-Simulate-Error: 1      -> answer 503 (test your error screens)
    X-Simulate-Delay: 2000   -> wait 2000 ms (test your loading screens)
"""
import logging
import os
import random
import time
import uuid

from flask import Flask, g, jsonify, request

from . import catalog, db
from .config import COUPONS, DELIVERY_SLOTS, SERVICEABLE_PINCODES
from .events import create_event_bus
from .pricing import compute_bill
from .tracking import with_live_status
from .validation import validate_checkout


def api_error(status, code, message, **extra):
    """One error format for the whole API, so the frontend can handle it in one place."""
    return jsonify({"error": {"code": code, "message": message, **extra}}), status


def build_lines(items):
    """Turn [{variantId, qty}] from the browser into priced lines using OUR prices."""
    lines, unknown = [], []
    for item in items or []:
        product, variant = catalog.find_variant(item.get("variantId"))
        qty = item.get("qty")
        if product is None or not isinstance(qty, int) or qty < 1:
            unknown.append(item.get("variantId"))
            continue
        lines.append({
            "variantId": variant["id"], "productId": product["id"], "name": product["name"],
            "label": variant["label"], "image": product["image"], "category": product["category"],
            "price": variant["price"], "mrp": variant["mrp"], "qty": qty,
        })
    return lines, unknown


def create_app(instance_name="api-1"):
    app = Flask(__name__)
    app.json.sort_keys = False                      # keep our key order in JSON responses
    log = logging.getLogger(instance_name)
    events = create_event_bus()
    db.init_db()
    fail_rate = float(os.getenv("FAIL_RATE", "0"))  # e.g. FAIL_RATE=0.3 -> 30% random 503s

    # ------------------------------------------------------------------ hooks
    @app.before_request
    def simulate_network_problems():
        g.request_id = request.headers.get("X-Request-Id") or uuid.uuid4().hex[:8]
        g.started = time.time()
        if request.method == "OPTIONS" or request.path == "/api/health":
            return None
        delay_ms = min(int(request.headers.get("X-Simulate-Delay", "0") or 0), 5000)
        if delay_ms:
            time.sleep(delay_ms / 1000)
        if request.headers.get("X-Simulate-Error") == "1" or random.random() < fail_rate:
            return api_error(503, "SERVICE_UNAVAILABLE", "BasketNow is busy right now. Please try again.")
        return None

    @app.after_request
    def add_common_headers(response):
        # CORS: allow a browser app from another origin (e.g. localhost:5173) to call us.
        response.headers["Access-Control-Allow-Origin"] = "*"
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, PATCH, OPTIONS"
        response.headers["Access-Control-Allow-Headers"] = (
            "Content-Type, X-Request-Id, Idempotency-Key, X-Simulate-Error, X-Simulate-Delay")
        response.headers["Access-Control-Expose-Headers"] = "X-Served-By, X-Request-Id"
        response.headers["X-Served-By"] = instance_name      # which copy answered (Module 9)
        response.headers["X-Request-Id"] = g.get("request_id", "-")
        took = (time.time() - g.get("started", time.time())) * 1000
        log.info("%s %s -> %s (%.0f ms) id=%s", request.method, request.full_path.rstrip("?"),
                 response.status_code, took, g.get("request_id"))
        return response

    @app.errorhandler(404)
    def not_found(_e):
        return api_error(404, "NOT_FOUND", f"No route for {request.path}")

    @app.errorhandler(405)
    def method_not_allowed(_e):
        return api_error(405, "METHOD_NOT_ALLOWED", f"{request.method} is not allowed on {request.path}")

    @app.errorhandler(Exception)
    def unexpected(e):
        log.exception("Unexpected error: %s", e)
        return api_error(500, "INTERNAL_ERROR", "Something went wrong on our side")

    # ----------------------------------------------------------------- routes
    @app.get("/api/health")
    def health():
        return {"status": "UP", "instance": instance_name}

    @app.get("/api/categories")
    def list_categories():
        products = catalog.list_products()
        return jsonify([
            {**c, "count": sum(1 for p in products if p["category"] == c["slug"])}
            for c in catalog.categories()
        ])

    @app.get("/api/products")
    def list_products():
        items = catalog.list_products(
            category=request.args.get("category") or None,
            q=request.args.get("q") or None,
            sort=request.args.get("sort", "relevance"),
            in_stock_only=request.args.get("inStock") == "1",
        )
        return {"items": items, "total": len(items)}

    @app.get("/api/products/<product_id>")
    def get_product(product_id):
        product = catalog.get_product(product_id)
        if product is None:
            return api_error(404, "PRODUCT_NOT_FOUND", f"Product {product_id} does not exist")
        return product

    @app.get("/api/pincodes/<pincode>")
    def check_pincode(pincode):
        if not (pincode.isdigit() and len(pincode) == 6):
            return api_error(400, "INVALID_PINCODE", "Pincode must be exactly 6 digits")
        city = SERVICEABLE_PINCODES.get(pincode)
        return {"pincode": pincode, "serviceable": city is not None, "city": city,
                "etaMinutes": 15 if city else None}

    @app.get("/api/meta")
    def meta():
        return {"coupons": [{"code": k, "text": v["text"]} for k, v in COUPONS.items()],
                "slots": [{"id": k, "label": v} for k, v in DELIVERY_SLOTS.items()]}

    @app.post("/api/cart/quote")
    def quote():
        body = request.get_json(silent=True) or {}
        lines, unknown = build_lines(body.get("items"))
        if unknown:
            return api_error(400, "UNKNOWN_ITEMS", "Some cart items are invalid", items=unknown)
        bill = compute_bill(lines, body.get("couponCode"))
        if bill["couponError"]:
            return api_error(400, "INVALID_COUPON", bill["couponError"], fields={"couponCode": bill["couponError"]})
        return {"lines": lines, "bill": bill}

    @app.post("/api/orders")
    def place_order():
        body = request.get_json(silent=True)
        if body is None:
            return api_error(400, "BAD_JSON", "Send a JSON body with Content-Type: application/json")

        # Same Idempotency-Key again (double click, network retry)? Return the SAME order.
        idem_key = request.headers.get("Idempotency-Key")
        existing = db.get_order_by_idempotency_key(idem_key)
        if existing:
            log.info("Idempotent replay for key %s -> %s", idem_key, existing["id"])
            return with_live_status(existing), 200

        lines, unknown = build_lines(body.get("items"))
        if not lines or unknown:
            return api_error(400, "EMPTY_OR_INVALID_CART", "Your cart is empty or has invalid items")
        bill = compute_bill(lines, body.get("couponCode"))

        customer = body.get("customer") or {}
        payment = body.get("payment") or {}
        fields = validate_checkout(customer, payment, body.get("slot"), bill["total"])
        if bill["couponError"]:
            fields["couponCode"] = bill["couponError"]
        if fields:
            return api_error(400, "VALIDATION_ERROR", "Please correct the highlighted fields", fields=fields)

        def build_order(order_id, created_at):
            return {
                "id": order_id, "createdAt": created_at,
                "items": [{k: l[k] for k in ("variantId", "productId", "name", "label", "image", "price", "qty")}
                          for l in lines],
                "bill": bill,
                "customer": {k: (customer.get(k) or "").strip() for k in
                             ("fullName", "phone", "pincode", "houseNo", "area", "landmark", "addressType")},
                "city": SERVICEABLE_PINCODES[customer["pincode"].strip()],
                "slot": DELIVERY_SLOTS[body["slot"]],
                "payment": {"method": payment["method"]},          # never store a full UPI id / card
                "instructions": (body.get("instructions") or "").strip()[:120],
            }

        order, problems = db.reserve_stock_and_save_order(lines, build_order, idem_key)
        if problems:
            return api_error(409, "OUT_OF_STOCK", "Some items just went out of stock", items=problems)

        events.publish("order.placed", {
            "orderId": order["id"], "total": bill["total"], "itemCount": bill["itemCount"],
            "phone": order["customer"]["phone"], "city": order["city"],
            "items": [{"variantId": i["variantId"], "qty": i["qty"]} for i in order["items"]],
        })
        return with_live_status(order), 201

    @app.get("/api/orders")
    def list_orders():
        return jsonify([with_live_status(o) for o in db.list_orders()])

    @app.get("/api/orders/<order_id>")
    def get_order(order_id):
        order = db.get_order(order_id)
        if order is None:
            return api_error(404, "ORDER_NOT_FOUND", f"Order {order_id} does not exist")
        return with_live_status(order)

    @app.patch("/api/orders/<order_id>/cancel")
    def cancel_order(order_id):
        order = db.get_order(order_id)
        if order is None:
            return api_error(404, "ORDER_NOT_FOUND", f"Order {order_id} does not exist")
        live = with_live_status(order)
        if not live["canCancel"]:
            return api_error(409, "CANNOT_CANCEL", f"Order is already {live['statusLabel'].lower()}")
        db.cancel_order_and_restock(order)
        events.publish("order.cancelled", {"orderId": order_id, "total": order["bill"]["total"],
                                           "itemCount": order["bill"]["itemCount"],
                                           "phone": order["customer"]["phone"]})
        return with_live_status(db.get_order(order_id))

    return app
