"""Order status is calculated from the time since the order was placed (like a delivery simulation)."""
import time

from .config import CANCELLABLE, STATUS_FLOW, TIMELINE_SCALE


def with_live_status(order, now=None):
    """Return a copy of the order with status, steps, etaMinutes and canCancel filled in."""
    now = now or time.time()
    elapsed = now - order["createdAt"]

    if order.get("cancelled"):
        status = "CANCELLED"
    else:
        status = "PLACED"
        for key, _label, after_seconds in STATUS_FLOW:
            if elapsed >= after_seconds * TIMELINE_SCALE:
                status = key

    keys = [s[0] for s in STATUS_FLOW]
    current_index = keys.index(status) if status in keys else -1
    steps = [
        {"key": key, "label": label, "done": i <= current_index, "current": i == current_index}
        for i, (key, label, _) in enumerate(STATUS_FLOW)
    ]
    delivered_at = STATUS_FLOW[-1][2] * TIMELINE_SCALE
    eta_seconds = max(0, delivered_at - elapsed) if status not in ("DELIVERED", "CANCELLED") else 0
    labels = {k: l for k, l, _ in STATUS_FLOW} | {"CANCELLED": "Cancelled"}
    return {
        **order,
        "status": status,
        "statusLabel": labels[status],
        "steps": steps,
        "etaMinutes": round(eta_seconds / 60, 1),
        "canCancel": status in CANCELLABLE,
    }
