# BasketNow - Day 14: React data flow + backend communication

BasketNow (the Day 13 grocery app) now goes live: a real Python API, React Router pages,
Context-based shared state, validated forms, axios services, live order tracking over
WebSockets, events on message queues and a load balancer.

```
basketnow-day14/
├── frontend/                 React 19 + Vite + React Router + axios
│   └── src/
│       ├── context/          CartContext (useReducer), DevToolsContext          Module 1
│       ├── hooks/            useForm, useApi, useOrderLive, useDebounce          Modules 2,3,6,7
│       ├── services/         apiClient (axios), fetchClient, product/order services, ApiError   Modules 5,6
│       ├── utils/            validation rules, bill preview, business rules      Module 3
│       ├── components/       ui/ (Button, TextField, OptionCards, ErrorState...), layout/
│       ├── pages/            Home, Product, Cart, Checkout, Orders, OrderTracking, NotFound   Module 4
│       └── labs/             Learning Lab: small experiments for each concept
├── backend/
│   ├── api/                  Flask REST API + SQLite + event bus                Modules 5-9
│   ├── run_api.py            start the API (python run_api.py)
│   ├── tests/                pytest tests for the API
│   ├── m7_protocols/         REST client, WebSocket server/client, gRPC, comparisons
│   ├── m8_messaging/         4 patterns (no install) + RabbitMQ + Azure Service Bus
│   └── m9_load_balancing/    algorithms simulation, real load balancer, load test, nginx.conf
└── solutions/                hands-on lab solutions (trainer)
```

## Run it (two terminals)

```
# Terminal 1 - backend
cd backend
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
python run_api.py --reset            # http://localhost:8000/api/health

# Terminal 2 - frontend
cd frontend
npm install
npm run dev                          # http://localhost:5173
```

Optional, for live order tracking: `python m7_protocols/ws_server.py` (Terminal 3).
Without it the tracking page falls back to REST polling every 5 seconds.

| Port | What |
|---|---|
| 5173 | React app (Vite) |
| 8000 | BasketNow API |
| 8001-8003 | API copies behind the load balancer (Module 9) |
| 8080 | Load balancer |
| 8765 | WebSocket order tracking |
| 50051 | gRPC inventory service |
| 5672 / 15672 | RabbitMQ / RabbitMQ web UI |

Tests: `cd backend && python -m pytest -v`
