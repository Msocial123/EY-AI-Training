"""
LAB 6 SOLUTION - add a NEW subscriber without touching the publisher.

Copy into backend/m8_messaging/ and run:  python lab6_loyalty_points.py
loyalty-service listens to order.placed AND order.cancelled:
  placed    -> +1 point per Rs. 100
  cancelled -> take the points back
A message with a missing "total" is poison -> after 3 tries it goes to the DLQ.
"""
from collections import defaultdict

from minibroker import MiniBroker, say

broker = MiniBroker()
broker.declare_exchange("basketnow.events", "topic")
broker.declare_queue("loyalty-service", dead_letter_queue="loyalty-service.dlq", max_deliveries=3)
broker.bind("basketnow.events", "loyalty-service", "order.placed")
broker.bind("basketnow.events", "loyalty-service", "order.cancelled")

points = defaultdict(int)


def loyalty(msg, worker):
    e = msg.body
    change = e["total"] // 100                    # KeyError if "total" is missing -> retry -> DLQ
    if msg.routing_key == "order.cancelled":
        change = -change
    points[e["phone"]] += change
    say(f"[loyalty] {e['orderId']}: {change:+d} points -> {e['phone']} now has {points[e['phone']]}")


broker.consume("loyalty-service", loyalty)
for key, event in [
    ("order.placed", {"orderId": "BN-1001", "phone": "9876543210", "total": 548}),
    ("order.placed", {"orderId": "BN-1002", "phone": "9876543210", "total": 214}),
    ("order.cancelled", {"orderId": "BN-1002", "phone": "9876543210", "total": 214}),
    ("order.placed", {"orderId": "BN-1003", "phone": "9123456780"}),            # broken: no total
]:
    broker.publish("basketnow.events", key, event)
broker.wait_until_idle("loyalty-service")
broker.stop()
say(f"final points: {dict(points)} | messages in DLQ: {broker.depth('loyalty-service.dlq')}")
