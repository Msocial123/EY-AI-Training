// LAB 2 SOLUTION - "Sell on BasketNow" form: controlled inputs + validation with useForm.
// Save as frontend/src/pages/SellerSignupPage.jsx and add to App.jsx:
//   <Route path="/sell" element={<SellerSignupPage />} />
import { useState } from "react";
import Button from "../components/ui/Button";
import TextField from "../components/ui/TextField";
import { useForm } from "../hooks/useForm";
import { onlyDigits, rules } from "../utils/validation";

const GSTIN_RE = /^\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/;      // e.g. 36ABCDE1234F1Z5
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function validateSeller(v) {
  const errors = {};
  if (v.shopName.trim().length < 3) errors.shopName = "Shop name must be at least 3 characters";
  const phoneError = rules.phone(v.phone);
  if (phoneError) errors.phone = phoneError;
  if (!EMAIL_RE.test(v.email.trim())) errors.email = "Enter a valid email address";
  if (!GSTIN_RE.test(v.gstin)) errors.gstin = "GSTIN must be 15 characters, like 36ABCDE1234F1Z5";
  if (!v.category) errors.category = "Choose what you sell";
  if (v.password.length < 8) errors.password = "Password must be at least 8 characters";
  else if (v.password !== v.confirmPassword) errors.confirmPassword = "Passwords do not match";  // cross-field
  return errors;
}

export default function SellerSignupPage() {
  const [done, setDone] = useState(null);
  const form = useForm({
    initialValues: { shopName: "", phone: "", email: "", gstin: "", category: "", password: "", confirmPassword: "" },
    validate: validateSeller,
    transform: { phone: (v) => onlyDigits(v, 10), gstin: (v) => v.toUpperCase().replace(/\s/g, "").slice(0, 15) },
    onSubmit: async (values) => {
      await new Promise((r) => setTimeout(r, 800));          // pretend API call
      setDone(values.shopName);
    },
  });
  const field = (name) => ({ name, value: form.values[name], onChange: form.handleChange, onBlur: form.handleBlur, error: form.errorFor(name) });

  if (done) return <div className="panel"><h1>Welcome, {done}! 🎉</h1><p>Our team will verify your GSTIN within 24 hours.</p></div>;
  return (
    <form ref={form.formRef} className="panel checkout-form" onSubmit={form.handleSubmit} noValidate>
      <h1>Sell on BasketNow</h1>
      <TextField label="Shop name" {...field("shopName")} />
      <div className="row-2">
        <TextField label="Mobile number" inputMode="numeric" {...field("phone")} />
        <TextField label="Email" type="email" {...field("email")} />
      </div>
      <TextField label="GSTIN" hint="15 characters, printed on your GST certificate" {...field("gstin")} />
      <div className="field">
        <label htmlFor="category">What do you sell?</label>
        <select id="category" {...field("category")}>
          <option value="">Choose...</option>
          <option value="fruits-vegetables">Fruits & Vegetables</option>
          <option value="dairy-bakery">Dairy & Bakery</option>
          <option value="staples">Staples</option>
        </select>
        {form.errorFor("category") && <p className="field-error">{form.errorFor("category")}</p>}
      </div>
      <div className="row-2">
        <TextField label="Password" type="password" {...field("password")} />
        <TextField label="Confirm password" type="password" {...field("confirmPassword")} />
      </div>
      <Button type="submit" className="block" loading={form.submitting}>Create seller account</Button>
    </form>
  );
}
