// LAB 4 SOLUTION (part 2) - load coupon hints from GET /api/meta instead of hard-coding them.
// Save as frontend/src/components/CouponHints.jsx and use it inside CouponBox in CartPage.jsx:
//   <CouponHints onPick={setCode} />
import { useApi } from "../hooks/useApi";
import { metaService } from "../services/metaService";

export default function CouponHints({ onPick }) {
  const { data, loading, error, reload } = useApi((signal) => metaService.get({ signal }), []);

  if (loading) return <small className="muted">Loading offers...</small>;
  if (error) return <small className="field-error">Offers unavailable. <button type="button" className="link" onClick={reload}>Retry</button></small>;
  return (
    <div className="coupon-hints">
      {data.coupons.map((c) => (
        <button type="button" key={c.code} className="chip small" title={c.text} onClick={() => onPick(c.code)}>{c.code}</button>
      ))}
    </div>
  );
}
