// LAB 3 SOLUTION - a route with a parameter: /offers/:code
// Save as frontend/src/pages/OfferPage.jsx and add to App.jsx:
//   <Route path="/offers/:code" element={<OfferPage />} />
// Try /offers/SAVE10 and /offers/WRONG
import { Link, useNavigate, useParams } from "react-router-dom";
import Button from "../components/ui/Button";
import EmptyState from "../components/ui/EmptyState";
import { useCart } from "../context/CartContext";
import { COUPONS } from "../utils/rules";

export default function OfferPage() {
  const { code } = useParams();
  const navigate = useNavigate();
  const { applyCoupon, items } = useCart();
  const offer = COUPONS[code.toUpperCase()];

  if (!offer) {
    return (
      <EmptyState icon="🏷️" title="Offer not found" text={`"${code}" is not a valid offer.`}>
        <Link to="/" className="btn btn-primary btn-md">Back to shop</Link>
      </EmptyState>
    );
  }
  function handleUseOffer() {
    applyCoupon(code.toUpperCase());
    navigate(items.length ? "/cart" : "/");
  }
  return (
    <div className="panel">
      <h1>🏷️ {code.toUpperCase()}</h1>
      <p>{offer.text}</p>
      <Button onClick={handleUseOffer}>Use this offer</Button>
    </div>
  );
}
