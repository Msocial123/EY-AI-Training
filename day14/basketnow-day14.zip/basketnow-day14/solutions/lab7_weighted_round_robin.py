"""
LAB 7 SOLUTION - Weighted Round Robin.

api-3 is a bigger machine (8 CPUs instead of 4), so it should get TWICE the requests.
Copy into backend/m9_load_balancing/ and run:  python lab7_weighted_round_robin.py
"""
from collections import Counter
from itertools import cycle

WEIGHTS = {"api-1": 1, "api-2": 1, "api-3": 2}


def weighted_round_robin(weights):
    """Simple version: repeat each server 'weight' times in the rotation."""
    rotation = [server for server, weight in weights.items() for _ in range(weight)]
    return cycle(rotation)


def smooth_weighted_round_robin(weights):
    """NGINX's 'smooth' version: same totals, but the big server's turns are spread out."""
    current = {s: 0 for s in weights}
    total = sum(weights.values())
    while True:
        for s in weights:
            current[s] += weights[s]
        best = max(current, key=current.get)
        current[best] -= total
        yield best


for name, picker in [("simple", weighted_round_robin(WEIGHTS)), ("smooth", smooth_weighted_round_robin(WEIGHTS))]:
    order = [next(picker) for _ in range(8)]
    print(f"{name:<7}: {' '.join(order)}")
    print(f"         share of 8 requests: {dict(Counter(order))}")
