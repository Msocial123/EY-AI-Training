// LAB 4 SOLUTION (part 1) - a reusable API service function.
// Save as frontend/src/services/metaService.js
import { apiClient } from "./apiClient";

export const metaService = {
  async get({ signal } = {}) {
    const { data } = await apiClient.get("/meta", { signal });
    return data;                         // { coupons: [{code, text}], slots: [{id, label}] }
  },
};
