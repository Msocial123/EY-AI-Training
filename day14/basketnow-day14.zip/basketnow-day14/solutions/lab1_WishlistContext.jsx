// LAB 1 SOLUTION - Wishlist as shared state (Context + useReducer)
// 1. Save as frontend/src/context/WishlistContext.jsx
// 2. In main.jsx wrap <App /> with <WishlistProvider> (inside <CartProvider>)
// 3. Use <WishlistHeart productId={product.id} /> in ProductCard and show `count` in Header.
import { createContext, useContext, useEffect, useMemo, useReducer } from "react";

const WishlistContext = createContext(null);

function wishlistReducer(ids, action) {
  switch (action.type) {
    case "TOGGLE":
      return ids.includes(action.productId) ? ids.filter((id) => id !== action.productId) : [...ids, action.productId];
    case "CLEAR":
      return [];
    default:
      throw new Error(`Unknown wishlist action: ${action.type}`);
  }
}

function loadSaved() {
  try {
    const saved = JSON.parse(localStorage.getItem("bn-wishlist"));
    return Array.isArray(saved) ? saved : [];
  } catch {
    return [];
  }
}

export function WishlistProvider({ children }) {
  const [ids, dispatch] = useReducer(wishlistReducer, undefined, loadSaved);
  useEffect(() => localStorage.setItem("bn-wishlist", JSON.stringify(ids)), [ids]);
  const value = useMemo(() => ({
    ids,
    count: ids.length,
    has: (productId) => ids.includes(productId),
    toggle: (productId) => dispatch({ type: "TOGGLE", productId }),
    clear: () => dispatch({ type: "CLEAR" }),
  }), [ids]);
  return <WishlistContext.Provider value={value}>{children}</WishlistContext.Provider>;
}

export function useWishlist() {
  const ctx = useContext(WishlistContext);
  if (!ctx) throw new Error("useWishlist() must be used inside <WishlistProvider>");
  return ctx;
}

export function WishlistHeart({ productId }) {
  const { has, toggle } = useWishlist();
  const saved = has(productId);
  return (
    <button type="button" className="link" aria-pressed={saved} onClick={() => toggle(productId)}
            aria-label={saved ? "Remove from wishlist" : "Add to wishlist"}>
      {saved ? "♥" : "♡"}
    </button>
  );
}
