# BasketNow: Quick-Commerce Web App

BasketNow delivers groceries in 15 minutes in Hyderabad, Kadapa, Nellore and Visakhapatnam.
This repository is its customer web app and the store manager's inventory screen, built with **React 19 + Vite**,
React Router, axios and a REST API.

This release adds accounts and production readiness: login and protected pages, user sessions, error boundaries,
environment configuration, logging, a smaller production build and deployment to **Azure Static Web Apps**.
The requirements, tickets and test cases are in the **BasketNow Project Brief (PDF)**.

## Run it

```bash
npm install
npm run dev        # http://localhost:5173  (the REST API runs inside the same dev server)
npm run build      # production build in dist/
npm run preview    # serve dist/ at http://localhost:4173 (with the API)
```

Node.js 20.19+ or 22.12+ is required. Configuration lives in `.env` (see `.env.example`).

## Demo accounts

| Role | Email | Password |
|---|---|---|
| Customer | priya@basketnow.in | Priya@123 |
| Customer | ravi@basketnow.in | Ravi@123 |
| Store manager (admin) | admin@basketnow.in | Admin@123 |

## What is provided vs. what you build

| Provided | You build |
|---|---|
| The whole shop from earlier releases (catalogue, cart, checkout, orders, inventory) | Every file listed in the tickets below |
| `mock-server/server.js`: the REST API with login, tokens and roles | `.env`, `.env.production`, `.env.example` |
| `mock-server/mockApi.js`: runs the API inside `npm run dev` and `npm run preview` | `public/staticwebapp.config.json` and the `api/` folder (Azure Functions) |
| `src/styles.css`: the complete design system | |

New source files start with a TODO comment: the ticket, the props or return value and the behaviour required.

## Tickets

| Ticket | Title | Files |
|---|---|---|
| BN-901 | Reusable layouts and loading components | `Spinner.jsx`, `LoadingState.jsx`, `PageHeader.jsx`, `AuthLayout.jsx`, pages |
| BN-902 | API client that sends the login token | `api/client.js`, `api/authApi.js` |
| BN-903 | Login, protected routes and roles | `AuthContext.jsx`, `LoginPage.jsx`, `ProtectedRoute.jsx`, `RequireRole.jsx`, `App.jsx`, `main.jsx`, `Header.jsx`, `ShopContext.jsx`, `validation.js` |
| BN-904 | User sessions | `utils/session.js`, `AuthContext.jsx`, `LoginPage.jsx`, `AccountPage.jsx`, `App.jsx`, `Header.jsx` |
| BN-905 | Error boundaries, offline and loading states | `ErrorBoundary.jsx`, `CrashTest.jsx`, `useOnlineStatus.js`, `Layout.jsx`, `main.jsx` |
| BN-906 | Environment variables and configuration | `.env*`, `config/env.js`, `vite.config.js`, `index.html`, `client.js`, `Footer.jsx` |
| BN-907 | Logging and debugging | `utils/logger.js`, `client.js`, `AuthContext.jsx`, `ErrorBoundary.jsx`, `main.jsx` |
| BN-908 | Build and performance | `App.jsx` (lazy pages), `Layout.jsx`, `AuthLayout.jsx`, `CatalogPage.jsx`, `CategoryBar.jsx`, `CatalogToolbar.jsx`, `vite.config.js` |
| BN-909 | Deploy to Azure Static Web Apps | `public/staticwebapp.config.json`, `api/`, `package.json`, `.env.production` |

## REST API

| Method | Path | Who |
|---|---|---|
| POST | `/api/auth/login` `{ email, password }` → `{ token, expiresAt, user }` | anyone |
| GET | `/api/auth/me` → `{ user, expiresAt }` | logged in |
| POST | `/api/auth/logout` → 204 (the token is revoked) | logged in |
| GET | `/api/products`, `/api/products/:id`, `/api/pincodes/:pincode` | anyone |
| GET · POST | `/api/orders` (own orders; the admin sees all) | logged in |
| GET · PATCH | `/api/orders/:id`, `/api/orders/:id/cancel` | owner or admin |
| POST · DELETE · PATCH | `/api/products`, `/api/products/:id`, `/api/variants/:id` | admin |
| POST | `/api/reset` | anyone (demo) |

The token is sent as `Authorization: Bearer <token>` (locally) or `X-Auth-Token: Bearer <token>` (Azure Static Web Apps
replaces the Authorization header). Errors: `{ "error": { "code", "message", "fields" } }` with 400, 401, 403, 404, 409 or 503.

## Deploy (Azure Static Web Apps)

```bash
npm run build && npm run build:api          # dist/ (React) and api/src/server.cjs (the API)
npx swa deploy ./dist --api-location ./api --api-language node --api-version 22 --env production --deployment-token <TOKEN>
```

Server settings such as `AUTH_SECRET` are set in Azure (Static Web App → Environment variables), never in a `VITE_` variable.
