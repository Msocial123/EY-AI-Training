// Azure Functions (Node.js v4 programming model). Azure Static Web Apps sends every /api/... request here.
// It is only an ADAPTER: Azure request -> handleRequest() (the same server code as local) -> Azure response.
const { app } = require("@azure/functions");
const { handleRequest } = require("../server.cjs");    // created by `npm run build:api` from mock-server/server.js

app.http("api", {
  methods: ["GET", "POST", "PATCH", "DELETE"],
  authLevel: "anonymous",                                 // our own token check runs inside handleRequest
  route: "{*path}",                                       // every path under /api/
  handler: async (request, context) => {
    const url = new URL(request.url);
    const result = await handleRequest({
      method: request.method,
      url: url.pathname + url.search,
      headers: Object.fromEntries(request.headers),       // Headers object -> plain object, lower-case names
      bodyText: ["POST", "PATCH"].includes(request.method) ? await request.text() : "",
    });
    context.log(`${request.method} ${url.pathname} -> ${result.status}`);
    return { status: result.status, headers: result.headers, body: result.body || undefined };
  },
});
