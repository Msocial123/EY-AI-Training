// All configuration of the app in ONE place. Components import `config`, never import.meta.env directly.
// Vite REPLACES import.meta.env.* with the real values when it builds, so they are fixed per build.
const env = import.meta.env;

/** A value the app cannot work without: fail early with a clear message instead of strange bugs later. */
function required(name) {
  const value = env[name];
  if (value === undefined || value === "") {
    throw new Error(`Missing environment variable ${name}. Copy .env.example to .env and restart npm run dev.`);
  }
  return value;
}

export const config = Object.freeze({
  appName: env.VITE_APP_NAME || "BasketNow",
  apiBaseUrl: required("VITE_API_BASE_URL"),
  apiTimeoutMs: Number(env.VITE_API_TIMEOUT_MS) || 8000,      // every env value is a STRING: convert it
  authHeader: env.VITE_AUTH_HEADER || "Authorization",
  enableDevTools: env.VITE_ENABLE_DEV_TOOLS === "true",       // "false" is a truthy string, so compare
  mode: env.MODE,                                             // "development", "production" or --mode name
  isDev: env.DEV,                                             // true while running npm run dev
  isProd: env.PROD,                                           // true in npm run build
  version: __APP_VERSION__,                                   // from package.json, see vite.config.js
});
