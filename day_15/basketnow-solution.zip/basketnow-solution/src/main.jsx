import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App.jsx";
import ErrorBoundary from "./components/errors/ErrorBoundary";
import { AuthProvider } from "./context/AuthContext";
import { ShopProvider } from "./context/ShopContext";
import { CartProvider } from "./context/CartContext";
import { logger } from "./utils/logger";
import "./styles.css";

// Errors in async code (promises) are NOT caught by ErrorBoundary: log them so they are never silent
window.addEventListener("unhandledrejection", (event) => logger.error("Unhandled promise rejection:", event.reason));

// BrowserRouter gives every component the current URL (useParams, useNavigate, <Link>...).
// AuthProvider is outside ShopProvider because the shop loads the orders OF the logged-in user.
createRoot(document.getElementById("root")).render(
  <StrictMode>
    {/* Last line of defence: if anything outside the pages crashes, show a fallback for the whole app */}
    <ErrorBoundary>
      <BrowserRouter>
        <AuthProvider>
          <ShopProvider>
            <CartProvider>
              <App />
            </CartProvider>
          </ShopProvider>
        </AuthProvider>
      </BrowserRouter>
    </ErrorBoundary>
  </StrictMode>
);
