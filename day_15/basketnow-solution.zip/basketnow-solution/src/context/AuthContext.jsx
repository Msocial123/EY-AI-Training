import { createContext, useCallback, useContext, useDebugValue, useEffect, useState } from "react";
import { logger } from "../utils/logger";
import * as authApi from "../api/authApi";
import { setAuthToken, setUnauthorizedHandler } from "../api/client";
import { SESSION_KEY, clearSession, readSession, saveSession } from "../utils/session";

const AuthContext = createContext(null);

/**
 * The user session, shared with the whole app.
 * status:    "checking" (reading the saved session) | "authenticated" | "anonymous"
 * endReason: why the last session ended - "logout", "expired" or "other-tab" (the login page explains it)
 */
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [status, setStatus] = useState("checking");
  const [expiresAt, setExpiresAt] = useState(null);
  const [remember, setRemember] = useState(false);
  const [endReason, setEndReason] = useState("");

  /** One place that ends a session, whatever the reason. useCallback: the same function on every render. */
  const endSession = useCallback((reason) => {
    logger.debug("session ended:", reason);
    clearSession();
    setAuthToken(null);
    setUser(null);
    setExpiresAt(null);
    setStatus("anonymous");
    setEndReason(reason);
  }, []);

  // 1. On start: restore the saved session and ask the server if the token is still valid
  useEffect(() => {
    const saved = readSession();
    if (!saved) {
      setStatus("anonymous");
      return;
    }
    if (saved.expiresAt <= Date.now()) {                 // expired while the app was closed
      endSession("expired");
      return;
    }
    setAuthToken(saved.token);
    setRemember(saved.remember);
    const controller = new AbortController();
    authApi.fetchMe({ signal: controller.signal })
      .then(({ user: me, expiresAt: exp }) => {
        setUser(me);
        setExpiresAt(exp);
        setStatus("authenticated");
      })
      .catch((err) => {
        if (err.code !== "CANCELLED") endSession("expired");
      });
    return () => controller.abort();
  }, [endSession]);

  // 2. The API answered 401 to a logged-in request (token expired or revoked): end the session
  useEffect(() => {
    setUnauthorizedHandler(() => endSession("expired"));
    return () => setUnauthorizedHandler(null);
  }, [endSession]);

  // 3. Log out automatically at the exact moment the token expires
  useEffect(() => {
    if (status !== "authenticated" || !expiresAt) return;
    const timer = setTimeout(() => endSession("expired"), expiresAt - Date.now());
    return () => clearTimeout(timer);
  }, [status, expiresAt, endSession]);

  // 4. Logged out in ANOTHER tab? The "storage" event fires in every other tab of the same site.
  useEffect(() => {
    function onStorage(event) {
      if (event.key === SESSION_KEY && event.newValue === null && status === "authenticated") endSession("other-tab");
    }
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, [status, endSession]);

  async function login(email, password, rememberMe) {
    const { token, user: me, expiresAt: exp } = await authApi.login(email, password); // throws ApiError
    saveSession({ token, expiresAt: exp, remember: rememberMe });
    setAuthToken(token);
    setUser(me);
    setExpiresAt(exp);
    setRemember(rememberMe);
    setEndReason("");
    setStatus("authenticated");
    logger.debug("logged in as", me.email, "remember me:", rememberMe);
    return me;
  }

  async function logout() {
    await authApi.logout().catch(() => {});             // revoke on the server; log out locally anyway
    endSession("logout");
  }

  /** Ask the server if the session is still valid. A 401 ends the session through the handler above. */
  async function checkSession() {
    const { expiresAt: exp } = await authApi.fetchMe();
    setExpiresAt(exp);
  }

  /** Developer test: replace the token with a broken one. The next API call gets 401. */
  function breakTokenForTesting() {
    setAuthToken("broken.token");
  }

  const value = {
    user, status, expiresAt, remember, endReason,
    isAuthenticated: status === "authenticated",
    isAdmin: user?.role === "admin",
    login, logout, checkSession, breakTokenForTesting,
  };
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

/** Read the session anywhere: const { user, isAuthenticated, login, logout } = useAuth(); */
export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth() must be used inside <AuthProvider>");
  // Label shown next to this hook in React DevTools -> Components (only a debugging aid)
  useDebugValue(context.user ? `${context.user.name} (${context.user.role})` : context.status);
  return context;
}
