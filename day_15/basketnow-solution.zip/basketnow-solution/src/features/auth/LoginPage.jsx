import { useState } from "react";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import TextField from "../../components/ui/TextField";
import Button from "../../components/ui/Button";
import { useForm } from "../../hooks/useForm";
import { useAuth } from "../../context/AuthContext";
import { friendlyMessage } from "../../api/client";
import { validateLogin } from "../../utils/validation";

const END_MESSAGES = {
  expired: "Your session has expired. Please log in again.",
  "other-tab": "You were logged out in another tab.",
};

const DEMO_ACCOUNTS = [
  { label: "Customer: Priya", email: "priya@basketnow.in", password: "Priya@123" },
  { label: "Customer: Ravi", email: "ravi@basketnow.in", password: "Ravi@123" },
  { label: "Store manager", email: "admin@basketnow.in", password: "Admin@123" },
];

/** /login - shown inside AuthLayout. After login, go back to the page the user wanted (state.from). */
function LoginPage() {
  const { login, isAuthenticated, endReason } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from ?? "/";            // set by ProtectedRoute
  const [failure, setFailure] = useState("");

  const form = useForm({
    initialValues: { email: "", password: "", remember: true },
    validate: validateLogin,
    onSubmit: async ({ email, password, remember }, { setServerErrors }) => {
      setFailure("");
      try {
        await login(email.trim().toLowerCase(), password, remember);
        navigate(from, { replace: true });             // replace: Back does not return to the login form
      } catch (err) {
        if (err.fields) setServerErrors(err.fields);
        setFailure(friendlyMessage(err));              // 401: "Email or password is incorrect"
      }
    },
  });

  // Already logged in (e.g. opened /login from a bookmark): nothing to do here
  if (isAuthenticated && !form.submitting) return <Navigate to={from} replace />;

  const field = (name) => ({
    name,
    value: form.values[name],
    onChange: form.handleChange,
    onBlur: form.handleBlur,
    error: form.errorFor(name),
  });

  function fillDemo(account) {
    form.setValue("email", account.email);
    form.setValue("password", account.password);
  }

  return (
    <>
      <h1>Log in</h1>
      <p className="muted">Log in to place orders and follow your deliveries.</p>
      {END_MESSAGES[endReason] && !failure && <p className="session-banner" role="status">{END_MESSAGES[endReason]}</p>}
      {failure && <p className="error-banner" role="alert">{failure}</p>}
      <form ref={form.formRef} onSubmit={form.handleSubmit} noValidate>
        <TextField label="Email" type="email" autoComplete="username" {...field("email")} />
        <TextField label="Password" type="password" autoComplete="current-password" {...field("password")} />
        <label className="toggle remember-row">
          <input type="checkbox" name="remember" checked={form.values.remember} onChange={form.handleChange} />
          Remember me on this device
        </label>
        <Button type="submit" size="lg" fullWidth isLoading={form.submitting}>
          {form.submitting ? "Logging in..." : "Log in"}
        </Button>
      </form>
      <div className="demo-accounts">
        <b>Demo accounts</b> (click to fill the form)
        <div className="row">
          {DEMO_ACCOUNTS.map((account) => (
            <Button key={account.email} variant="secondary" size="sm" onClick={() => fillDemo(account)}>
              {account.label}
            </Button>
          ))}
        </div>
      </div>
    </>
  );
}

export default LoginPage;
