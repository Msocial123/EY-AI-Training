import { useNavigate } from "react-router-dom";
import PageHeader from "../../components/layout/PageHeader";
import Badge from "../../components/ui/Badge";
import Button from "../../components/ui/Button";
import CrashTest from "../../components/errors/CrashTest";
import { useAuth } from "../../context/AuthContext";
import { useShop } from "../../context/ShopContext";
import { useNow } from "../../hooks/useNow";
import { formatDateTime, pluralize } from "../../utils/format";
import { config } from "../../config/env";

/** "12 min 05 s" from a number of seconds */
function formatCountdown(seconds) {
  const s = Math.max(0, Math.round(seconds));
  return `${Math.floor(s / 60)} min ${String(s % 60).padStart(2, "0")} s`;
}

/** /account - who is logged in and how the session is kept. */
function AccountPage() {
  const { user, expiresAt, remember, logout, checkSession, breakTokenForTesting } = useAuth();
  const { orders } = useShop();
  const navigate = useNavigate();
  const now = useNow(1000);                            // re-render every second for the countdown

  async function handleLogout() {
    await logout();
    navigate("/");
  }

  return (
    <section>
      <PageHeader
        title="My account"
        subtitle="Your profile and your login session"
        actions={<Button variant="secondary" size="sm" onClick={handleLogout}>Log out</Button>}
      />
      <div className="account-grid">
        <div className="panel">
          <h2>Profile</h2>
          <dl className="kv">
            <dt>Name</dt><dd>{user.name}</dd>
            <dt>Email</dt><dd>{user.email}</dd>
            <dt>Role</dt><dd><Badge tone={user.role === "admin" ? "blue" : "green"}>{user.role}</Badge></dd>
            <dt>Orders</dt><dd>{pluralize(orders.length, "order")}</dd>
          </dl>
        </div>
        <div className="panel">
          <h2>Session</h2>
          <dl className="kv">
            <dt>Kept in</dt><dd>{remember ? "localStorage (remember me)" : "sessionStorage (this tab only)"}</dd>
            <dt>Expires at</dt><dd>{formatDateTime(expiresAt)}</dd>
            <dt>Time left</dt><dd>{formatCountdown((expiresAt - now) / 1000)}</dd>
          </dl>
        </div>
      </div>
      {config.enableDevTools && (
        <div className="panel">
          <h2>Developer tests</h2>
          <p className="muted">Break the token, then check the session: the API answers 401 and the app logs you out.
            Crash this page: the ErrorBoundary shows a fallback instead of a white screen.</p>
          <div className="row">
            <Button variant="secondary" size="sm" onClick={breakTokenForTesting}>Break my token</Button>
            <Button variant="secondary" size="sm" onClick={() => checkSession().catch(() => {})}>Check my session</Button>
            <CrashTest />
          </div>
        </div>
      )}
    </section>
  );
}

export default AccountPage;
