import { http } from "./client";

// Service functions for authentication. Components and AuthContext never write "/auth/..." URLs.

/** POST /api/auth/login { email, password } -> { token, expiresAt, user }. 401 if the password is wrong. */
export async function login(email, password) {
  const { data } = await http.post("/auth/login", { email, password });
  return data;
}

/** GET /api/auth/me -> { user, expiresAt }. Uses the token set with setAuthToken(); 401 if it is not valid. */
export async function fetchMe({ signal } = {}) {
  const { data } = await http.get("/auth/me", { signal });
  return data;
}

/** POST /api/auth/logout -> 204. The server revokes the token, so it can never be used again. */
export async function logout() {
  await http.post("/auth/logout");
}
