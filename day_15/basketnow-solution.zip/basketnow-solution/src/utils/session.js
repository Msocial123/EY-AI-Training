// Where the login session is kept in the browser.
//   "Remember me" ON  -> localStorage   : survives closing the browser
//   "Remember me" OFF -> sessionStorage : deleted when the tab is closed
// session = { token, expiresAt, remember }
export const SESSION_KEY = "bn-session";

export function saveSession(session) {
  clearSession();                                          // never keep two copies
  const store = session.remember ? localStorage : sessionStorage;
  store.setItem(SESSION_KEY, JSON.stringify(session));
}

export function readSession() {
  const text = sessionStorage.getItem(SESSION_KEY) ?? localStorage.getItem(SESSION_KEY);
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch {
    return null;                                           // broken data = no session
  }
}

export function clearSession() {
  localStorage.removeItem(SESSION_KEY);
  sessionStorage.removeItem(SESSION_KEY);
}
