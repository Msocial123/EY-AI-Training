import { config } from "../config/env";

// A small logger for the whole app.
//  - debug / api logs appear only in development (no noise for real customers)
//  - warnings and errors always appear
// In production a company also sends errors to a monitoring service (Azure Application Insights, Sentry...).
const STYLE = "color:#0c831f;font-weight:bold";

export const logger = {
  debug(...args) {
    if (config.isDev) console.debug("%c[BasketNow]", STYLE, ...args);
  },
  warn(...args) {
    console.warn("[BasketNow]", ...args);
  },
  error(...args) {
    console.error("[BasketNow]", ...args);
  },
  /** One collapsible line per API call: click it in the Console to see the data. */
  api(method, url, status, ms, data) {
    if (!config.isDev) return;
    const color = status >= 400 || status === 0 ? "color:#d93025;font-weight:bold" : STYLE;
    console.groupCollapsed(`%c[api] ${method.toUpperCase()} ${url} -> ${status} (${ms} ms)`, color);
    console.log("data:", data);
    console.groupEnd();
  },
};
