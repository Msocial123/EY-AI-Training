import { Link, Outlet } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import EmptyState from "../ui/EmptyState";

/**
 * Role guard, used INSIDE ProtectedRoute (so a user is already logged in).
 * Authentication = who are you? Authorization = what are you allowed to do?
 * The server checks the role again on every admin API call - this guard only protects the screen.
 */
function RequireRole({ role }) {
  const { user } = useAuth();
  if (user.role !== role) {
    return (
      <EmptyState
        icon="⛔"
        tone="error"
        title="Access denied"
        message={`This page is only for the ${role} role. You are logged in as ${user.name} (${user.role}).`}
        action={<Link className="btn btn-primary btn-md" to="/">Go to the shop</Link>}
      />
    );
  }
  return <Outlet />;
}

export default RequireRole;
