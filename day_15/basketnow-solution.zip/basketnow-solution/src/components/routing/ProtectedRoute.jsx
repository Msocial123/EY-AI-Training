import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import LoadingState from "../ui/LoadingState";

/**
 * Route guard used as a layout route: <Route element={<ProtectedRoute />}> ...private pages... </Route>
 * - still checking the saved session -> wait
 * - nobody logged in -> go to /login and remember where the user wanted to go
 * - logged in -> show the page (<Outlet />)
 */
function ProtectedRoute() {
  const { status } = useAuth();
  const location = useLocation();

  if (status === "checking") return <LoadingState text="Checking your session..." />;
  if (status === "anonymous") {
    return <Navigate to="/login" replace state={{ from: location.pathname + location.search }} />;
  }
  return <Outlet />;
}

export default ProtectedRoute;
