/** A round loading indicator. `size` "sm" or "md". `label` is read by screen readers only. */
function Spinner({ size = "md", label = "Loading" }) {
  return <span className={size === "sm" ? "loader loader-sm" : "loader"} role="status" aria-label={label} />;
}

export default Spinner;
