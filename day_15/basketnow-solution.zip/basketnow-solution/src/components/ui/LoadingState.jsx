import Spinner from "./Spinner";

/**
 * Standard "please wait" block used by every page: a spinner and a short text.
 * fullPage: centre it on the screen (first app start, lazy pages).
 */
function LoadingState({ text = "Loading...", fullPage = false }) {
  return (
    <div className={fullPage ? "loading-state full" : "loading-state"}>
      <Spinner label={text} />
      <p>{text}</p>
    </div>
  );
}

export default LoadingState;
