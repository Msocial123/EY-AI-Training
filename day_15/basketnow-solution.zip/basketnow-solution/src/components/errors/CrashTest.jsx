import { useState } from "react";
import Button from "../ui/Button";

function Bomb() {
  throw new Error("Test crash: this component failed while rendering");
}

/** Developer tool: renders a component that throws, to see the ErrorBoundary catch it. */
function CrashTest() {
  const [crash, setCrash] = useState(false);
  return (
    <>
      <Button variant="danger" size="sm" onClick={() => setCrash(true)}>Crash this page</Button>
      {crash && <Bomb />}
    </>
  );
}

export default CrashTest;
