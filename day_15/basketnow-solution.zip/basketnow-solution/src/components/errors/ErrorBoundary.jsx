import { Component } from "react";
import Button from "../ui/Button";
import { config } from "../../config/env";
import { logger } from "../../utils/logger";

/**
 * Catches errors thrown while RENDERING its children (a bug in a component) and shows a fallback
 * instead of a blank white page. Only a class component can do this (getDerivedStateFromError).
 * It does NOT catch errors in event handlers, timers or async code: those need try/catch.
 * resetKey: when it changes (e.g. the URL), the boundary tries to render the children again.
 */
class ErrorBoundary extends Component {
  state = { error: null };

  static getDerivedStateFromError(error) {
    return { error };                                   // the next render shows the fallback
  }

  componentDidCatch(error, info) {
    // componentStack = which components were rendering: the fastest clue when debugging
    logger.error("UI crashed:", error.message, info.componentStack);
  }

  componentDidUpdate(prevProps) {
    if (this.state.error && prevProps.resetKey !== this.props.resetKey) this.setState({ error: null });
  }

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div className="error-fallback" role="alert">
        <h2>Something went wrong on this page</h2>
        <p className="muted">The rest of BasketNow still works. Try again, or go back to the shop.</p>
        {config.isDev && <pre>{String(this.state.error.stack ?? this.state.error)}</pre>}
        <div className="row">
          <Button onClick={() => this.setState({ error: null })}>Try again</Button>
          <a className="btn btn-secondary btn-md" href="/">Go to the shop</a>
        </div>
      </div>
    );
  }
}

export default ErrorBoundary;
