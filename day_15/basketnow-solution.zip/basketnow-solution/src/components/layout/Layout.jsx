import { Suspense, useEffect } from "react";
import { Outlet, useLocation } from "react-router-dom";
import Header from "./Header";
import Footer from "./Footer";
import CartDrawer from "../../features/cart/CartDrawer";
import { useCart } from "../../context/CartContext";
import ErrorBoundary from "../errors/ErrorBoundary";
import LoadingState from "../ui/LoadingState";
import { useOnlineStatus } from "../../hooks/useOnlineStatus";

/** The frame around every page. <Outlet /> is where the page of the current URL is drawn. */
function Layout() {
  const { pathname } = useLocation();
  const { closeCart } = useCart();
  const isOnline = useOnlineStatus();

  // A new page: scroll to the top and close the cart drawer
  useEffect(() => {
    window.scrollTo(0, 0);
    closeCart();
  }, [pathname]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="app">
      {!isOnline && <p className="offline-banner" role="alert">You are offline. Changes will fail until the connection is back.</p>}
      <Header />
      <main className="main">
        {/* A crash inside one page shows a fallback; header, cart and footer keep working */}
        <ErrorBoundary resetKey={pathname}>
          {/* Suspense shows the fallback while a lazy page is being downloaded */}
          <Suspense fallback={<LoadingState text="Loading page..." />}>
            <Outlet />
          </Suspense>
        </ErrorBoundary>
      </main>
      <CartDrawer />
      <Footer />
    </div>
  );
}

export default Layout;
