import { Suspense } from "react";
import { Link, Outlet } from "react-router-dom";
import LoadingState from "../ui/LoadingState";

/**
 * Second layout of the app: a centred card with only the logo, used by the login page.
 * Different pages can share different frames - each layout route renders its pages in <Outlet />.
 */
function AuthLayout() {
  return (
    <div className="auth-layout">
      <Link className="logo" to="/" aria-label="BasketNow home">
        basket<span>now</span>
      </Link>
      <div className="auth-card">
        <Suspense fallback={<LoadingState text="Loading..." />}>
          <Outlet />
        </Suspense>
      </div>
      <p className="auth-foot">Groceries in 15 minutes · Hyderabad · Kadapa · Nellore · Vizag</p>
    </div>
  );
}

export default AuthLayout;
