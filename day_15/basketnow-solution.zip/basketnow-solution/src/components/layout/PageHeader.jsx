/**
 * The same title area on every page: a title, an optional subtitle and optional action buttons.
 * Composition: the page decides WHAT goes in `actions`, PageHeader decides WHERE it goes.
 */
function PageHeader({ title, subtitle, actions }) {
  return (
    <div className="page-header">
      <div>
        <h1>{title}</h1>
        {subtitle && <p>{subtitle}</p>}
      </div>
      {actions && <div className="page-actions">{actions}</div>}
    </div>
  );
}

export default PageHeader;
