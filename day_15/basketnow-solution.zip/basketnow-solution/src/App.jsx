import { lazy } from "react";
import { Route, Routes } from "react-router-dom";
import Layout from "./components/layout/Layout";
import AuthLayout from "./components/layout/AuthLayout";
import ProtectedRoute from "./components/routing/ProtectedRoute";
import RequireRole from "./components/routing/RequireRole";
import NotFoundPage from "./components/layout/NotFoundPage";
import CatalogPage from "./features/catalog/CatalogPage";
import ProductPage from "./features/catalog/ProductPage";

// CODE SPLITTING: these pages are downloaded only when someone opens them.
// The shop (catalogue + product page) stays in the main bundle because almost every visit starts there.
const CheckoutPage = lazy(() => import("./features/checkout/CheckoutPage"));
const OrderTrackerPage = lazy(() => import("./features/orders/OrderTrackerPage"));
const OrdersPage = lazy(() => import("./features/orders/OrdersPage"));
const InventoryPage = lazy(() => import("./features/admin/InventoryPage"));
const LoginPage = lazy(() => import("./features/auth/LoginPage"));
const AccountPage = lazy(() => import("./features/account/AccountPage"));

/**
 * The site map. Two layouts (AuthLayout for /login, Layout for the shop) and two guards:
 * ProtectedRoute (must be logged in) and RequireRole (must have the admin role).
 */
function App() {
  return (
    <Routes>
      <Route element={<AuthLayout />}>
        <Route path="/login" element={<LoginPage />} />
      </Route>

      <Route element={<Layout />}>
        {/* Public pages */}
        <Route path="/" element={<CatalogPage />} />
        <Route path="/product/:productId" element={<ProductPage />} />

        {/* Logged-in users only */}
        <Route element={<ProtectedRoute />}>
          <Route path="/checkout" element={<CheckoutPage />} />
          <Route path="/orders" element={<OrdersPage />} />
          <Route path="/orders/:orderId" element={<OrderTrackerPage />} />
          <Route path="/account" element={<AccountPage />} />

          {/* Logged in AND role "admin" */}
          <Route element={<RequireRole role="admin" />}>
            <Route path="/admin" element={<InventoryPage />} />
          </Route>
        </Route>

        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  );
}

export default App;
