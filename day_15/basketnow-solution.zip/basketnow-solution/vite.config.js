import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";
import { mockApi } from "./mock-server/mockApi.js";

// defineConfig can take a FUNCTION: Vite passes the mode ("development" for dev, "production" for build).
export default defineConfig(({ mode }) => {
  // loadEnv reads .env, .env.local, .env.[mode], .env.[mode].local. Prefix "" = load ALL variables.
  const env = loadEnv(mode, process.cwd(), "");

  // Server-side settings for the mock API. They go to process.env (Node), NOT to the browser.
  for (const key of ["AUTH_SECRET", "AUTH_TOKEN_TTL_SECONDS"]) {
    if (env[key]) process.env[key] = env[key];
  }

  return {
    plugins: [react(), mockApi()],
    // define: replace the word __APP_VERSION__ in the code with the version from package.json
    define: { __APP_VERSION__: JSON.stringify(process.env.npm_package_version ?? "0.0.0") },
    server: { port: 5173, open: true },
    preview: { port: 4173 },
    build: {
      // Source maps let DevTools show your original code; skip them in production (smaller, code not exposed)
      sourcemap: mode !== "production",
      chunkSizeWarningLimit: 400,                         // warn if one JavaScript file is bigger than 400 kB
      rollupOptions: {
        output: {
          // Libraries change rarely: separate files stay cached in the browser between our releases
          manualChunks: {
            react: ["react", "react-dom"],
            router: ["react-router-dom"],
            http: ["axios"],
          },
        },
      },
    },
  };
});
