// Vite plugin: runs the BasketNow REST API (mock-server/server.js) inside the dev server AND the preview server,
// so `npm run dev` and `npm run preview` serve the React app and http://localhost:<port>/api/... together.
import { handleRequest } from "./server.js";

function readBody(req) {
  return new Promise((resolve) => {
    let text = "";
    req.on("data", (chunk) => (text += chunk));
    req.on("end", () => resolve(text));
  });
}

/** Node/Connect middleware: Node request -> handleRequest() -> Node response. */
export async function handleApi(req, res, next) {
  if (!req.url.startsWith("/api/")) return next();
  const started = Date.now();
  const bodyText = ["POST", "PATCH"].includes(req.method) ? await readBody(req) : "";
  const result = await handleRequest({ method: req.method, url: req.url, headers: req.headers, bodyText });
  res.statusCode = result.status;
  Object.entries(result.headers).forEach(([name, value]) => res.setHeader(name, value));
  res.end(result.body);
  console.log(`[api] ${req.method} ${req.url} -> ${result.status} (${Date.now() - started} ms)`);
}

export function mockApi() {
  return {
    name: "basketnow-mock-api",
    configureServer(server) {
      server.middlewares.use(handleApi);
    },
    configurePreviewServer(server) {
      server.middlewares.use(handleApi);
    },
  };
}
