// BasketNow REST API - the server logic, independent of any web framework.
// Locally it runs inside Vite (mock-server/mockApi.js). On Azure it runs as an Azure Function (api/).
// Data lives in memory: restarting the server (or POST /api/reset) brings back the original catalogue.
//
//   POST   /api/auth/login               { email, password } -> { token, expiresAt, user }   200 / 400 / 401
//   GET    /api/auth/me                  who am I? (needs a token)                            200 / 401
//   POST   /api/auth/logout              revoke the token                                     204 / 401
//   GET    /api/products                 all products (public)
//   GET    /api/products/:id             one product (public)                                 404 if unknown
//   POST   /api/products                 add a product           ADMIN                        201 / 400 / 401 / 403
//   DELETE /api/products/:id             delete a product        ADMIN                        204 / 404
//   PATCH  /api/variants/:id             change stock { stock }  ADMIN                        200 / 400 / 404
//   GET    /api/pincodes/:pincode        can we deliver here? (public)                        200 / 400
//   GET    /api/orders                   my orders (admin: all)  LOGGED IN                    200 / 401
//   GET    /api/orders/:id               one of my orders        LOGGED IN                    404 if not mine
//   POST   /api/orders                   place an order          LOGGED IN                    201 / 400 / 409
//   PATCH  /api/orders/:id/cancel        cancel before "Out for delivery"                     200 / 404 / 409
//   POST   /api/reset                    restore the original demo data
//
// The token travels in "Authorization: Bearer <token>" or in "X-Auth-Token: Bearer <token>"
// (Azure Static Web Apps replaces the Authorization header, so production uses X-Auth-Token).
// Developer headers: "X-Simulate-Error: 1" -> 503, "X-Simulate-Delay: 2000" -> extra wait in ms.
// Demo accounts: priya@basketnow.in / Priya@123, ravi@basketnow.in / Ravi@123, admin@basketnow.in / Admin@123

import { createHmac, timingSafeEqual } from "node:crypto";
import { SEED_PRODUCTS } from "../src/data/products.js";
import { COUPONS } from "../src/data/coupons.js";
import {
  CANCELLABLE_UNTIL, COD_LIMIT, DELIVERY_FEE, DELIVERY_SLOTS, FREE_DELIVERY_THRESHOLD, HANDLING_FEE,
  PAYMENT_METHODS, SERVICEABLE_PREFIXES, TRACKING_STEPS,
} from "../src/data/config.js";

// ---------------------------------------------------------------- in-memory database
const db = { products: [], orders: [], ordersByKey: new Map(), nextOrderNo: 10001, revokedTokens: new Set() };

// Demo accounts. A real server keeps users in a database and stores only password HASHES (bcrypt/argon2).
const USERS = [
  { id: "u1", name: "Priya Sharma", email: "priya@basketnow.in", password: "Priya@123", role: "customer" },
  { id: "u2", name: "Ravi Kumar", email: "ravi@basketnow.in", password: "Ravi@123", role: "customer" },
  { id: "u9", name: "Store Manager", email: "admin@basketnow.in", password: "Admin@123", role: "admin" },
];

// Server-side configuration from environment variables (never sent to the browser).
// Read when needed (not at import time), so vite.config.js can set them first.
const env = (typeof process !== "undefined" && process.env) || {};
const authSecret = () => env.AUTH_SECRET || "basketnow-dev-secret-change-me";
const tokenTtlSeconds = () => Number(env.AUTH_TOKEN_TTL_SECONDS) || 30 * 60;

function resetDb() {
  db.products = JSON.parse(JSON.stringify(SEED_PRODUCTS)); // deep copy of the seed catalogue
  db.orders = [];
  db.ordersByKey = new Map();
  db.nextOrderNo = 10001;
  db.revokedTokens = new Set();
}
resetDb();

// ---------------------------------------------------------------- helpers
const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/** Every handler RETURNS { status, body }. The adapters (Vite dev server, Azure Functions) turn it into HTTP. */
function send(status, body) {
  return { status, body };
}

function sendError(status, code, message, extra = {}) {
  return send(status, { error: { code, message, ...extra } });
}

// ---------------------------------------------------------------- auth: signed tokens (JWT-like)
const base64url = (text) => Buffer.from(text).toString("base64url");
const sign = (data) => createHmac("sha256", authSecret()).update(data).digest("base64url");
const publicUser = ({ id, name, email, role }) => ({ id, name, email, role });

/** token = base64url(payload) + "." + signature. The payload is readable, the signature makes it tamper-proof. */
function createToken(user) {
  const payload = { sub: user.id, role: user.role, name: user.name, exp: Math.floor(Date.now() / 1000) + tokenTtlSeconds() };
  const data = base64url(JSON.stringify(payload));
  return { token: `${data}.${sign(data)}`, expiresAt: payload.exp * 1000 };
}

/** Returns { user, expiresAt } or { error: response } */
function authenticate(headers) {
  const raw = headers["x-auth-token"] || headers.authorization || "";
  const token = raw.replace(/^Bearer\s+/i, "");
  if (!token) return { error: sendError(401, "UNAUTHENTICATED", "Please log in to continue") };
  const [data, signature = ""] = token.split(".");
  const expected = sign(data);
  const valid = signature.length === expected.length && timingSafeEqual(Buffer.from(signature), Buffer.from(expected));
  if (!valid || db.revokedTokens.has(token)) return { error: sendError(401, "INVALID_TOKEN", "Your session is not valid. Please log in again") };
  const payload = JSON.parse(Buffer.from(data, "base64url").toString());
  if (payload.exp * 1000 < Date.now()) return { error: sendError(401, "TOKEN_EXPIRED", "Your session has expired. Please log in again") };
  const user = USERS.find((u) => u.id === payload.sub);
  if (!user) return { error: sendError(401, "INVALID_TOKEN", "Your session is not valid. Please log in again") };
  return { user: publicUser(user), expiresAt: payload.exp * 1000, token };
}

/** Wrap a route handler: only logged-in users (and optionally only some roles) get through. */
const requireAuth = (handler, roles) => (req) => {
  const auth = authenticate(req.headers);
  if (auth.error) return auth.error;
  if (roles && !roles.includes(auth.user.role)) return sendError(403, "FORBIDDEN", "You do not have permission to do this");
  return handler({ ...req, auth });
};

function findVariant(variantId) {
  for (const product of db.products) {
    const variant = product.variants.find((v) => v.id === variantId);
    if (variant) return { product, variant };
  }
  return null;
}

function trackingOf(order) {
  if (order.cancelledAt) return { stepIndex: -1, canCancel: false, label: "Cancelled" };
  const elapsed = (Date.now() - order.createdAt) / 1000;
  let stepIndex = 0;
  TRACKING_STEPS.forEach((step, i) => { if (elapsed >= step.at) stepIndex = i; });
  const limit = TRACKING_STEPS.findIndex((s) => s.id === CANCELLABLE_UNTIL);
  return { stepIndex, canCancel: stepIndex < limit, label: TRACKING_STEPS[stepIndex].label };
}

// ---------------------------------------------------------------- business rules (server copy)
function couponCheck(coupon, lines, itemTotal, hasPreviousOrders) {
  if (coupon.firstOrderOnly && hasPreviousOrders) return { ok: false, reason: "Valid on your first order only" };
  if (itemTotal < coupon.minOrder) return { ok: false, reason: `Add items worth ₹${coupon.minOrder - itemTotal} more to use this` };
  const eligible = coupon.category
    ? lines.filter((l) => l.category === coupon.category).reduce((s, l) => s + l.price * l.qty, 0)
    : itemTotal;
  if (eligible === 0) return { ok: false, reason: `Add ${coupon.category} items to use this` };
  let discount = coupon.type === "flat" ? coupon.value : Math.round((eligible * coupon.value) / 100);
  if (coupon.maxDiscount) discount = Math.min(discount, coupon.maxDiscount);
  return { ok: true, discount: Math.min(discount, eligible) };
}

function billFor(lines, couponCode, slotFee, userId) {
  const itemCount = lines.reduce((s, l) => s + l.qty, 0);
  const itemTotal = lines.reduce((s, l) => s + l.price * l.qty, 0);
  const mrpTotal = lines.reduce((s, l) => s + l.mrp * l.qty, 0);
  const hasPreviousOrders = db.orders.some((o) => o.userId === userId && !o.cancelledAt);
  const coupon = COUPONS.find((c) => c.code === couponCode);
  const couponResult = coupon ? couponCheck(coupon, lines, itemTotal, hasPreviousOrders) : null;
  const couponDiscount = couponResult?.ok ? couponResult.discount : 0;
  const deliveryFee = itemTotal >= FREE_DELIVERY_THRESHOLD ? 0 : DELIVERY_FEE;
  return {
    itemCount, itemTotal, mrpTotal, productSavings: mrpTotal - itemTotal,
    couponResult, couponDiscount, deliveryFee, handlingFee: HANDLING_FEE, slotFee,
    grandTotal: itemTotal - couponDiscount + deliveryFee + HANDLING_FEE + slotFee,
    amountForFreeDelivery: Math.max(0, FREE_DELIVERY_THRESHOLD - itemTotal),
    totalSavings: mrpTotal - itemTotal + couponDiscount + (deliveryFee === 0 ? DELIVERY_FEE : 0),
  };
}

function validateOrder(body, grandTotal) {
  const errors = {};
  const a = body.address || {};
  const text = (v) => String(v ?? "").trim();
  if (text(a.fullName).length < 3) errors.fullName = "Enter your full name (at least 3 letters)";
  if (!/^[6-9]\d{9}$/.test(text(a.phone))) errors.phone = "Enter a valid 10-digit mobile number starting with 6-9";
  if (!text(a.house)) errors.house = "House / flat number is required";
  if (!text(a.area)) errors.area = "Area / street is required";
  if (!/^\d{6}$/.test(text(a.pincode))) errors.pincode = "Enter a valid 6-digit pincode";
  else if (!SERVICEABLE_PREFIXES[text(a.pincode).slice(0, 3)]) errors.pincode = "Sorry, we do not deliver to this pincode yet";
  if (!DELIVERY_SLOTS.some((s) => s.id === body.slotId)) errors.slotId = "Choose a delivery slot";
  if (!PAYMENT_METHODS.some((p) => p.id === body.paymentId)) errors.paymentId = "Choose a payment method";
  else if (body.paymentId === "upi" && !/^[\w.-]{2,}@[A-Za-z]{2,}$/.test(text(body.upiId))) errors.upiId = "Enter a valid UPI ID, for example priya@okaxis";
  else if (body.paymentId === "cod" && grandTotal > COD_LIMIT) errors.paymentId = `Cash on Delivery is available only up to ₹${COD_LIMIT}`;
  if (text(body.instructions).length > 120) errors.instructions = "Keep instructions under 120 characters";
  return errors;
}

function validateProduct(v) {
  const errors = {};
  const price = Number(v.price);
  const mrp = Number(v.mrp);
  const stock = Number(v.stock);
  if (String(v.name ?? "").trim().length < 3) errors.name = "Name must have at least 3 characters";
  if (!String(v.brand ?? "").trim()) errors.brand = "Brand is required";
  if (!String(v.variantLabel ?? "").trim()) errors.variantLabel = "Pack size is required, e.g. 500 g";
  if (!(price > 0)) errors.price = "Price must be greater than 0";
  if (!(mrp > 0)) errors.mrp = "MRP must be greater than 0";
  else if (mrp < price) errors.mrp = "MRP cannot be lower than the selling price";
  if (!Number.isInteger(stock) || stock < 0 || v.stock === "") errors.stock = "Stock must be a whole number, 0 or more";
  return errors;
}

// ---------------------------------------------------------------- routes
const routes = [
  // ---------- auth ----------
  ["POST", /^\/api\/auth\/login$/, ({ body }) => {
    const email = String(body.email ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");
    const fields = {};
    if (!/^\S+@\S+\.\S+$/.test(email)) fields.email = "Enter a valid email address";
    if (!password) fields.password = "Password is required";
    if (Object.keys(fields).length) return sendError(400, "VALIDATION_ERROR", "Please correct the highlighted fields", { fields });
    const user = USERS.find((u) => u.email === email && u.password === password);
    if (!user) return sendError(401, "INVALID_CREDENTIALS", "Email or password is incorrect");
    const { token, expiresAt } = createToken(user);
    return send(200, { token, expiresAt, user: publicUser(user) });
  }],

  ["GET", /^\/api\/auth\/me$/, requireAuth(({ auth }) => send(200, { user: auth.user, expiresAt: auth.expiresAt }))],

  ["POST", /^\/api\/auth\/logout$/, requireAuth(({ auth }) => {
    db.revokedTokens.add(auth.token);                       // this token can never be used again
    return send(204);
  })],

  ["GET", /^\/api\/products$/, ({ url }) => {
    const q = (url.searchParams.get("q") || "").trim().toLowerCase();
    const category = url.searchParams.get("category");
    const items = db.products
      .filter((p) => !q || `${p.name} ${p.brand} ${p.category}`.toLowerCase().includes(q))
      .filter((p) => !category || p.category === category);
    return send(200, items);
  }],

  ["GET", /^\/api\/products\/([^/]+)$/, ({ params }) => {
    const product = db.products.find((p) => p.id === params[0]);
    if (!product) return sendError(404, "PRODUCT_NOT_FOUND", `Product ${params[0]} does not exist`);
    return send(200, product);
  }],

  ["POST", /^\/api\/products$/, requireAuth(({ body }) => {
    const fields = validateProduct(body);
    if (Object.keys(fields).length) return sendError(400, "VALIDATION_ERROR", "Please correct the highlighted fields", { fields });
    const id = `p${Date.now()}`;
    const product = {
      id, name: body.name.trim(), brand: body.brand.trim(), category: body.category, image: body.image || "🛒",
      rating: 4.0, tags: ["new"],
      variants: [{ id: `${id}-v1`, label: body.variantLabel.trim(), price: Number(body.price), mrp: Number(body.mrp), stock: Number(body.stock) }],
    };
    db.products.unshift(product);
    return send(201, product);
  }, ["admin"])],

  ["DELETE", /^\/api\/products\/([^/]+)$/, requireAuth(({ params }) => {
    const before = db.products.length;
    db.products = db.products.filter((p) => p.id !== params[0]);
    if (db.products.length === before) return sendError(404, "PRODUCT_NOT_FOUND", `Product ${params[0]} does not exist`);
    return send(204);
  }, ["admin"])],

  ["PATCH", /^\/api\/variants\/([^/]+)$/, requireAuth(({ params, body }) => {
    const found = findVariant(params[0]);
    if (!found) return sendError(404, "VARIANT_NOT_FOUND", `Pack size ${params[0]} does not exist`);
    const stock = Number(body.stock);
    if (!Number.isInteger(stock) || stock < 0 || stock > 999) {
      return sendError(400, "VALIDATION_ERROR", "Stock must be a whole number from 0 to 999", { fields: { stock: "0 to 999" } });
    }
    found.variant.stock = stock;
    return send(200, { variantId: found.variant.id, stock });
  }, ["admin"])],

  ["GET", /^\/api\/pincodes\/([^/]+)$/, ({ params }) => {
    const pincode = params[0];
    if (!/^\d{6}$/.test(pincode)) return sendError(400, "INVALID_PINCODE", "Pincode must be exactly 6 digits");
    const city = SERVICEABLE_PREFIXES[pincode.slice(0, 3)] || null;
    return send(200, { pincode, serviceable: Boolean(city), city });
  }],

  // Customers see their own orders; the admin sees everything.
  ["GET", /^\/api\/orders$/, requireAuth(({ auth }) =>
    send(200, auth.user.role === "admin" ? db.orders : db.orders.filter((o) => o.userId === auth.user.id)))],

  ["GET", /^\/api\/orders\/([^/]+)$/, requireAuth(({ params, auth }) => {
    const order = db.orders.find((o) => o.id === params[0] && (o.userId === auth.user.id || auth.user.role === "admin"));
    if (!order) return sendError(404, "ORDER_NOT_FOUND", `Order ${params[0]} does not exist`);
    return send(200, order);
  })],

  ["POST", /^\/api\/orders$/, requireAuth(({ body, headers, auth }) => {
    const key = headers["idempotency-key"];
    if (key && db.ordersByKey.has(key)) return send(200, db.ordersByKey.get(key)); // same key -> same order

    // Build the lines with OUR prices. Prices sent by the browser are ignored.
    const lines = [];
    for (const item of Array.isArray(body.items) ? body.items : []) {
      const found = findVariant(item.variantId);
      if (!found || !Number.isInteger(item.qty) || item.qty < 1) {
        return sendError(400, "INVALID_ITEMS", "Your cart has items that no longer exist");
      }
      const { product, variant } = found;
      lines.push({ variantId: variant.id, productId: product.id, name: product.name, image: product.image,
        category: product.category, variantLabel: variant.label, price: variant.price, mrp: variant.mrp, qty: item.qty });
    }
    if (lines.length === 0) return sendError(400, "EMPTY_CART", "Your cart is empty");

    const slot = DELIVERY_SLOTS.find((s) => s.id === body.slotId);
    const bill = billFor(lines, body.couponCode, slot ? slot.fee : 0, auth.user.id);
    const fields = validateOrder(body, bill.grandTotal);
    if (Object.keys(fields).length) return sendError(400, "VALIDATION_ERROR", "Please correct the highlighted fields", { fields });

    const soldOut = lines
      .map((l) => ({ variantId: l.variantId, name: l.name, requested: l.qty, available: findVariant(l.variantId).variant.stock }))
      .filter((l) => l.requested > l.available);
    if (soldOut.length) return sendError(409, "OUT_OF_STOCK", "Some items just went out of stock", { items: soldOut });

    lines.forEach((l) => { findVariant(l.variantId).variant.stock -= l.qty; }); // reserve stock
    const a = body.address;
    const order = {
      id: `BN${db.nextOrderNo++}`,
      userId: auth.user.id,
      createdAt: Date.now(),
      lines: lines.map(({ variantId, productId, name, image, variantLabel, price, qty }) => ({ variantId, productId, name, image, variantLabel, price, qty })),
      bill,
      couponCode: bill.couponDiscount > 0 ? body.couponCode : "",
      address: { fullName: a.fullName.trim(), phone: a.phone.trim(), house: a.house.trim(), area: a.area.trim(), landmark: (a.landmark || "").trim(), pincode: a.pincode.trim() },
      city: SERVICEABLE_PREFIXES[a.pincode.trim().slice(0, 3)],
      slotLabel: `${slot.label} · ${slot.detail}`,
      paymentLabel: PAYMENT_METHODS.find((p) => p.id === body.paymentId).label,
      instructions: String(body.instructions || "").trim(),
      cancelledAt: null,
    };
    db.orders.unshift(order);
    if (key) db.ordersByKey.set(key, order);
    return send(201, order);
  })],

  ["PATCH", /^\/api\/orders\/([^/]+)\/cancel$/, requireAuth(({ params, auth }) => {
    const order = db.orders.find((o) => o.id === params[0] && (o.userId === auth.user.id || auth.user.role === "admin"));
    if (!order) return sendError(404, "ORDER_NOT_FOUND", `Order ${params[0]} does not exist`);
    if (order.cancelledAt) return sendError(409, "CANNOT_CANCEL", "This order is already cancelled");
    const info = trackingOf(order);
    if (!info.canCancel) return sendError(409, "CANNOT_CANCEL", `This order is already "${info.label}" and cannot be cancelled`);
    order.cancelledAt = Date.now();
    order.lines.forEach((l) => { const found = findVariant(l.variantId); if (found) found.variant.stock += l.qty; }); // return stock
    return send(200, order);
  })],

  ["POST", /^\/api\/reset$/, (_req) => { resetDb(); return send(200, { ok: true }); }],
];


// ---------------------------------------------------------------- the framework-free request handler
/**
 * handleRequest({ method, url, headers, bodyText }) -> Promise<{ status, headers, body }>
 * `url` is the path + query (/api/orders?x=1). `headers` keys are lower-case. `body` is a string.
 * Used by the Vite dev/preview server (mock-server/mockApi.js) and by Azure Functions (api/).
 */
export async function handleRequest({ method, url: rawUrl, headers = {}, bodyText = "" }) {
  const url = new URL(rawUrl, "http://localhost");
  const reply = (result) => ({
    status: result.status,
    headers: { "Content-Type": "application/json; charset=utf-8", "X-Request-Id": headers["x-request-id"] || "-" },
    body: result.body === undefined ? "" : JSON.stringify(result.body),
  });

  const route = routes.find(([m, pattern]) => m === method && pattern.test(url.pathname));
  if (!route) return reply(sendError(404, "NOT_FOUND", `No API route for ${method} ${url.pathname}`));

  // Network-like behaviour: every call takes a moment; the catalogue takes a bit longer.
  const extra = Math.min(Number(headers["x-simulate-delay"]) || 0, 5000);
  await wait((url.pathname === "/api/products" ? 700 : 250) + extra);
  if (headers["x-simulate-error"] === "1" && url.pathname !== "/api/reset") {
    return reply(sendError(503, "SERVICE_UNAVAILABLE", "BasketNow is busy right now. Please try again."));
  }

  let body = {};
  if (["POST", "PATCH"].includes(method) && bodyText) {
    try { body = JSON.parse(bodyText); } catch { return reply(sendError(400, "BAD_JSON", "The request body is not valid JSON")); }
  }
  const params = url.pathname.match(route[1]).slice(1).map(decodeURIComponent);
  try {
    return reply(route[2]({ url, params, body, headers }));
  } catch (error) {
    console.error(error);
    return reply(sendError(500, "INTERNAL_ERROR", "Something went wrong on our side"));
  }
}
