/**
 * TODO BN-905 - Developer tool: a "Crash this page" button that renders a component which throws.
 */
function CrashTest() {
  return null;
}

export default CrashTest;
