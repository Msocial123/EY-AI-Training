/**
 * TODO BN-905 - ErrorBoundary: a CLASS component (getDerivedStateFromError + componentDidCatch).
 * Shows a fallback (CSS error-fallback) with "Try again" instead of a white page when a child crashes
 * while rendering. Prop resetKey: when it changes (the URL), render the children again.
 */
function ErrorBoundary({ children }) {
  return children;
}

export default ErrorBoundary;
