/**
 * TODO BN-901 / BN-903 - AuthLayout: the second layout of the app, used by /login.
 * A centred card: logo <Link to="/">, <div className="auth-card"> with <Outlet />, and a small footer text.
 * CSS: auth-layout, logo, auth-card, auth-foot. BN-908: wrap the Outlet in <Suspense>.
 */
function AuthLayout() {
  return null;
}

export default AuthLayout;
