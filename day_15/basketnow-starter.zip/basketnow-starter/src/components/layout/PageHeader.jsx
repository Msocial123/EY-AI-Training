/**
 * TODO BN-901 - PageHeader: the same title area on every page.
 * Props: title, subtitle (optional), actions (optional JSX, e.g. buttons).
 * CSS: page-header, page-actions. Use it in OrdersPage and InventoryPage.
 */
function PageHeader() {
  return null;
}

export default PageHeader;
