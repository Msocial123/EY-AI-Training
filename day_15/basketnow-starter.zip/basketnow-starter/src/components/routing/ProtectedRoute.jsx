/**
 * TODO BN-903 - ProtectedRoute: a layout route that only logged-in users can pass.
 * status "checking" -> <LoadingState />; "anonymous" -> <Navigate to="/login" replace state={{ from }} />;
 * otherwise <Outlet />.
 */
function ProtectedRoute() {
  return null;
}

export default ProtectedRoute;
