/**
 * TODO BN-903 - RequireRole({ role }): used inside ProtectedRoute.
 * Wrong role -> EmptyState "Access denied" with a Link to the shop; right role -> <Outlet />.
 */
function RequireRole() {
  return null;
}

export default RequireRole;
