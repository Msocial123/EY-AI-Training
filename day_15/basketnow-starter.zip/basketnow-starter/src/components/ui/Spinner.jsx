/**
 * TODO BN-901 - Spinner: a round loading indicator.
 * Props: size ("sm" | "md", default "md"), label (default "Loading", for screen readers).
 * Render one <span> with className "loader" (+ " loader-sm" when small), role="status" and aria-label.
 */
function Spinner() {
  return null;
}

export default Spinner;
