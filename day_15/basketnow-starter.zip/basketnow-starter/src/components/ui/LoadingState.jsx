/**
 * TODO BN-901 - LoadingState: the standard "please wait" block for every page.
 * Props: text (default "Loading..."), fullPage (default false).
 * Render <div className="loading-state"> (add " full" when fullPage) with a <Spinner label={text} /> and <p>{text}</p>.
 */
function LoadingState() {
  return null;
}

export default LoadingState;
