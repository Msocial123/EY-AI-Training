/**
 * TODO BN-903 / BN-904 - AuthContext: the logged-in user and the session, for the whole app.
 * - status: "checking" | "authenticated" | "anonymous"; user; expiresAt; remember; endReason
 * - on start: restore the saved session (utils/session.js) and check it with fetchMe()
 * - login(email, password, remember), logout(), checkSession()
 * - end the session on 401 (setUnauthorizedHandler), at expiresAt (timer) and when another tab logs out
 * - export useAuth() with a clear error outside <AuthProvider>
 */
export function AuthProvider({ children }) {
  return children;
}

export function useAuth() {
  throw new Error("useAuth is not built yet (BN-903)");
}
