/**
 * TODO BN-906 - One frozen `config` object built from import.meta.env:
 * appName, apiBaseUrl (required), apiTimeoutMs (number), authHeader, enableDevTools (boolean),
 * mode, isDev, isProd, version (__APP_VERSION__ from vite.config.js).
 */
export const config = {};
