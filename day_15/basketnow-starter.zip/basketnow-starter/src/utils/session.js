/**
 * TODO BN-904 - Where the session { token, expiresAt, remember } is kept.
 * remember ON -> localStorage, OFF -> sessionStorage. Key "bn-session".
 * export SESSION_KEY, saveSession(session), readSession() (null if missing or broken), clearSession()
 */
export {};
