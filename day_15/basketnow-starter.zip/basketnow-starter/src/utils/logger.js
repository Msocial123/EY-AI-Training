/**
 * TODO BN-907 - logger: debug(...) and api(method, url, status, ms, data) only in development,
 * warn(...) and error(...) always. api() prints one collapsible console group per request.
 */
export const logger = {};
