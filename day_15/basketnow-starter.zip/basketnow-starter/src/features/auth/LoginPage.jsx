/**
 * TODO BN-903 / BN-904 - /login inside AuthLayout.
 * useForm with email + password (+ remember in BN-904), validateLogin, server errors under the fields,
 * after login navigate to location.state.from (or "/") with replace. Demo account buttons fill the form.
 * BN-904: show why the last session ended (expired, other tab).
 */
function LoginPage() {
  return null;
}

export default LoginPage;
