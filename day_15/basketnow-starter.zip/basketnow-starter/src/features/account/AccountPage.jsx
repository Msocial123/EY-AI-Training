/**
 * TODO BN-904 - /account (logged-in users): profile (name, email, role, orders) and session
 * (where it is kept, expiry time, live countdown with useNow). Log out button in PageHeader.
 * Developer tests (BN-905/BN-906): Break my token, Check my session, Crash this page.
 */
function AccountPage() {
  return null;
}

export default AccountPage;
