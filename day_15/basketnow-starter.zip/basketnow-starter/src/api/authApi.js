/**
 * TODO BN-902 - Service functions for authentication (they use `http` from ./client).
 * - login(email, password)  POST /auth/login  -> { token, expiresAt, user }   (401 if wrong)
 * - fetchMe({ signal })     GET  /auth/me     -> { user, expiresAt }          (401 if the token is not valid)
 * - logout()                POST /auth/logout -> 204
 */
export {};
