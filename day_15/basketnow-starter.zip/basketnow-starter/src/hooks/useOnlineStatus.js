/**
 * TODO BN-905 - useOnlineStatus(): true while the browser is online.
 * Start with navigator.onLine; listen to the window "online" and "offline" events (remove them in the cleanup).
 */
export function useOnlineStatus() {
  return true;
}
