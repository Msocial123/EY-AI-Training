# GenAI Navigator

An internal tool that helps business and engineering teams understand Generative AI and choose the right approach for a business problem.

- **What is GenAI**: definition, generative vs traditional AI, the four types (text, image, audio, code), key models (GPT, DALL·E, Codex, Stable Diffusion, Whisper, StyleGAN) and a timeline.
- **How it works**: three interactive demos: a next-word model (the Transformer idea), a noise-to-image demo (diffusion) and a generator-vs-discriminator game (GAN).
- **Use-case Mapper**: map 12 enterprise problem statements to a GenAI type and model family; analyse your own problem statement.
- **Playground**: text (with prompt templates), image, audio (text-to-speech) and code generation.
- **Industry Use Cases**: 18 use cases across 8 industries, each with value, risks and controls.
- **Settings**: switch between offline demo mode and any OpenAI-compatible API (OpenAI, Ollama, gateways).

## Run it

```bash
npm install
npm run dev        # http://localhost:5173
npm run build
```

Node.js 20.19+ or 22.12+ is required.

## Demo mode and live models

The app starts in **demo mode**: everything works offline and generated outputs are clearly labelled "simulated".

To use a real model, either open **Settings** in the app, or copy `.env.example` to `.env`, fill it in and restart `npm run dev`.

| Provider | Base URL | API key | Text model |
|---|---|---|---|
| Ollama (free, runs on your laptop) | `http://localhost:11434/v1` | leave empty | e.g. `llama3.2` (after `ollama pull llama3.2`) |
| OpenAI | `https://api.openai.com/v1` | your key | a model name from your account's model list |

Use **Test connection** in Settings to see the model names your provider offers today. Image generation needs a provider and model that support `/images/generations`.

**Security:** an API key used in a browser app can be seen by anyone using that app. This is fine for personal learning only. Production apps call AI models from a backend server. Never commit `.env` (it is in `.gitignore`).

## Project structure

```text
src/
├── App.jsx                 # page navigation + provider settings (shared state)
├── api/aiClient.js         # OpenAI-compatible client: models, chat completions, images
├── data/                   # GenAI types, models, timeline, problem statements, use cases, prompts, corpus
├── utils/
│   ├── ngram.js            # tiny next-word language model with temperature sampling
│   ├── diffusion.js        # forward diffusion (adding noise) for the image demo
│   ├── gan.js              # simplified generator-vs-discriminator game
│   ├── classifier.js       # keyword-based problem → GenAI type helper
│   ├── demoAI.js           # offline simulated text, code and image output
│   ├── random.js, format.js
├── hooks/useLocalStorage.js
├── components/             # Button, Badge, SegmentedControl, CopyButton, ProviderNotice, Header
└── features/               # overview, lab, mapper, playground, usecases, settings
```
