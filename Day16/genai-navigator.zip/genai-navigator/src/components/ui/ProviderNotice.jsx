/** Tells the user whether output is simulated (demo) or comes from a real model. */
function ProviderNotice({ config, onOpenSettings }) {
  if (config.provider === "demo") {
    return (
      <div className="notice notice-demo">
        <b>Demo mode:</b> outputs are simulated offline, no AI model is called.
        <button className="link" onClick={onOpenSettings}>Connect a real model</button>
      </div>
    );
  }
  return (
    <div className="notice notice-live">
      <b>Live model:</b> {config.textModel || "no text model set"} via {config.baseUrl}
      <button className="link" onClick={onOpenSettings}>Change</button>
    </div>
  );
}

export default ProviderNotice;
