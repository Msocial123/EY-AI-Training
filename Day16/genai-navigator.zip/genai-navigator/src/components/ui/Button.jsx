/**
 * Reusable button. variant: "primary" | "secondary" | "ghost" | "danger"; size: "sm" | "md".
 * isLoading shows a spinner and disables the button. Other props pass through to <button>.
 */
function Button({ variant = "primary", size = "md", isLoading = false, disabled, children, ...rest }) {
  return (
    <button className={`btn btn-${variant} btn-${size}`} disabled={disabled || isLoading} aria-busy={isLoading} {...rest}>
      {isLoading && <span className="spinner" aria-hidden="true" />}
      {children}
    </button>
  );
}

export default Button;
