/** Small label. tone: "violet" | "cyan" | "green" | "amber" | "red" | "grey" */
function Badge({ tone = "grey", children }) {
  return <span className={`badge badge-${tone}`}>{children}</span>;
}

/** Colour used for each Generative AI type, so the same type always looks the same. */
export const TYPE_TONES = { text: "violet", image: "cyan", audio: "amber", code: "green" };

export function TypeBadge({ type }) {
  const labels = { text: "Text", image: "Image", audio: "Audio", code: "Code" };
  return <Badge tone={TYPE_TONES[type]}>{labels[type]}</Badge>;
}

export default Badge;
