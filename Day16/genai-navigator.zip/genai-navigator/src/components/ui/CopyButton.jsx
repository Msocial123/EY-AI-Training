import { useState } from "react";
import Button from "./Button";

/** Copies text to the clipboard and shows "Copied" for 1.5 seconds. */
function CopyButton({ text }) {
  const [copied, setCopied] = useState(false);

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      setCopied(false);
    }
  }

  return (
    <Button variant="ghost" size="sm" onClick={handleCopy} disabled={!text}>
      {copied ? "✓ Copied" : "Copy"}
    </Button>
  );
}

export default CopyButton;
