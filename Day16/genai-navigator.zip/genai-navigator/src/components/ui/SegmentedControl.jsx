/**
 * Row of buttons where exactly one is selected (like tabs or radio buttons).
 * options: [{ id, label }] or plain strings.
 */
function SegmentedControl({ options, value, onChange, label }) {
  const items = options.map((o) => (typeof o === "string" ? { id: o, label: o } : o));
  return (
    <div className="segmented" role="radiogroup" aria-label={label}>
      {items.map((o) => (
        <button
          key={o.id}
          type="button"
          role="radio"
          aria-checked={o.id === value}
          className={o.id === value ? "segment active" : "segment"}
          onClick={() => onChange(o.id)}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export default SegmentedControl;
