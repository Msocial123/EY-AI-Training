const TABS = [
  { id: "overview", label: "What is GenAI" },
  { id: "lab", label: "How it works" },
  { id: "mapper", label: "Use-case Mapper" },
  { id: "playground", label: "Playground" },
  { id: "usecases", label: "Industry Use Cases" },
  { id: "settings", label: "Settings" },
];

/** Logo, provider status and the main navigation. No state of its own. */
function Header({ view, onNavigate, provider }) {
  return (
    <header className="header">
      <div className="header-row">
        <button className="logo" onClick={() => onNavigate("overview")} aria-label="GenAI Navigator home">
          <span className="logo-mark">✦</span> GenAI <b>Navigator</b>
        </button>
        <span className={provider === "demo" ? "status-pill demo" : "status-pill live"}>
          {provider === "demo" ? "Demo mode" : "Live model"}
        </span>
      </div>
      <nav className="tabs" aria-label="Main">
        {TABS.map((tab) => (
          <button key={tab.id} className={tab.id === view ? "tab active" : "tab"} onClick={() => onNavigate(tab.id)}>
            {tab.label}
          </button>
        ))}
      </nav>
    </header>
  );
}

export default Header;
