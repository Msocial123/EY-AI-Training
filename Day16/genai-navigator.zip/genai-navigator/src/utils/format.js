// Small display helpers.

export function percent(value, digits = 0) {
  return `${(value * 100).toFixed(digits)}%`;
}

export function formatMs(ms) {
  return ms < 1000 ? `${Math.round(ms)} ms` : `${(ms / 1000).toFixed(1)} s`;
}

export function timeNow() {
  return new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

/** Pulls the code out of a ```fenced``` block in a model reply; returns the whole text if there is none. */
export function extractCode(text) {
  const match = text.match(/```[a-zA-Z]*\n?([\s\S]*?)```/);
  return (match ? match[1] : text).trim();
}
