// DEMO MODE: offline, rule-based imitations of generative models, so the app works without an API key.
// They are deliberately simple and are always labelled "simulated" in the UI.
// Connect a real model in Settings to see true generative output.
import { createRandom, hashString } from "./random";

const STOPWORDS = new Set(
  "a an the and or but if to of in on at for with from by is are was were be been it this that she he they we you i her his their our your has have had not no do does did will would can could also".split(" ")
);

function splitSentences(text) {
  return text.replace(/\s+/g, " ").split(/(?<=[.!?])\s+/).map((s) => s.trim()).filter(Boolean);
}

/** Extractive summary: keeps the sentences that contain the most frequent important words. */
export function summarize(text, sentenceCount) {
  const sentences = splitSentences(text);
  const freq = {};
  for (const w of text.toLowerCase().match(/[a-z']+/g) || []) {
    if (!STOPWORDS.has(w)) freq[w] = (freq[w] || 0) + 1;
  }
  const scored = sentences.map((s, index) => {
    const words = (s.toLowerCase().match(/[a-z']+/g) || []).filter((w) => !STOPWORDS.has(w));
    const score = words.reduce((sum, w) => sum + (freq[w] || 0), 0) / Math.max(1, words.length);
    return { s, index, score };
  });
  return scored
    .sort((a, b) => b.score - a.score)
    .slice(0, sentenceCount)
    .sort((a, b) => a.index - b.index)
    .map((x) => `• ${x.s}`)
    .join("\n");
}

const POSITIVE = ["good", "great", "fast", "excellent", "love", "happy", "nice", "quick", "perfect", "helpful", "best", "fresh", "easy"];
const NEGATIVE = ["poor", "bad", "late", "damaged", "broken", "stopped", "worst", "slow", "rude", "refund", "never", "disappointed", "not working", "defective"];

export function classifySentiment(text) {
  const t = text.toLowerCase();
  const pos = POSITIVE.filter((w) => t.includes(w));
  const neg = NEGATIVE.filter((w) => t.includes(w));
  let label = "Neutral";
  if (pos.length && neg.length) label = "Mixed";
  else if (pos.length) label = "Positive";
  else if (neg.length) label = "Negative";
  const strength = Math.min(0.95, 0.55 + 0.1 * Math.abs(pos.length - neg.length) + 0.05 * (pos.length + neg.length));
  return { label, confidence: Number(strength.toFixed(2)), positive: pos, negative: neg };
}

function detectTopic(text) {
  const t = text.toLowerCase();
  if (t.includes("refund")) return "refund";
  if (t.includes("damag") || t.includes("broken")) return "damaged";
  if (t.includes("delay") || t.includes("late")) return "delay";
  return "update";
}

const EMAIL_LINES = {
  refund: "Good news: your refund has been approved. The amount will be credited to your original payment method within 5 working days.",
  damaged: "We are sorry that your product arrived damaged. We will arrange a free replacement and our delivery partner will collect the damaged item.",
  delay: "We are sorry that your delivery is taking longer than expected. Your order is on its way and we are tracking it closely.",
  update: "Here is an update on your request. Our team has reviewed it and will keep you informed at every step.",
};

const OPENERS = {
  friendly: "Hope you are doing well!",
  formal: "Thank you for contacting us.",
  apologetic: "We sincerely apologise for the trouble this has caused.",
  enthusiastic: "Thank you so much for shopping with us!",
};

/** Returns simulated output for a Text studio template. */
export function demoText(templateId, input, { tone = "friendly", length = "short" } = {}) {
  if (templateId === "summarize") return summarize(input, length === "short" ? 2 : 4);

  if (templateId === "sentiment") {
    const r = classifySentiment(input);
    return [
      `Sentiment: ${r.label}`,
      `Confidence: ${r.confidence}`,
      `Positive phrases: ${r.positive.join(", ") || "none"}`,
      `Negative phrases: ${r.negative.join(", ") || "none"}`,
    ].join("\n");
  }

  if (templateId === "email") {
    const nameMatch = input.match(/customer\s+([A-Z][a-z]+)|([A-Z][a-z]+)'s/);
    const name = nameMatch ? nameMatch[1] || nameMatch[2] : "Customer";
    const orderMatch = input.match(/order\s*#?\s*(\d{3,})/i);
    const topic = detectTopic(input);
    return [
      `Subject: ${topic === "refund" ? "Your refund is approved" : "Update on your order"}${orderMatch ? ` #${orderMatch[1]}` : ""}`,
      "",
      `Dear ${name},`,
      "",
      OPENERS[tone] || OPENERS.friendly,
      EMAIL_LINES[topic],
      "",
      "If you have any questions, just reply to this email.",
      "",
      "Warm regards,",
      "Team ShopEase",
    ].join("\n");
  }

  if (templateId === "product") {
    const [name, ...features] = input.split(",").map((s) => s.trim()).filter(Boolean);
    const list = features.length ? features.join(", ") : "thoughtful design";
    const intro = tone === "enthusiastic" ? `Meet the ${name || "product"}: made to make every day easier!` : `The ${name || "product"} is designed for everyday reliability.`;
    const extra = length === "short" ? "" : ` Whether it is a busy weekday morning or a relaxed weekend, it fits right into your routine. Order today and enjoy hassle-free returns.`;
    return `${intro} It comes with ${list}.${extra}`;
  }

  return "Demo mode can run only the four built-in tasks (summarise, email, sentiment, product description).\nTo answer free prompts like this one, connect a real model in Settings.";
}

const CODE_TEMPLATES = [
  {
    match: ["email"],
    JavaScript: `function isValidEmail(email) {\n  // something@something.domain, no spaces\n  const pattern = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$/;\n  return pattern.test(email.trim());\n}\n\nconsole.log(isValidEmail("priya@example.com")); // true\nconsole.log(isValidEmail("priya@example"));     // false`,
    Python: `import re\n\ndef is_valid_email(email: str) -> bool:\n    """something@something.domain, no spaces"""\n    pattern = r"^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$"\n    return re.match(pattern, email.strip()) is not None\n\nprint(is_valid_email("priya@example.com"))  # True\nprint(is_valid_email("priya@example"))      # False`,
    Java: `import java.util.regex.Pattern;\n\npublic class EmailValidator {\n    private static final Pattern EMAIL = Pattern.compile("^[^\\\\s@]+@[^\\\\s@]+\\\\.[^\\\\s@]{2,}$");\n\n    public static boolean isValid(String email) {\n        return email != null && EMAIL.matcher(email.trim()).matches();\n    }\n}`,
  },
  {
    match: ["top", "customer"],
    SQL: `-- Top 5 customers by total order value\nSELECT c.customer_id,\n       c.customer_name,\n       SUM(o.order_total) AS total_value\nFROM customers c\nJOIN orders o ON o.customer_id = c.customer_id\nGROUP BY c.customer_id, c.customer_name\nORDER BY total_value DESC\nLIMIT 5;`,
  },
  {
    match: ["palindrome"],
    JavaScript: `function isPalindrome(text) {\n  const clean = text.toLowerCase().replace(/[^a-z0-9]/g, "");\n  return clean === [...clean].reverse().join("");\n}\n\nconsole.log(isPalindrome("Madam"));       // true\nconsole.log(isPalindrome("ShopEase"));    // false`,
    Python: `def is_palindrome(text: str) -> bool:\n    clean = "".join(ch for ch in text.lower() if ch.isalnum())\n    return clean == clean[::-1]\n\nprint(is_palindrome("Madam"))     # True\nprint(is_palindrome("ShopEase"))  # False`,
  },
  {
    match: ["test", "add"],
    JavaScript: `// add.test.js (Vitest / Jest)\nimport { add } from "./add";\n\ndescribe("add", () => {\n  test("adds two positive numbers", () => {\n    expect(add(2, 3)).toBe(5);\n  });\n  test("works with negative numbers", () => {\n    expect(add(-2, 5)).toBe(3);\n  });\n  test("adding zero returns the same number", () => {\n    expect(add(7, 0)).toBe(7);\n  });\n});`,
    Python: `# test_add.py (pytest)\nfrom calculator import add\n\ndef test_adds_two_positive_numbers():\n    assert add(2, 3) == 5\n\ndef test_works_with_negative_numbers():\n    assert add(-2, 5) == 3\n\ndef test_adding_zero_returns_same_number():\n    assert add(7, 0) == 7`,
  },
];

/** Returns simulated generated code for a request, or a commented skeleton if no template matches. */
export function demoCode(request, language) {
  const r = request.toLowerCase();
  const template = CODE_TEMPLATES.find((t) => t.match.every((word) => r.includes(word)));
  if (template && template[language]) return template[language];
  const comment = language === "Python" || language === "SQL" ? (language === "SQL" ? "--" : "#") : "//";
  return [
    `${comment} Demo mode has ready-made answers only for the sample requests.`,
    `${comment} Your request: ${request}`,
    `${comment} Connect a real model in Settings to generate ${language} code for any request.`,
  ].join("\n");
}

/** Creates a simple abstract SVG "image" from the prompt. Same prompt -> same picture. */
export function demoImage(prompt, style) {
  const seed = hashString(`${prompt}|${style}`);
  const random = createRandom(seed);
  const hue = Math.floor(random() * 360);
  const hue2 = (hue + 40 + Math.floor(random() * 80)) % 360;
  const shapes = Array.from({ length: 7 }, () => {
    const x = Math.floor(random() * 512);
    const y = Math.floor(random() * 300) + 40;
    const r = Math.floor(random() * 70) + 25;
    const h = (hue + Math.floor(random() * 120)) % 360;
    return `<circle cx="${x}" cy="${y}" r="${r}" fill="hsl(${h},70%,65%)" opacity="0.55"/>`;
  }).join("");
  const caption = prompt.length > 48 ? `${prompt.slice(0, 45)}...` : prompt;
  const safe = caption.replace(/[<>&"]/g, "");
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512">
<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="hsl(${hue},70%,45%)"/><stop offset="1" stop-color="hsl(${hue2},70%,30%)"/></linearGradient></defs>
<rect width="512" height="512" fill="url(#g)"/>${shapes}
<path d="M0 420 L120 330 L230 400 L340 300 L512 410 L512 512 L0 512 Z" fill="rgba(0,0,0,0.25)"/>
<rect x="24" y="440" width="464" height="48" rx="10" fill="rgba(0,0,0,0.45)"/>
<text x="40" y="470" font-family="Arial" font-size="18" fill="#fff">${safe}</text>
<text x="40" y="44" font-family="Arial" font-size="14" fill="rgba(255,255,255,0.85)">SIMULATED · ${style}</text>
</svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}
