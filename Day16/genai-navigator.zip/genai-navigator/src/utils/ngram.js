// A tiny next-word language model (trigram with fallback).
// GPT does the same job - predict the next token from the previous ones - but with a Transformer
// neural network and billions of parameters. Here we simply COUNT which word follows which.
import { createRandom } from "./random";

/** "Your order HAS shipped." -> ["your", "order", "has", "shipped", "."] */
export function tokenize(text) {
  return text.toLowerCase().match(/[a-z0-9']+|[.,!?]/g) || [];
}

/**
 * Builds count tables from the training text.
 * trigrams["your order"]["has"] = how many times "has" came after "your order".
 */
export function trainModel(text) {
  const tokens = tokenize(text);
  const unigrams = {};
  const bigrams = {};
  const trigrams = {};

  for (let i = 0; i < tokens.length; i++) {
    const w = tokens[i];
    unigrams[w] = (unigrams[w] || 0) + 1;
    if (i >= 1) {
      const prev = tokens[i - 1];
      bigrams[prev] = bigrams[prev] || {};
      bigrams[prev][w] = (bigrams[prev][w] || 0) + 1;
    }
    if (i >= 2) {
      const key = `${tokens[i - 2]} ${tokens[i - 1]}`;
      trigrams[key] = trigrams[key] || {};
      trigrams[key][w] = (trigrams[key][w] || 0) + 1;
    }
  }
  return { unigrams, bigrams, trigrams, vocabularySize: Object.keys(unigrams).length, tokenCount: tokens.length };
}

/**
 * Probability of every possible next word, given the words so far.
 * Uses the last two words if that pair was seen in training, else the last word, else overall frequency.
 * Returns [{ word, probability }] sorted from most to least likely, plus which table was used.
 */
export function nextWordDistribution(model, contextTokens) {
  const n = contextTokens.length;
  let counts = null;
  let source = "unigram";

  if (n >= 2) {
    const key = `${contextTokens[n - 2]} ${contextTokens[n - 1]}`;
    if (model.trigrams[key]) { counts = model.trigrams[key]; source = "trigram"; }
  }
  if (!counts && n >= 1 && model.bigrams[contextTokens[n - 1]]) {
    counts = model.bigrams[contextTokens[n - 1]];
    source = "bigram";
  }
  if (!counts) counts = model.unigrams;

  const total = Object.values(counts).reduce((sum, c) => sum + c, 0);
  const options = Object.entries(counts)
    .map(([word, c]) => ({ word, probability: c / total }))
    .sort((a, b) => b.probability - a.probability);

  return { options, source };
}

/**
 * Temperature reshapes probabilities before sampling.
 * Low (0.2): the top word becomes almost certain -> safe, repetitive text.
 * High (1.5): unlikely words get more chance -> creative, sometimes nonsense.
 */
export function applyTemperature(options, temperature) {
  const t = Math.max(0.05, temperature);
  const weights = options.map((o) => Math.pow(o.probability, 1 / t));
  const total = weights.reduce((sum, w) => sum + w, 0);
  return options.map((o, i) => ({ ...o, probability: weights[i] / total }));
}

/** Picks one option at random, respecting the probabilities (like spinning a weighted wheel). */
export function sample(options, random) {
  let r = random();
  for (const o of options) {
    r -= o.probability;
    if (r <= 0) return o.word;
  }
  return options[options.length - 1].word;
}

/** Generates `maxWords` words after the prompt. Stops early at a full stop. */
export function generate(model, prompt, { maxWords = 15, temperature = 0.7, seed = 42 } = {}) {
  const random = createRandom(seed);
  const tokens = tokenize(prompt);
  const steps = [];

  for (let i = 0; i < maxWords; i++) {
    const { options, source } = nextWordDistribution(model, tokens);
    const shaped = applyTemperature(options, temperature);
    const word = sample(shaped, random);
    steps.push({ word, source, top: shaped.slice(0, 3) });
    tokens.push(word);
    if (word === ".") break;
  }
  return { text: tokens.join(" ").replace(/ ([.,!?])/g, "$1"), steps };
}
