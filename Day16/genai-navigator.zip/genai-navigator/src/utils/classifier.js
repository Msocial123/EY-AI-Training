// Rule-based helper that suggests which Generative AI type fits a problem statement.
// It is NOT an AI model: it looks for keywords. Useful as a first guess and to explain the thinking.

const KEYWORDS = {
  text: ["summar", "email", "draft", "report", "chat", "answer", "question", "translat", "policy", "document",
    "article", "description", "reply", "sentiment", "classif", "letter", "faq", "knowledge", "proposal", "minutes", "review"],
  image: ["image", "photo", "picture", "banner", "logo", "design", "visual", "poster", "illustration", "thumbnail",
    "render", "face", "mockup", "creative", "catalogue", "drawing", "x-ray", "defect"],
  audio: ["audio", "voice", "speech", "call", "recording", "podcast", "music", "jingle", "sound", "transcri", "ivr",
    "narrat", "dictat", "spoken", "announcement"],
  code: ["code", "sql", "query", "unit test", "function", "script", "api", "bug", "refactor", "program", "java",
    "python", "cobol", "regex", "developer", "migrat", "automation"],
};

const SUGGESTIONS = {
  text: { models: "GPT or another LLM (Llama, Claude, Gemini)", architecture: "Transformer" },
  image: { models: "Stable Diffusion, GPT Image (successor of DALL·E); GAN for synthetic faces", architecture: "Diffusion (or GAN)" },
  audio: { models: "Whisper for speech-to-text; a TTS model for voice; a music model for jingles", architecture: "Transformer / diffusion for audio" },
  code: { models: "GPT-class code models (successors of Codex), GitHub Copilot", architecture: "Transformer trained on code" },
};

/**
 * Scores each type by counting keyword matches.
 * Returns { best, confidence, scores: [{ type, score, matches }] } or best = null when nothing matched.
 */
export function classifyProblem(statement) {
  const text = statement.toLowerCase();
  const scores = Object.entries(KEYWORDS).map(([type, words]) => {
    const matches = words.filter((w) => text.includes(w));
    return { type, score: matches.length, matches };
  });
  scores.sort((a, b) => b.score - a.score);

  const total = scores.reduce((sum, s) => sum + s.score, 0);
  if (total === 0) return { best: null, confidence: 0, scores, suggestion: null };

  const best = scores[0].type;
  return {
    best,
    confidence: Math.round((scores[0].score / total) * 100),
    scores,
    suggestion: SUGGESTIONS[best],
  };
}
