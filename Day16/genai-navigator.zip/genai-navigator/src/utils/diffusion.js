// Forward diffusion: x_t = sqrt(alphaBar_t) * x_0 + sqrt(1 - alphaBar_t) * noise
// t = 0 is the clean image, t = T is almost pure noise.
// A real diffusion model is trained to PREDICT the noise so it can walk back from t = T to t = 0.
import { createRandom, gaussian } from "./random";

export const TOTAL_STEPS = 50;

/** alphaBar[t] = how much of the original image is left at step t (1 = all of it, ~0 = none). */
export function makeSchedule(steps = TOTAL_STEPS, betaStart = 0.0005, betaEnd = 0.2) {
  const alphaBar = [1];
  let product = 1;
  for (let t = 1; t <= steps; t++) {
    const beta = betaStart + ((betaEnd - betaStart) * (t - 1)) / (steps - 1);
    product *= 1 - beta;
    alphaBar.push(product);
  }
  return alphaBar;
}

/** One fixed noise value per pixel channel (seeded, so every step uses the same noise). */
export function makeNoise(length, seed = 7) {
  const random = createRandom(seed);
  const noise = new Float32Array(length);
  for (let i = 0; i < length; i++) noise[i] = gaussian(random);
  return noise;
}

/**
 * Mixes the clean image with noise for step t.
 * clean: RGBA bytes (0-255). Returns new RGBA bytes.
 */
export function noisyFrame(clean, noise, alphaBarT) {
  const out = new Uint8ClampedArray(clean.length);
  const keep = Math.sqrt(alphaBarT);
  const add = Math.sqrt(1 - alphaBarT);
  for (let i = 0; i < clean.length; i += 4) {
    for (let c = 0; c < 3; c++) {
      const x0 = clean[i + c] / 127.5 - 1;           // 0..255 -> -1..1
      const xt = keep * x0 + add * noise[i + c];
      out[i + c] = (xt + 1) * 127.5;                 // -1..1 -> 0..255 (clamped automatically)
    }
    out[i + 3] = 255;
  }
  return out;
}
