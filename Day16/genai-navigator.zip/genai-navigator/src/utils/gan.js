// A simplified GAN game in one dimension (no neural networks).
// REAL data: delivery times (minutes) of real orders, around 35 ± 6.
// GENERATOR: makes fake delivery times from its own mean and spread, starting badly.
// DISCRIMINATOR: tries to tell real from fake. Its accuracy falls to ~50% when the fakes look real.
import { createRandom, gaussian } from "./random";

export const REAL = { mean: 35, sd: 6 };
export const BINS = { min: 0, max: 80, count: 16 };

export function initialGenerator() {
  return { mean: 10, sd: 4 };
}

/** Draws `n` samples from a normal distribution. */
export function drawSamples(params, n, random) {
  return Array.from({ length: n }, () => params.mean + params.sd * gaussian(random));
}

/** Counts samples into equal-width bins for the histogram. */
export function histogram(samples) {
  const width = (BINS.max - BINS.min) / BINS.count;
  const counts = new Array(BINS.count).fill(0);
  for (const s of samples) {
    const i = Math.min(BINS.count - 1, Math.max(0, Math.floor((s - BINS.min) / width)));
    counts[i] += 1;
  }
  return counts;
}

/**
 * Best possible discriminator accuracy = 0.5 + 0.5 * (1 - overlap of the two histograms).
 * 100% = fakes are easy to spot, 50% = a coin toss (fakes look real).
 */
export function discriminatorAccuracy(realCounts, fakeCounts, n) {
  let overlap = 0;
  for (let i = 0; i < realCounts.length; i++) overlap += Math.min(realCounts[i], fakeCounts[i]) / n;
  return 0.5 + 0.5 * (1 - overlap);
}

/**
 * One training round. The generator moves its mean and spread a step towards whatever
 * the discriminator says looks real (learning rate controls the step size).
 */
export function trainingRound(generator, round, learningRate = 0.3, n = 400) {
  const random = createRandom(1000 + round);
  const real = drawSamples(REAL, n, random);
  const fake = drawSamples(generator, n, random);
  const realCounts = histogram(real);
  const fakeCounts = histogram(fake);
  const accuracy = discriminatorAccuracy(realCounts, fakeCounts, n);

  const next = {
    mean: generator.mean + learningRate * (REAL.mean - generator.mean),
    sd: generator.sd + learningRate * (REAL.sd - generator.sd),
  };
  return { realCounts, fakeCounts, accuracy, next };
}
