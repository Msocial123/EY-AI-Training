// Key models and architectures, plus a timeline of milestones.
// Facts are historical; "status" notes reflect late 2026. Model names change often:
// always check your provider's current model list before using a name in code.

export const ARCHITECTURES = [
  {
    id: "transformer",
    name: "Transformer",
    year: 2017,
    origin: "Google research paper \"Attention Is All You Need\"",
    idea: "Reads the whole input at once and uses attention to decide which earlier words matter most, then predicts the next token, one token at a time.",
    goodFor: "Text, code, speech recognition; the base of GPT, Codex and Whisper",
    analogy: "Autocomplete on your phone, scaled up to billions of parameters and trained on a huge library of text.",
  },
  {
    id: "diffusion",
    name: "Diffusion model",
    year: 2020,
    origin: "Denoising Diffusion Probabilistic Models (Ho et al.), building on 2015 work",
    idea: "Training: add noise to real images step by step. Generation: start from pure noise and remove a little noise at each step, guided by the text prompt, until an image appears.",
    goodFor: "High-quality images, also audio and video; the base of Stable Diffusion and DALL·E 2/3",
    analogy: "A sculptor who starts with a rough block and removes a little material at every step.",
  },
  {
    id: "gan",
    name: "GAN (Generative Adversarial Network)",
    year: 2014,
    origin: "Ian Goodfellow and colleagues",
    idea: "Two networks compete: a generator makes fakes, a discriminator tries to spot them. Both improve until the fakes look real.",
    goodFor: "Realistic faces and textures (StyleGAN), image-to-image translation, synthetic data",
    analogy: "A counterfeiter and a bank inspector who keep getting better because of each other.",
  },
];

export const KEY_MODELS = [
  {
    id: "gpt",
    name: "GPT",
    maker: "OpenAI",
    type: "text",
    architecture: "transformer",
    firstRelease: 2018,
    summary: "Generative Pre-trained Transformer. Pre-trained on large text collections to predict the next token, then tuned to follow instructions. Powers ChatGPT.",
    status: "Active. New generations ship regularly (GPT-3 in 2020, GPT-4 in 2023, GPT-5 in 2025, GPT-6 models by late 2026).",
  },
  {
    id: "dalle",
    name: "DALL·E",
    maker: "OpenAI",
    type: "image",
    architecture: "diffusion",
    firstRelease: 2021,
    summary: "Text-to-image model. The first version (2021) was transformer-based; DALL·E 2 (2022) and DALL·E 3 (2023) used diffusion.",
    status: "Retired from the OpenAI API on 12 May 2026; replaced by OpenAI's GPT Image models.",
  },
  {
    id: "codex",
    name: "Codex",
    maker: "OpenAI",
    type: "code",
    architecture: "transformer",
    firstRelease: 2021,
    summary: "GPT-3 fine-tuned on natural language and public source code. Translated plain English into code and powered the first GitHub Copilot.",
    status: "Codex API deprecated in March 2023 (general GPT models took over coding). The name was later reused for OpenAI's coding agent.",
  },
  {
    id: "stablediffusion",
    name: "Stable Diffusion",
    maker: "Stability AI with CompVis and Runway",
    type: "image",
    architecture: "diffusion",
    firstRelease: 2022,
    summary: "Latent diffusion model: denoises a compressed version of the image, so it runs on a single consumer GPU. Released with open weights.",
    status: "Active, with many newer versions and community fine-tunes; can run on-premises.",
  },
  {
    id: "whisper",
    name: "Whisper",
    maker: "OpenAI",
    type: "audio",
    architecture: "transformer",
    firstRelease: 2022,
    summary: "Speech-to-text model trained on many languages; turns audio into a transcript. Released as open source.",
    status: "Active; widely used for transcription, including on-premises.",
  },
  {
    id: "stylegan",
    name: "StyleGAN",
    maker: "NVIDIA",
    type: "image",
    architecture: "gan",
    firstRelease: 2018,
    summary: "GAN that generates highly realistic faces and objects with control over style (pose, hair, lighting).",
    status: "Mostly research and synthetic-data use; diffusion models now dominate image generation.",
  },
];

export const TIMELINE = [
  { year: 2014, title: "GANs introduced", detail: "Generator vs discriminator training (Goodfellow et al.)", arch: "gan" },
  { year: 2017, title: "Transformer architecture", detail: "\"Attention Is All You Need\" (Google)", arch: "transformer" },
  { year: 2018, title: "GPT-1 and StyleGAN", detail: "Generative pre-training for text; GAN faces", arch: "transformer" },
  { year: 2020, title: "GPT-3 and DDPM", detail: "175-billion-parameter language model; modern diffusion paper", arch: "diffusion" },
  { year: 2021, title: "DALL·E and Codex", detail: "Text-to-image; code from plain English (GitHub Copilot)", arch: "transformer" },
  { year: 2022, title: "Stable Diffusion, Whisper, ChatGPT", detail: "Open image model; open speech-to-text; ChatGPT launches (30 Nov)", arch: "diffusion" },
  { year: 2023, title: "GPT-4 and DALL·E 3", detail: "Multimodal GPT; Codex API retired in March", arch: "transformer" },
  { year: 2025, title: "GPT-5", detail: "Reasoning models become mainstream for coding and agents", arch: "transformer" },
  { year: 2026, title: "DALL·E retired from the API", detail: "OpenAI's GPT Image models replace DALL·E 2 and 3 (12 May)", arch: "diffusion" },
];

export const MODEL_BY_ID = Object.fromEntries(KEY_MODELS.map((m) => [m.id, m]));
export const ARCH_BY_ID = Object.fromEntries(ARCHITECTURES.map((a) => [a.id, a]));
