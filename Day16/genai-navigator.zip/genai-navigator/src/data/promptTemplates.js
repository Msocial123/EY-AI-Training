// Prompt templates for the Text studio.
// A template = a SYSTEM prompt (the model's role and rules) + a USER prompt built from the user's input.
// Showing both to the learner teaches prompt engineering: same model, different instructions, different output.

export const TEXT_TEMPLATES = [
  {
    id: "summarize",
    label: "Summarise text",
    placeholder: "Paste a long text: tickets, meeting notes, an article...",
    sample:
      "Customer says the order arrived two days late. The box was damaged and the mixer grinder does not switch on. " +
      "She has called support twice already and nobody called back. She wants a replacement before the festival. " +
      "She is a regular customer and has ordered from us for three years. She also asked whether the warranty card is inside the box.",
    system: "You are a support team lead. Summarise accurately. Never add facts that are not in the text.",
    buildUser: (input, opts) =>
      `Summarise the following in ${opts.length === "short" ? "2" : "4"} bullet points for a store manager.\n\nTEXT:\n${input}`,
  },
  {
    id: "email",
    label: "Draft a customer email",
    placeholder: "Describe the situation: who the customer is and what happened...",
    sample: "Customer Priya's refund for order 48213 was approved today; amount ₹1,499 will be credited in 5 days.",
    system: "You write short, polite customer-service emails for an Indian online store. Use simple English. Sign off as 'Team ShopEase'.",
    buildUser: (input, opts) => `Write a ${opts.tone} email to the customer about this situation:\n${input}`,
  },
  {
    id: "sentiment",
    label: "Classify sentiment",
    placeholder: "Paste a customer review...",
    sample: "The delivery was fast and the packaging was good, but the product quality is poor and it stopped working in a week.",
    system: "You are a review analyst. Reply with: Sentiment (Positive, Negative or Mixed), a confidence from 0 to 1, and the key phrases that justify it.",
    buildUser: (input) => `Classify the sentiment of this customer review:\n"${input}"`,
  },
  {
    id: "product",
    label: "Write a product description",
    placeholder: "Product name and key features, separated by commas...",
    sample: "SmartBrew Coffee Maker, 1.2 litre, auto shut-off, 12-cup capacity, 2-year warranty, stainless steel",
    system: "You are an e-commerce copywriter. Use only the features given. Do not invent specifications.",
    buildUser: (input, opts) => `Write a ${opts.tone} product description of about ${opts.length === "short" ? "40" : "90"} words for:\n${input}`,
  },
  {
    id: "free",
    label: "Free prompt",
    placeholder: "Ask anything (needs a connected model in Settings)...",
    sample: "Explain the difference between a GAN and a diffusion model to a new joiner in 3 sentences.",
    system: "You are a helpful assistant for employees of an IT services company. Be concise and accurate.",
    buildUser: (input) => input,
  },
];

export const TONES = ["friendly", "formal", "apologetic", "enthusiastic"];

export const CODE_LANGUAGES = ["JavaScript", "Python", "SQL", "Java"];

export const CODE_SAMPLES = [
  "Write a function that checks whether an email address is valid",
  "Write a SQL query to find the top 5 customers by total order value",
  "Write a function that checks if a string is a palindrome",
  "Write unit tests for a function add(a, b)",
];

export const IMAGE_STYLES = ["photorealistic", "flat illustration", "3D render", "watercolour"];

export const IMAGE_SAMPLES = [
  "A stainless steel coffee maker on a sunny kitchen counter",
  "Festive sale banner with diyas and gift boxes",
  "A friendly robot helping a customer in a store",
];

export const SPEECH_SAMPLES = [
  "Welcome to ShopEase customer care. For order status, press 1. For refunds, press 2.",
  "Your order has been shipped and will arrive in two days. Thank you for shopping with us.",
];
