// The four kinds of Generative AI covered in this app.
// Each entry is used by the Overview page, the Mapper quiz and the Playground tabs.

export const GENAI_TYPES = [
  {
    id: "text",
    label: "Text generation",
    icon: "📝",
    input: "Text prompt (instructions, documents, questions)",
    output: "New text: answers, summaries, emails, reports, translations",
    architecture: "Transformer (large language model)",
    models: ["GPT family (OpenAI)", "Llama (Meta, open weights)", "Claude (Anthropic)", "Gemini (Google)"],
    examples: ["Summarise support tickets", "Draft customer emails", "HR policy chat assistant"],
  },
  {
    id: "image",
    label: "Image generation",
    icon: "🖼️",
    input: "Text prompt (and optionally a reference image)",
    output: "New images: product photos, banners, illustrations, design variations",
    architecture: "Diffusion models (earlier: GANs)",
    models: ["Stable Diffusion (open weights)", "DALL·E → GPT Image (OpenAI)", "Midjourney", "StyleGAN (GAN)"],
    examples: ["Catalogue lifestyle photos", "Festive sale banners", "Synthetic test faces"],
  },
  {
    id: "audio",
    label: "Audio generation",
    icon: "🎙️",
    input: "Text (for speech), audio (for transcription), or a description (for music)",
    output: "Speech, transcripts, voice-overs, music and sound effects",
    architecture: "Transformers and diffusion for audio",
    models: ["Whisper (speech-to-text, open)", "Text-to-speech models", "Music generation models"],
    examples: ["Transcribe customer calls", "Multilingual IVR voice", "Video background music"],
  },
  {
    id: "code",
    label: "Code generation",
    icon: "💻",
    input: "Natural-language request or existing code",
    output: "New code, tests, SQL queries, explanations, refactored code",
    architecture: "Transformer trained on text + source code",
    models: ["Codex (2021, retired) → GPT models", "GitHub Copilot", "Code Llama / open code models"],
    examples: ["Generate unit tests", "English to SQL", "Explain legacy code"],
  },
];

export const TYPE_BY_ID = Object.fromEntries(GENAI_TYPES.map((t) => [t.id, t]));
