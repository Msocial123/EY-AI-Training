// Training text for the tiny next-word model on the "How it works" page.
// Customer-support replies from an online store. A real GPT model learns from trillions of words;
// this corpus has about 330, which is enough to see how next-word prediction works.

export const SUPPORT_CORPUS = `
thank you for contacting our support team .
thank you for your order . your order has been confirmed .
your order has been shipped and will arrive in two days .
your order has been delivered . we hope you enjoy your purchase .
your refund has been processed and will reach your account in five days .
your refund has been approved . the amount will be credited to your original payment method .
we are sorry for the delay in your delivery .
we are sorry for the inconvenience caused .
we are sorry that the product arrived damaged .
we will replace the damaged product at no extra cost .
we will send a replacement within three days .
we will call you within one hour to resolve the issue .
please share your order number so we can help you .
please share a photo of the damaged product .
please check your email for the tracking link .
please allow five days for the refund to reach your account .
you can track your order using the link in your email .
you can return the product within seven days of delivery .
you can cancel the order before it is shipped .
the product is out of stock right now .
the product will be back in stock next week .
the delivery partner will call you before delivery .
the delivery is delayed because of heavy rain in your area .
our team is looking into your complaint .
our team will contact you within one day .
your complaint has been registered . your ticket number is in the email .
your account has been updated successfully .
your payment was successful and your order is confirmed .
your payment failed . please try again or use another payment method .
thank you for your patience .
thank you for shopping with us .
have a great day .
`;
