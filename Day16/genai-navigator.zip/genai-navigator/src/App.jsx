import { useState } from "react";
import Header from "./components/layout/Header";
import OverviewPage from "./features/overview/OverviewPage";
import LabPage from "./features/lab/LabPage";
import MapperPage from "./features/mapper/MapperPage";
import PlaygroundPage from "./features/playground/PlaygroundPage";
import UseCasesPage from "./features/usecases/UseCasesPage";
import SettingsPage from "./features/settings/SettingsPage";
import { getEnvConfig } from "./api/aiClient";
import { useLocalStorage } from "./hooks/useLocalStorage";

/**
 * App owns the shared state: which page is open, which playground tab is open,
 * and the AI provider settings used by every page that generates content.
 */
function App() {
  const env = getEnvConfig();
  const [view, setView] = useState("overview");
  const [playTab, setPlayTab] = useState("text");

  // Saved settings (without the key) survive a refresh; the API key stays in memory only.
  const [savedSettings, setSavedSettings] = useLocalStorage("gn-settings", null);
  const [apiKey, setApiKey] = useState(env.apiKey);
  const config = { ...env, ...savedSettings, apiKey };

  function navigate(next) {
    setView(next);
    window.scrollTo(0, 0);
  }

  function openPlayground(type) {
    setPlayTab(type);
    navigate("playground");
  }

  function saveSettings(draft) {
    const { apiKey: key, ...rest } = draft;
    setSavedSettings(rest);
    setApiKey(key);
  }

  function resetSettings() {
    setSavedSettings(null);
    setApiKey(env.apiKey);
    return env;
  }

  return (
    <div className="app">
      <Header view={view} onNavigate={navigate} provider={config.provider} />
      <main className="main">
        {view === "overview" && <OverviewPage onTryType={openPlayground} />}
        {view === "lab" && <LabPage />}
        {view === "mapper" && <MapperPage />}
        {view === "playground" && (
          <PlaygroundPage tab={playTab} onTabChange={setPlayTab} config={config} onOpenSettings={() => navigate("settings")} />
        )}
        {view === "usecases" && <UseCasesPage />}
        {view === "settings" && <SettingsPage config={config} onSave={saveSettings} onResetToEnv={resetSettings} />}
      </main>
      <footer className="footer">
        GenAI Navigator · Learn the types, models and enterprise uses of Generative AI · Built with React
      </footer>
    </div>
  );
}

export default App;
