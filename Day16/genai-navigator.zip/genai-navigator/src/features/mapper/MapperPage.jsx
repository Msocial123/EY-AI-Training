import MappingQuiz from "./MappingQuiz";
import ProblemAnalyzer from "./ProblemAnalyzer";

/** Map enterprise problem statements to the right type of Generative AI. */
function MapperPage() {
  return (
    <section>
      <h1>Use-case Mapper</h1>
      <p className="muted">
        For each problem, ask two questions: <b>what will be created?</b> (text, image, audio or code) and <b>which model family is built for it?</b>
      </p>
      <ProblemAnalyzer />
      <h2>Exercise: map 12 enterprise problems</h2>
      <MappingQuiz />
    </section>
  );
}

export default MapperPage;
