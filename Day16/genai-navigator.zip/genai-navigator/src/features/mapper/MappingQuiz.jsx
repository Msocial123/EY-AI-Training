import { PROBLEMS, MODEL_OPTIONS } from "../../data/problems";
import { GENAI_TYPES } from "../../data/genaiTypes";
import { ARCH_BY_ID } from "../../data/models";
import { TypeBadge } from "../../components/ui/Badge";
import Badge from "../../components/ui/Badge";
import Button from "../../components/ui/Button";
import SegmentedControl from "../../components/ui/SegmentedControl";
import { useLocalStorage } from "../../hooks/useLocalStorage";

const TYPE_OPTIONS = GENAI_TYPES.map((t) => ({ id: t.id, label: t.label.split(" ")[0] }));
const MODEL_LABEL = Object.fromEntries(MODEL_OPTIONS.map((m) => [m.id, m.label]));

/**
 * Exercise: map each enterprise problem statement to a GenAI type and a model family.
 * answers = { P01: { type: "text", model: "gpt" }, ... } (saved so a refresh keeps progress)
 */
function MappingQuiz() {
  const [answers, setAnswers] = useLocalStorage("gn-quiz-answers", {});
  const [checked, setChecked] = useLocalStorage("gn-quiz-checked", false);

  function setAnswer(problemId, field, value) {
    setAnswers((prev) => ({ ...prev, [problemId]: { ...prev[problemId], [field]: value } }));
  }

  // Derived results: never stored, always calculated from the answers.
  const results = PROBLEMS.map((p) => {
    const a = answers[p.id] || {};
    return { id: p.id, typeOk: a.type === p.type, modelOk: p.models.includes(a.model) };
  });
  const score = results.reduce((sum, r) => sum + (r.typeOk ? 1 : 0) + (r.modelOk ? 1 : 0), 0);
  const answeredCount = PROBLEMS.filter((p) => answers[p.id]?.type && answers[p.id]?.model).length;

  function reset() {
    setAnswers({});
    setChecked(false);
  }

  return (
    <div>
      <div className="quiz-bar">
        <span>{answeredCount} of {PROBLEMS.length} answered</span>
        {checked && <b className="score">Score: {score} / {PROBLEMS.length * 2}</b>}
        <div className="row">
          <Button onClick={() => setChecked(true)} disabled={answeredCount === 0}>Check answers</Button>
          <Button variant="ghost" onClick={reset}>Reset</Button>
        </div>
      </div>

      <ol className="quiz-list">
        {PROBLEMS.map((p, i) => {
          const a = answers[p.id] || {};
          const r = results[i];
          return (
            <li key={p.id} className={checked ? (r.typeOk && r.modelOk ? "quiz-item ok" : "quiz-item bad") : "quiz-item"}>
              <div className="quiz-q">
                <Badge tone="grey">{p.industry}</Badge>
                <p>{p.statement}</p>
              </div>
              <div className="quiz-a">
                <SegmentedControl options={TYPE_OPTIONS} value={a.type} onChange={(v) => setAnswer(p.id, "type", v)} label={`Type for ${p.id}`} />
                <select value={a.model || ""} onChange={(e) => setAnswer(p.id, "model", e.target.value)} aria-label={`Model for ${p.id}`}>
                  <option value="">Choose a model...</option>
                  {MODEL_OPTIONS.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}
                </select>
              </div>
              {checked && (
                <div className="quiz-feedback">
                  <p>
                    {r.typeOk ? "✓" : "✗"} Type: <TypeBadge type={p.type} /> &nbsp;
                    {r.modelOk ? "✓" : "✗"} Model: {p.models.map((m) => MODEL_LABEL[m]).join(" or ")} &nbsp;
                    <span className="muted">({ARCH_BY_ID[p.architecture].name})</span>
                  </p>
                  <p className="muted">{p.why}</p>
                </div>
              )}
            </li>
          );
        })}
      </ol>
    </div>
  );
}

export default MappingQuiz;
