import { useState } from "react";
import { classifyProblem } from "../../utils/classifier";
import { TypeBadge } from "../../components/ui/Badge";
import Button from "../../components/ui/Button";
import { TYPE_BY_ID } from "../../data/genaiTypes";

const EXAMPLES = [
  "Write minutes of our weekly project meeting from the transcript",
  "Create a poster design for our annual sports day",
  "Convert doctor voice recordings into text notes",
  "Refactor this Python script and add unit tests",
];

/** Type any business problem and get a rule-based suggestion with reasons. */
function ProblemAnalyzer() {
  const [text, setText] = useState("");
  const [result, setResult] = useState(null);

  function analyze(statement) {
    setText(statement);
    setResult(classifyProblem(statement));
  }

  return (
    <div className="panel">
      <h2>Analyse your own problem statement</h2>
      <p className="muted">A keyword-based helper (not an AI model) suggests a GenAI type and explains why. Use it to check your thinking.</p>
      <form className="analyzer" onSubmit={(e) => { e.preventDefault(); analyze(text); }}>
        <textarea rows={2} value={text} onChange={(e) => setText(e.target.value)} placeholder="e.g. Generate product photos for our new kitchen range" />
        <Button type="submit" disabled={!text.trim()}>Analyse</Button>
      </form>
      <div className="chips">
        {EXAMPLES.map((ex) => <button key={ex} className="chip" onClick={() => analyze(ex)}>{ex}</button>)}
      </div>

      {result && !result.best && (
        <p className="warning-box">No keywords matched. Describe what should be CREATED (text, image, audio or code) and try again.</p>
      )}
      {result && result.best && (
        <div className="analysis">
          <p className="analysis-head">
            Suggested type: <TypeBadge type={result.best} /> <b>{TYPE_BY_ID[result.best].label}</b> · confidence {result.confidence}%
          </p>
          <ul className="score-bars">
            {result.scores.map((s) => (
              <li key={s.type}>
                <span className="score-label">{TYPE_BY_ID[s.type].label}</span>
                <span className="prob-bar"><span style={{ width: `${(s.score / Math.max(1, result.scores[0].score)) * 100}%` }} /></span>
                <span className="muted small">{s.matches.length ? s.matches.join(", ") : "no matches"}</span>
              </li>
            ))}
          </ul>
          <p><b>Models to consider:</b> {result.suggestion.models}</p>
          <p><b>Architecture:</b> {result.suggestion.architecture}</p>
        </div>
      )}
    </div>
  );
}

export default ProblemAnalyzer;
