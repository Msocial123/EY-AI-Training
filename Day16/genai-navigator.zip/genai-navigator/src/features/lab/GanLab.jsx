import { useState } from "react";
import Button from "../../components/ui/Button";
import { REAL, BINS, initialGenerator, trainingRound } from "../../utils/gan";
import { percent } from "../../utils/format";

/** GAN idea: a generator learns to fool a discriminator. */
function GanLab() {
  const [generator, setGenerator] = useState(initialGenerator);
  const [rounds, setRounds] = useState([]);

  // Show the current state even before training starts.
  const preview = trainingRound(generator, rounds.length);
  const maxCount = Math.max(...preview.realCounts, ...preview.fakeCounts, 1);
  const binWidth = (BINS.max - BINS.min) / BINS.count;

  function train(times) {
    let g = generator;
    const added = [];
    for (let i = 0; i < times; i++) {
      const roundNo = rounds.length + i;
      const r = trainingRound(g, roundNo);
      added.push({ round: roundNo + 1, mean: g.mean, sd: g.sd, accuracy: r.accuracy });
      g = r.next;
    }
    setGenerator(g);
    setRounds((prev) => [...prev, ...added]);
  }

  function reset() {
    setGenerator(initialGenerator());
    setRounds([]);
  }

  const last = rounds[rounds.length - 1];

  return (
    <div className="lab">
      <div className="lab-controls">
        <p><b>Real data:</b> delivery times of real orders (about {REAL.mean} ± {REAL.sd} minutes).</p>
        <p><b>Generator:</b> invents fake delivery times. Now: {generator.mean.toFixed(1)} ± {generator.sd.toFixed(1)} minutes.</p>
        <p><b>Discriminator:</b> tries to tell real from fake.</p>
        <div className="row">
          <Button onClick={() => train(1)}>Train 1 round</Button>
          <Button variant="secondary" onClick={() => train(5)}>Train 5 rounds</Button>
          <Button variant="ghost" onClick={reset}>Reset</Button>
        </div>
        <div className="meter">
          <span>Discriminator accuracy: <b>{percent(preview.accuracy)}</b></span>
          <span className="meter-bar"><span style={{ width: percent((preview.accuracy - 0.5) * 2) }} /></span>
          <small className="muted">100% = fakes are obvious · 50% = fakes look real (the generator has won)</small>
        </div>
      </div>

      <div className="lab-output">
        <div className="histogram" aria-label="Real versus fake distribution">
          {preview.realCounts.map((real, i) => (
            <div key={i} className="hist-col" title={`${BINS.min + i * binWidth}-${BINS.min + (i + 1) * binWidth} min`}>
              <span className="hist-real" style={{ height: `${(real / maxCount) * 100}%` }} />
              <span className="hist-fake" style={{ height: `${(preview.fakeCounts[i] / maxCount) * 100}%` }} />
            </div>
          ))}
        </div>
        <div className="hist-axis"><span>{BINS.min} min</span><span>{BINS.max} min</span></div>
        <p className="legend"><span className="key real" /> real <span className="key fake" /> generated</p>
        {last && (
          <p className="muted small">After round {last.round}: generator mean moved to {generator.mean.toFixed(1)}, spread {generator.sd.toFixed(1)}.</p>
        )}
        {rounds.length > 0 && (
          <table className="table compact">
            <thead><tr><th>Round</th><th>Generator</th><th>Discriminator accuracy</th></tr></thead>
            <tbody>
              {rounds.slice(-5).map((r) => (
                <tr key={r.round}><td>{r.round}</td><td>{r.mean.toFixed(1)} ± {r.sd.toFixed(1)}</td><td>{percent(r.accuracy)}</td></tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default GanLab;
