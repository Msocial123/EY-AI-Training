import { useState } from "react";
import Button from "../../components/ui/Button";
import { SUPPORT_CORPUS } from "../../data/corpus";
import { trainModel, tokenize, nextWordDistribution, applyTemperature, generate } from "../../utils/ngram";
import { percent } from "../../utils/format";

// Train once when the file loads: counting ~330 words takes a millisecond.
const MODEL = trainModel(SUPPORT_CORPUS);

/** Transformer idea: predict the next word, again and again. */
function NextWordLab() {
  const [prompt, setPrompt] = useState("your order");
  const [temperature, setTemperature] = useState(0.7);
  const [result, setResult] = useState(null);
  const [seed, setSeed] = useState(42);

  // Live view: what does the model think comes next RIGHT NOW? (derived on every render)
  const { options, source } = nextWordDistribution(MODEL, tokenize(prompt));
  const top = applyTemperature(options, temperature).slice(0, 6);

  function handleGenerate() {
    const newSeed = Math.floor(Math.random() * 100000);
    setSeed(newSeed);
    setResult(generate(MODEL, prompt, { maxWords: 15, temperature, seed: newSeed }));
  }

  return (
    <div className="lab">
      <div className="lab-controls">
        <label className="field">
          <span>Start of the sentence (prompt)</span>
          <input value={prompt} onChange={(e) => { setPrompt(e.target.value); setResult(null); }} />
        </label>
        <label className="field">
          <span>Temperature: <b>{temperature.toFixed(1)}</b> {temperature < 0.5 ? "(safe, predictable)" : temperature > 1.1 ? "(creative, risky)" : "(balanced)"}</span>
          <input type="range" min="0.1" max="1.5" step="0.1" value={temperature} onChange={(e) => setTemperature(Number(e.target.value))} />
        </label>
        <Button onClick={handleGenerate} disabled={!prompt.trim()}>Generate 15 words</Button>
        <p className="muted small">Trained on {MODEL.tokenCount} words of support replies · vocabulary {MODEL.vocabularySize} words</p>
      </div>

      <div className="lab-output">
        <h4>Next-word probabilities <small className="muted">(using the {source} table)</small></h4>
        <p className="muted small">Click a word to add it, just like the model does.</p>
        <ul className="prob-list">
          {top.map((o) => (
            <li key={o.word}>
              <button className="prob-word" onClick={() => { setPrompt(`${prompt.trim()} ${o.word}`); setResult(null); }}>{o.word}</button>
              <span className="prob-bar"><span style={{ width: percent(o.probability) }} /></span>
              <span className="prob-value">{percent(o.probability)}</span>
            </li>
          ))}
        </ul>

        {result && (
          <div className="generated">
            <p className="generated-text">{result.text}</p>
            <p className="muted small">Seed {seed} · {result.steps.length} words generated · run again for a different result</p>
            <details>
              <summary>Show each step</summary>
              <ol className="steps">
                {result.steps.map((s, i) => (
                  <li key={i}>
                    chose <b>{s.word}</b> <span className="muted">from {s.top.map((t) => `${t.word} ${percent(t.probability)}`).join(", ")}</span>
                  </li>
                ))}
              </ol>
            </details>
          </div>
        )}
      </div>
    </div>
  );
}

export default NextWordLab;
