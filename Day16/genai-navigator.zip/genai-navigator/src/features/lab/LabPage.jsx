import { useState } from "react";
import SegmentedControl from "../../components/ui/SegmentedControl";
import NextWordLab from "./NextWordLab";
import DiffusionLab from "./DiffusionLab";
import GanLab from "./GanLab";
import { ARCH_BY_ID } from "../../data/models";

const LABS = [
  { id: "transformer", label: "Transformer · next word" },
  { id: "diffusion", label: "Diffusion · noise to image" },
  { id: "gan", label: "GAN · generator vs discriminator" },
];

/** Interactive, simplified demos of the three architectures behind Generative AI. */
function LabPage() {
  const [lab, setLab] = useState("transformer");
  const arch = ARCH_BY_ID[lab];

  return (
    <section>
      <h1>How Generative AI works</h1>
      <p className="muted">Three architectures power almost every model you will meet. Each demo below is a small, honest simplification you can play with.</p>
      <SegmentedControl options={LABS} value={lab} onChange={setLab} label="Architecture" />

      <div className="arch-card">
        <div>
          <h2>{arch.name} <small className="muted">({arch.year})</small></h2>
          <p>{arch.idea}</p>
          <p className="muted"><b>Used for:</b> {arch.goodFor}</p>
        </div>
        <div className="analogy"><b>Think of it as:</b> {arch.analogy}</div>
      </div>

      {lab === "transformer" && <NextWordLab />}
      {lab === "diffusion" && <DiffusionLab />}
      {lab === "gan" && <GanLab />}
    </section>
  );
}

export default LabPage;
