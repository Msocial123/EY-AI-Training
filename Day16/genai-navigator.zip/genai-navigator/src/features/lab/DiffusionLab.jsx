import { useEffect, useRef, useState } from "react";
import Button from "../../components/ui/Button";
import { TOTAL_STEPS, makeSchedule, makeNoise, noisyFrame } from "../../utils/diffusion";
import { percent } from "../../utils/format";

const SIZE = 128;
const SCHEDULE = makeSchedule();
const NOISE = makeNoise(SIZE * SIZE * 4);

/** Draws the "clean" training image: a simple landscape. Returns its RGBA pixels. */
function drawCleanImage() {
  const canvas = document.createElement("canvas");
  canvas.width = SIZE;
  canvas.height = SIZE;
  const ctx = canvas.getContext("2d");
  const sky = ctx.createLinearGradient(0, 0, 0, SIZE);
  sky.addColorStop(0, "#60a5fa");
  sky.addColorStop(1, "#fde68a");
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, SIZE, SIZE);
  ctx.fillStyle = "#f97316";
  ctx.beginPath(); ctx.arc(92, 34, 16, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = "#15803d";
  ctx.beginPath(); ctx.moveTo(0, 96); ctx.lineTo(40, 62); ctx.lineTo(78, 92); ctx.lineTo(108, 70); ctx.lineTo(128, 88); ctx.lineTo(128, 128); ctx.lineTo(0, 128); ctx.fill();
  ctx.fillStyle = "#7c2d12";
  ctx.fillRect(22, 86, 22, 18);
  ctx.fillStyle = "#dc2626";
  ctx.beginPath(); ctx.moveTo(18, 88); ctx.lineTo(33, 74); ctx.lineTo(48, 88); ctx.fill();
  return ctx.getImageData(0, 0, SIZE, SIZE).data;
}

/** Diffusion idea: images are made by removing noise step by step. */
function DiffusionLab() {
  const canvasRef = useRef(null);
  const cleanRef = useRef(null);
  const [step, setStep] = useState(TOTAL_STEPS);
  const [isPlaying, setIsPlaying] = useState(false);

  // Draw the clean image once, after the component appears.
  useEffect(() => {
    cleanRef.current = drawCleanImage();
  }, []);

  // Re-draw the canvas whenever the step changes.
  useEffect(() => {
    if (!cleanRef.current) cleanRef.current = drawCleanImage();
    const pixels = noisyFrame(cleanRef.current, NOISE, SCHEDULE[step]);
    const ctx = canvasRef.current.getContext("2d");
    ctx.putImageData(new ImageData(pixels, SIZE, SIZE), 0, 0);
  }, [step]);

  // "Generate": walk from pure noise (step 50) back to the image (step 0).
  useEffect(() => {
    if (!isPlaying) return undefined;
    const id = setInterval(() => setStep((s) => Math.max(0, s - 1)), 70);
    return () => clearInterval(id);
  }, [isPlaying]);

  // Stop the animation when the clean image is reached.
  useEffect(() => {
    if (isPlaying && step === 0) setIsPlaying(false);
  }, [isPlaying, step]);

  function play() {
    setStep(TOTAL_STEPS);
    setIsPlaying(true);
  }

  return (
    <div className="lab">
      <div className="lab-controls">
        <label className="field">
          <span>Step <b>{step}</b> of {TOTAL_STEPS} · original image left: <b>{percent(Math.sqrt(SCHEDULE[step]))}</b></span>
          <input type="range" min="0" max={TOTAL_STEPS} value={step} disabled={isPlaying} onChange={(e) => setStep(Number(e.target.value))} />
        </label>
        <div className="row">
          <Button onClick={play} isLoading={isPlaying}>{isPlaying ? "Denoising..." : "Generate (denoise 50 → 0)"}</Button>
          <Button variant="ghost" onClick={() => { setIsPlaying(false); setStep(TOTAL_STEPS); }}>Back to pure noise</Button>
        </div>
        <ol className="explain-list">
          <li><b>Training:</b> take real images, add a little noise at each of 50 steps, and teach a neural network to predict the noise that was added.</li>
          <li><b>Generation:</b> start from random noise (step 50). At every step the network predicts the noise and removes it, guided by the text prompt.</li>
          <li>Here we already know the original picture, so you see exactly what each step looks like.</li>
        </ol>
      </div>
      <div className="lab-output center">
        <canvas ref={canvasRef} width={SIZE} height={SIZE} className="diffusion-canvas" aria-label={`Image at diffusion step ${step}`} />
        <p className="muted small">{step === TOTAL_STEPS ? "Pure noise: where generation starts" : step === 0 ? "Clean image: where generation ends" : "Partly denoised"}</p>
      </div>
    </div>
  );
}

export default DiffusionLab;
