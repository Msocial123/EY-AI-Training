import { useState } from "react";
import Button from "../../components/ui/Button";
import SegmentedControl from "../../components/ui/SegmentedControl";
import { listModels } from "../../api/aiClient";

const PRESETS = [
  { id: "openai", label: "OpenAI", baseUrl: "https://api.openai.com/v1" },
  { id: "ollama", label: "Ollama (local, free)", baseUrl: "http://localhost:11434/v1", textModel: "llama3.2" },
];

/**
 * Choose demo mode or a real OpenAI-compatible provider.
 * The form keeps a draft copy; nothing changes in the app until "Save".
 */
function SettingsPage({ config, onSave, onResetToEnv }) {
  const [draft, setDraft] = useState(config);
  const [test, setTest] = useState({ state: "idle" });
  const [saved, setSaved] = useState(false);

  function update(field, value) {
    setDraft((prev) => ({ ...prev, [field]: value }));
    setSaved(false);
    setTest({ state: "idle" });
  }

  function applyPreset(preset) {
    setDraft((prev) => ({ ...prev, provider: "openai", baseUrl: preset.baseUrl, textModel: preset.textModel ?? prev.textModel, apiKey: preset.id === "ollama" ? "" : prev.apiKey }));
    setSaved(false);
  }

  async function testConnection() {
    setTest({ state: "testing" });
    try {
      const models = await listModels(draft);
      setTest({ state: "ok", models });
    } catch (err) {
      setTest({ state: "error", message: err.message });
    }
  }

  function handleSubmit(event) {
    event.preventDefault();
    onSave(draft);
    setSaved(true);
  }

  const isLive = draft.provider === "openai";

  return (
    <section className="settings">
      <h1>Settings</h1>
      <form className="panel" onSubmit={handleSubmit}>
        <label className="field-label">Provider</label>
        <SegmentedControl
          options={[{ id: "demo", label: "Demo (offline, simulated)" }, { id: "openai", label: "OpenAI-compatible API" }]}
          value={draft.provider}
          onChange={(v) => update("provider", v)}
          label="Provider"
        />

        {isLive && (
          <>
            <div className="row">
              <span className="muted small">Quick fill:</span>
              {PRESETS.map((p) => <Button key={p.id} type="button" variant="ghost" size="sm" onClick={() => applyPreset(p)}>{p.label}</Button>)}
            </div>
            <label className="field"><span>Base URL</span>
              <input value={draft.baseUrl} onChange={(e) => update("baseUrl", e.target.value)} placeholder="https://api.openai.com/v1" />
            </label>
            <label className="field"><span>API key (kept in memory only, never saved)</span>
              <input type="password" value={draft.apiKey} onChange={(e) => update("apiKey", e.target.value)} placeholder="Not needed for Ollama" autoComplete="off" />
            </label>
            <div className="row">
              <label className="field inline grow"><span>Text model</span>
                <input value={draft.textModel} onChange={(e) => update("textModel", e.target.value)} placeholder="e.g. llama3.2" />
              </label>
              <label className="field inline grow"><span>Image model</span>
                <input value={draft.imageModel} onChange={(e) => update("imageModel", e.target.value)} placeholder="an image model your provider lists" />
              </label>
            </div>
            <div className="row">
              <Button type="button" variant="secondary" onClick={testConnection} isLoading={test.state === "testing"}>Test connection</Button>
              {test.state === "ok" && <span className="ok-text">✓ Connected · {test.models.length} models: {test.models.slice(0, 4).join(", ")}{test.models.length > 4 ? "..." : ""}</span>}
              {test.state === "error" && <span className="error-text">{test.message}</span>}
            </div>
          </>
        )}

        <div className="row">
          <Button type="submit">Save settings</Button>
          <Button type="button" variant="ghost" onClick={() => { const env = onResetToEnv(); setDraft(env); setSaved(false); }}>Reset to .env defaults</Button>
          {saved && <span className="ok-text">✓ Saved</span>}
        </div>
      </form>

      <div className="panel">
        <h2>Good practice</h2>
        <ul className="explain-list">
          <li><b>Keys:</b> never commit an API key. Put it in <code>.env</code> (already in .gitignore) or type it here for this session only.</li>
          <li><b>Browser apps:</b> anyone using a browser app can see its key. Company apps call AI models from a backend server.</li>
          <li><b>Cost:</b> paid APIs charge per token or per image. Use demo mode or Ollama while practising.</li>
          <li><b>Model names change:</b> click "Test connection" to see the names your provider supports today.</li>
          <li><b>Ollama:</b> install from ollama.com, run <code>ollama pull llama3.2</code>, then choose the Ollama quick fill.</li>
        </ul>
      </div>
    </section>
  );
}

export default SettingsPage;
