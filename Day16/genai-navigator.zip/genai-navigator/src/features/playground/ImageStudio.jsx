import { useState } from "react";
import Button from "../../components/ui/Button";
import SegmentedControl from "../../components/ui/SegmentedControl";
import { IMAGE_STYLES, IMAGE_SAMPLES } from "../../data/promptTemplates";
import { generateImage } from "../../api/aiClient";
import { demoImage } from "../../utils/demoAI";
import { formatMs, timeNow } from "../../utils/format";

const SIZES = ["1024x1024", "1536x1024", "1024x1536"];
const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/** Text-to-image generation. Real images need an image model; demo mode draws a simple placeholder. */
function ImageStudio({ config }) {
  const [prompt, setPrompt] = useState(IMAGE_SAMPLES[0]);
  const [style, setStyle] = useState(IMAGE_STYLES[0]);
  const [size, setSize] = useState(SIZES[0]);
  const [images, setImages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const fullPrompt = `${prompt.trim()}, ${style} style`;

  async function handleGenerate() {
    setIsLoading(true);
    setError("");
    const started = performance.now();
    try {
      let src;
      if (config.provider === "demo") {
        await wait(700);
        src = demoImage(prompt.trim(), style);
      } else {
        src = await generateImage(config, { prompt: fullPrompt, size });
      }
      const image = { id: Date.now(), src, prompt: fullPrompt, ms: performance.now() - started, time: timeNow(), simulated: config.provider === "demo" };
      setImages((prev) => [image, ...prev].slice(0, 4));
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="studio">
      <div className="studio-input">
        <label className="field">
          <span>Describe the image</span>
          <textarea rows={3} value={prompt} onChange={(e) => setPrompt(e.target.value)} />
        </label>
        <div className="chips">
          {IMAGE_SAMPLES.map((s) => <button key={s} className="chip" onClick={() => setPrompt(s)}>{s}</button>)}
        </div>
        <label className="field-label">Style</label>
        <SegmentedControl options={IMAGE_STYLES} value={style} onChange={setStyle} label="Style" />
        <label className="field inline">
          <span>Size</span>
          <select value={size} onChange={(e) => setSize(e.target.value)}>
            {SIZES.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </label>
        <p className="muted small">Final prompt: "{fullPrompt}"</p>
        <Button onClick={handleGenerate} isLoading={isLoading} disabled={!prompt.trim()}>
          {isLoading ? "Generating image..." : "Generate image"}
        </Button>
        <p className="muted small">Real image models use diffusion: they start from noise and denoise towards your prompt (see "How it works").</p>
      </div>

      <div className="studio-output">
        {error && <p className="error-box" role="alert">{error}</p>}
        {images.length === 0 && !error && <p className="placeholder">Generated images will appear here.</p>}
        <div className="gallery">
          {images.map((img) => (
            <figure key={img.id}>
              <img src={img.src} alt={img.prompt} />
              <figcaption className="muted small">{img.simulated ? "Simulated" : "Generated"} · {img.time} · {formatMs(img.ms)}</figcaption>
            </figure>
          ))}
        </div>
      </div>
    </div>
  );
}

export default ImageStudio;
