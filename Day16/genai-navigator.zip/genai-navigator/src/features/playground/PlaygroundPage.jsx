import SegmentedControl from "../../components/ui/SegmentedControl";
import ProviderNotice from "../../components/ui/ProviderNotice";
import TextStudio from "./TextStudio";
import ImageStudio from "./ImageStudio";
import AudioStudio from "./AudioStudio";
import CodeStudio from "./CodeStudio";

const TABS = [
  { id: "text", label: "📝 Text" },
  { id: "image", label: "🖼️ Image" },
  { id: "audio", label: "🎙️ Audio" },
  { id: "code", label: "💻 Code" },
];

/** Try the four types of Generative AI. The active tab lives in App so other pages can open a tab. */
function PlaygroundPage({ tab, onTabChange, config, onOpenSettings }) {
  return (
    <section>
      <h1>Playground</h1>
      <ProviderNotice config={config} onOpenSettings={onOpenSettings} />
      <SegmentedControl options={TABS} value={tab} onChange={onTabChange} label="Generation type" />
      {tab === "text" && <TextStudio config={config} />}
      {tab === "image" && <ImageStudio config={config} />}
      {tab === "audio" && <AudioStudio />}
      {tab === "code" && <CodeStudio config={config} />}
    </section>
  );
}

export default PlaygroundPage;
