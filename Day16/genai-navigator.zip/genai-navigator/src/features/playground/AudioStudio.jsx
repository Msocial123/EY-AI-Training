import { useEffect, useState } from "react";
import Button from "../../components/ui/Button";
import { SPEECH_SAMPLES } from "../../data/promptTemplates";

const supported = typeof window !== "undefined" && "speechSynthesis" in window;

/** Text-to-speech with the browser's built-in speech engine (works offline, no API key). */
function AudioStudio() {
  const [text, setText] = useState(SPEECH_SAMPLES[0]);
  const [voices, setVoices] = useState([]);
  const [voiceName, setVoiceName] = useState("");
  const [rate, setRate] = useState(1);
  const [pitch, setPitch] = useState(1);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Voices load asynchronously in most browsers: listen for the "voiceschanged" event.
  useEffect(() => {
    if (!supported) return undefined;
    function loadVoices() {
      setVoices(window.speechSynthesis.getVoices());
    }
    loadVoices();
    window.speechSynthesis.addEventListener("voiceschanged", loadVoices);
    return () => {
      window.speechSynthesis.removeEventListener("voiceschanged", loadVoices);
      window.speechSynthesis.cancel(); // stop talking if the user leaves the page
    };
  }, []);

  function speak() {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    const voice = voices.find((v) => v.name === voiceName);
    if (voice) utterance.voice = voice;
    utterance.rate = rate;
    utterance.pitch = pitch;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  }

  function stop() {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  }

  return (
    <div className="studio">
      <div className="studio-input">
        {!supported ? (
          <p className="warning-box">This browser does not support speech synthesis. Try Chrome or Edge.</p>
        ) : (
          <>
            <label className="field">
              <span>Text to speak</span>
              <textarea rows={4} value={text} onChange={(e) => setText(e.target.value)} />
            </label>
            <div className="chips">
              {SPEECH_SAMPLES.map((s) => <button key={s} className="chip" onClick={() => setText(s)}>{s.slice(0, 40)}...</button>)}
            </div>
            <label className="field">
              <span>Voice ({voices.length} available on this computer)</span>
              <select value={voiceName} onChange={(e) => setVoiceName(e.target.value)}>
                <option value="">Default voice</option>
                {voices.map((v) => <option key={`${v.name}-${v.lang}`} value={v.name}>{v.name} ({v.lang})</option>)}
              </select>
            </label>
            <div className="row">
              <label className="field inline"><span>Speed {rate.toFixed(1)}</span>
                <input type="range" min="0.5" max="2" step="0.1" value={rate} onChange={(e) => setRate(Number(e.target.value))} />
              </label>
              <label className="field inline"><span>Pitch {pitch.toFixed(1)}</span>
                <input type="range" min="0.5" max="2" step="0.1" value={pitch} onChange={(e) => setPitch(Number(e.target.value))} />
              </label>
            </div>
            <div className="row">
              <Button onClick={speak} disabled={!text.trim()}>{isSpeaking ? "Speaking..." : "▶ Speak"}</Button>
              <Button variant="ghost" onClick={stop} disabled={!isSpeaking}>■ Stop</Button>
            </div>
          </>
        )}
      </div>
      <div className="studio-output">
        <div className="panel">
          <h4>Three kinds of audio Generative AI</h4>
          <ul className="explain-list">
            <li><b>Text-to-speech (this demo):</b> text in, natural voice out. Used for IVR, voice-overs, accessibility.</li>
            <li><b>Speech-to-text:</b> audio in, transcript out (for example Whisper). Used for call analytics and dictation.</li>
            <li><b>Music and sound generation:</b> a description in, new audio out. Used for jingles and background tracks.</li>
          </ul>
          <p className="muted small">This tab uses the speech engine built into your operating system, so it works offline. Enterprise products use neural text-to-speech models through an API for more natural voices and more languages.</p>
        </div>
      </div>
    </div>
  );
}

export default AudioStudio;
