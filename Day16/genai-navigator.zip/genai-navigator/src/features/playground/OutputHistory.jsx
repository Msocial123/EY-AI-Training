import { formatMs } from "../../utils/format";

/** Last few generations (newest first), so the user can compare outputs. */
function OutputHistory({ items, onSelect }) {
  if (items.length === 0) return null;
  return (
    <div className="history">
      <h4>Recent runs</h4>
      <ul>
        {items.map((item) => (
          <li key={item.id}>
            <button className="link" onClick={() => onSelect(item)}>{item.label}</button>
            <span className="muted small"> · {item.time} · {item.simulated ? "simulated" : item.model} · {formatMs(item.ms)}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default OutputHistory;
