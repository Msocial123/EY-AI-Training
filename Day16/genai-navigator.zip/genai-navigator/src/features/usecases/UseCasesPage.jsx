import { useState } from "react";
import { USE_CASES, INDUSTRIES } from "../../data/useCases";
import { GENAI_TYPES } from "../../data/genaiTypes";
import Badge, { TypeBadge } from "../../components/ui/Badge";
import SegmentedControl from "../../components/ui/SegmentedControl";

const TYPE_FILTERS = [{ id: "all", label: "All types" }, ...GENAI_TYPES.map((t) => ({ id: t.id, label: t.label.split(" ")[0] }))];

/** Catalogue of enterprise use cases with industry, type and text filters. */
function UseCasesPage() {
  const [industry, setIndustry] = useState("all");
  const [type, setType] = useState("all");
  const [query, setQuery] = useState("");

  const q = query.trim().toLowerCase();
  const visible = USE_CASES.filter(
    (u) =>
      (industry === "all" || u.industry === industry) &&
      (type === "all" || u.type === type) &&
      (!q || `${u.title} ${u.problem} ${u.approach}`.toLowerCase().includes(q))
  );

  // Count per type for the summary line (derived)
  const counts = GENAI_TYPES.map((t) => ({ id: t.id, n: visible.filter((u) => u.type === t.id).length }));

  return (
    <section>
      <h1>Generative AI across industries</h1>
      <p className="muted">Every use case lists the business value, the main risks and the controls a responsible enterprise puts in place.</p>

      <div className="filters">
        <select value={industry} onChange={(e) => setIndustry(e.target.value)} aria-label="Industry">
          <option value="all">All industries</option>
          {INDUSTRIES.map((i) => <option key={i} value={i}>{i}</option>)}
        </select>
        <SegmentedControl options={TYPE_FILTERS} value={type} onChange={setType} label="Type" />
        <input type="search" placeholder="Search use cases" value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Search use cases" />
      </div>

      <p className="muted">
        {visible.length} use cases · {counts.map((c) => `${c.n} ${c.id}`).join(" · ")}
      </p>

      {visible.length === 0 ? (
        <p className="placeholder">No use cases match these filters.</p>
      ) : (
        <div className="usecase-grid">
          {visible.map((u) => (
            <article key={u.id} className="usecase-card">
              <div className="usecase-head">
                <Badge tone="grey">{u.industry}</Badge>
                <TypeBadge type={u.type} />
              </div>
              <h3>{u.title}</h3>
              <p><b>Problem:</b> {u.problem}</p>
              <p><b>How GenAI helps:</b> {u.approach}</p>
              <p className="value"><b>Value:</b> {u.value}</p>
              <p className="risk"><b>Risks:</b> {u.risks}</p>
              <p className="control"><b>Controls:</b> {u.controls}</p>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}

export default UseCasesPage;
