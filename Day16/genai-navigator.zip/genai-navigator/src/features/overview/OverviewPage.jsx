import { GENAI_TYPES } from "../../data/genaiTypes";
import { KEY_MODELS, TIMELINE, ARCH_BY_ID } from "../../data/models";
import Badge, { TypeBadge } from "../../components/ui/Badge";
import Button from "../../components/ui/Button";

/** What Generative AI is, the four types, the key models and a timeline. */
function OverviewPage({ onTryType }) {
  return (
    <section>
      <div className="hero">
        <div>
          <p className="eyebrow">Generative AI in one sentence</p>
          <h1>AI that <span className="hl">creates new content</span>, such as text, images, audio and code, by learning patterns from huge numbers of examples.</h1>
        </div>
      </div>

      <div className="compare">
        <div className="panel">
          <Badge tone="grey">Traditional (discriminative) AI</Badge>
          <h3>Decides or predicts a label</h3>
          <p className="example">"Is this email spam?" → <b>Yes / No</b></p>
          <p className="example">"Will this customer leave?" → <b>82% likely</b></p>
          <p className="muted">Output is a category or a number chosen from known options.</p>
        </div>
        <div className="panel panel-accent">
          <Badge tone="violet">Generative AI</Badge>
          <h3>Creates something new</h3>
          <p className="example">"Reply to this angry email politely" → <b>a new email</b></p>
          <p className="example">"A coffee maker on a sunny counter" → <b>a new image</b></p>
          <p className="muted">Output did not exist before; the model generates it piece by piece.</p>
        </div>
      </div>

      <h2>Four types of Generative AI</h2>
      <div className="type-grid">
        {GENAI_TYPES.map((t) => (
          <article key={t.id} className={`type-card type-${t.id}`}>
            <div className="type-head">
              <span className="type-icon" aria-hidden="true">{t.icon}</span>
              <h3>{t.label}</h3>
            </div>
            <dl>
              <dt>Input</dt><dd>{t.input}</dd>
              <dt>Output</dt><dd>{t.output}</dd>
              <dt>Architecture</dt><dd>{t.architecture}</dd>
              <dt>Models</dt><dd>{t.models.join(" · ")}</dd>
            </dl>
            <ul className="mini-list">
              {t.examples.map((ex) => <li key={ex}>{ex}</li>)}
            </ul>
            <Button variant="secondary" size="sm" onClick={() => onTryType(t.id)}>Try {t.label.split(" ")[0].toLowerCase()} →</Button>
          </article>
        ))}
      </div>

      <h2>Key models</h2>
      <div className="model-grid">
        {KEY_MODELS.map((m) => (
          <article key={m.id} className="model-card">
            <div className="model-head">
              <h3>{m.name}</h3>
              <TypeBadge type={m.type} />
            </div>
            <p className="muted">{m.maker} · first released {m.firstRelease} · {ARCH_BY_ID[m.architecture].name}</p>
            <p>{m.summary}</p>
            <p className="status"><b>Status:</b> {m.status}</p>
          </article>
        ))}
      </div>

      <h2>Timeline</h2>
      <ol className="timeline">
        {TIMELINE.map((item) => (
          <li key={`${item.year}-${item.title}`} className={`tl-${item.arch}`}>
            <span className="tl-year">{item.year}</span>
            <div>
              <b>{item.title}</b>
              <p className="muted">{item.detail}</p>
            </div>
          </li>
        ))}
      </ol>
    </section>
  );
}

export default OverviewPage;
