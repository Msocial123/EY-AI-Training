/**
 * TODO GN-202 - Mapping exercise: map each problem statement to a GenAI type and a model family.
 * State (use useLocalStorage so progress survives refresh):
 *   answers = { P01: { type: "text", model: "gpt" }, ... }  key "gn-quiz-answers"
 *   checked = false                                          key "gn-quiz-checked"
 * For each PROBLEMS item render: industry Badge, statement, a SegmentedControl of the four types,
 * and a <select> of MODEL_OPTIONS. Update answers immutably: { ...prev, [id]: { ...prev[id], [field]: value } }.
 * Derived (never stored): typeOk = answer.type === p.type; modelOk = p.models.includes(answer.model); score out of 24.
 * "Check answers" sets checked = true and shows per-item feedback (✓/✗, correct type and models, p.why).
 * "Reset" clears answers and checked.
 * CSS: quiz-bar, score, quiz-list, quiz-item (+ ok / bad), quiz-q, quiz-a, quiz-feedback
 */
function MappingQuiz() {
  return <div className="todo"><b>GN-202</b> Mapping exercise: 12 problem statements → type + model, score out of 24</div>;
}

export default MappingQuiz;
