/**
 * TODO GN-203 - "Analyse your own problem statement"
 * State: text, result. On submit (preventDefault) or example-chip click: setResult(classifyProblem(text)).
 * Show: a warning when result.best is null; otherwise the suggested type (TypeBadge + label from TYPE_BY_ID),
 * confidence %, one bar per type with matched keywords, and the suggested models + architecture.
 * CSS: panel, analyzer, chips/chip, warning-box, analysis, analysis-head, score-bars, score-label, prob-bar
 */
function ProblemAnalyzer() {
  return <div className="todo"><b>GN-203</b> Problem analyser: classifyProblem() + result view</div>;
}

export default ProblemAnalyzer;
