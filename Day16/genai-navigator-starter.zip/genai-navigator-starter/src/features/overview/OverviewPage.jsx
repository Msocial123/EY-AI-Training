/**
 * TODO GN-201 - "What is GenAI" page
 * Props: onTryType(typeId) - opens the Playground on that tab
 * Build (all from data, using .map() with keys):
 *  - hero with a one-sentence definition (classes: hero, eyebrow, hl)
 *  - two cards comparing traditional (discriminative) AI vs generative AI (compare, panel, panel-accent, example)
 *  - GENAI_TYPES as cards (type-grid, type-card type-<id>, type-head, type-icon, dl/dt/dd, mini-list) with a "Try ..." Button
 *  - KEY_MODELS as cards (model-grid, model-card, model-head, status) with <TypeBadge type={m.type} />
 *  - TIMELINE as an <ol className="timeline"> with li className={`tl-${item.arch}`} and <span className="tl-year">
 * Imports you will need: GENAI_TYPES (data/genaiTypes), KEY_MODELS, TIMELINE, ARCH_BY_ID (data/models),
 * Badge + TypeBadge (components/ui/Badge), Button.
 */
function OverviewPage() {
  return <div className="todo"><b>GN-201</b> What is GenAI page: definition, four types, key models, timeline</div>;
}

export default OverviewPage;
