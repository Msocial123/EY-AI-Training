/**
 * TODO GN-402 - Text generation studio with prompt templates.
 * Props: config (provider settings from App)
 * State: templateId ("summarize"), input (template sample), tone, length ("short"), temperature (0.7),
 *        output, isLoading, error, history (last 5 runs)
 * Derived: template = TEXT_TEMPLATES.find(...); userPrompt = template.buildUser(input, { tone, length })
 * Generate:
 *   - demo provider: wait ~500 ms, then demoText(templateId, input, { tone, length })
 *   - live provider: chatComplete(config, { messages: [system, user], temperature })
 *   - measure time with performance.now(); push the run to history (newest first, max 5)
 *   - try / catch / finally for isLoading and error
 * UI: task SegmentedControl, input textarea, tone select, length control, temperature slider,
 *     <details className="prompt-preview"> showing SYSTEM and USER prompts, Generate Button,
 *     output card with CopyButton, and <OutputHistory items={history} onSelect={setOutput} />.
 * Look at ImageStudio.jsx: it already follows the same demo / live / loading / error pattern.
 */
function TextStudio() {
  return <div className="todo"><b>GN-402</b> Text studio: templates, prompt preview, demo + live generation, history</div>;
}

export default TextStudio;
