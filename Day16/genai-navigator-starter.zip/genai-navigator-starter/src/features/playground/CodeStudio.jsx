/**
 * TODO GN-403 - Code generation studio (natural language -> code, the job Codex was built for).
 * Props: config
 * State: language ("JavaScript"), request (first CODE_SAMPLES item), code, meta, isLoading, error
 * System prompt: `You are a senior ${language} developer. Reply with only the code in one fenced code block. ...`
 * Generate: demo -> demoCode(request, language); live -> chatComplete(config, { messages, temperature: 0.2 })
 *           then extractCode(result.text) to keep only the code from the ``` block.
 * UI: language SegmentedControl (CODE_LANGUAGES), request textarea, CODE_SAMPLES chips, Generate Button,
 *     warning to review generated code, output <pre className="code-block"><code> with CopyButton.
 */
function CodeStudio() {
  return <div className="todo"><b>GN-403</b> Code studio: language, request, demo + live code generation</div>;
}

export default CodeStudio;
