// Forward diffusion: x_t = sqrt(alphaBar_t) * x_0 + sqrt(1 - alphaBar_t) * noise
// t = 0 is the clean image, t = T is almost pure noise.
// A real diffusion model is trained to PREDICT the noise so it can walk back from t = T to t = 0.
import { createRandom, gaussian } from "./random";

export const TOTAL_STEPS = 50;

/** alphaBar[t] = how much of the original image is left at step t (1 = all of it, ~0 = none). */
export function makeSchedule(steps = TOTAL_STEPS, betaStart = 0.0005, betaEnd = 0.2) {
  const alphaBar = [1];
  let product = 1;
  for (let t = 1; t <= steps; t++) {
    const beta = betaStart + ((betaEnd - betaStart) * (t - 1)) / (steps - 1);
    product *= 1 - beta;
    alphaBar.push(product);
  }
  return alphaBar;
}

/** One fixed noise value per pixel channel (seeded, so every step uses the same noise). */
export function makeNoise(length, seed = 7) {
  const random = createRandom(seed);
  const noise = new Float32Array(length);
  for (let i = 0; i < length; i++) noise[i] = gaussian(random);
  return noise;
}

/**
 * TODO GN-302 - Mix the clean image with noise for step t.
 * For every pixel i (step 4: R, G, B, A) and channel c in 0..2:
 *   x0 = clean[i + c] / 127.5 - 1                       (0..255 -> -1..1)
 *   xt = sqrt(alphaBarT) * x0 + sqrt(1 - alphaBarT) * noise[i + c]
 *   out[i + c] = (xt + 1) * 127.5                       (-1..1 -> 0..255)
 * Set out[i + 3] = 255 (fully opaque). Return a new Uint8ClampedArray.
 * Until this is done the image never gets noisy.
 */
export function noisyFrame(clean, noise, alphaBarT) {
  void noise; void alphaBarT;
  return new Uint8ClampedArray(clean);
}
