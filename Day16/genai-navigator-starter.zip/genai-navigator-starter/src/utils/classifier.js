// Rule-based helper that suggests which Generative AI type fits a problem statement.
// It is NOT an AI model: it looks for keywords. Useful as a first guess and to explain the thinking.

const KEYWORDS = {
  text: ["summar", "email", "draft", "report", "chat", "answer", "question", "translat", "policy", "document",
    "article", "description", "reply", "sentiment", "classif", "letter", "faq", "knowledge", "proposal", "minutes", "review"],
  image: ["image", "photo", "picture", "banner", "logo", "design", "visual", "poster", "illustration", "thumbnail",
    "render", "face", "mockup", "creative", "catalogue", "drawing", "x-ray", "defect"],
  audio: ["audio", "voice", "speech", "call", "recording", "podcast", "music", "jingle", "sound", "transcri", "ivr",
    "narrat", "dictat", "spoken", "announcement"],
  code: ["code", "sql", "query", "unit test", "function", "script", "api", "bug", "refactor", "program", "java",
    "python", "cobol", "regex", "developer", "migrat", "automation"],
};

const SUGGESTIONS = {
  text: { models: "GPT or another LLM (Llama, Claude, Gemini)", architecture: "Transformer" },
  image: { models: "Stable Diffusion, GPT Image (successor of DALL·E); GAN for synthetic faces", architecture: "Diffusion (or GAN)" },
  audio: { models: "Whisper for speech-to-text; a TTS model for voice; a music model for jingles", architecture: "Transformer / diffusion for audio" },
  code: { models: "GPT-class code models (successors of Codex), GitHub Copilot", architecture: "Transformer trained on code" },
};

/**
 * TODO GN-203 - Score each type by counting keyword matches.
 * 1. text = statement.toLowerCase()
 * 2. For every [type, words] in KEYWORDS: matches = words that text.includes(); score = matches.length
 * 3. Sort scores from high to low. total = sum of scores.
 * 4. If total is 0 -> { best: null, confidence: 0, scores, suggestion: null }
 * 5. Else best = scores[0].type, confidence = Math.round(scores[0].score / total * 100), suggestion = SUGGESTIONS[best]
 * Example: "Convert doctor voice recordings into text notes" -> best "audio"
 */
export function classifyProblem(statement) {
  void statement; void KEYWORDS; void SUGGESTIONS;
  return { best: null, confidence: 0, scores: [], suggestion: null };
}
