// A tiny next-word language model (trigram with fallback).
// GPT does the same job - predict the next token from the previous ones - but with a Transformer
// neural network and billions of parameters. Here we simply COUNT which word follows which.
import { createRandom } from "./random";

/** "Your order HAS shipped." -> ["your", "order", "has", "shipped", "."] */
export function tokenize(text) {
  return text.toLowerCase().match(/[a-z0-9']+|[.,!?]/g) || [];
}

/**
 * Builds count tables from the training text.
 * trigrams["your order"]["has"] = how many times "has" came after "your order".
 */
export function trainModel(text) {
  const tokens = tokenize(text);
  const unigrams = {};
  const bigrams = {};
  const trigrams = {};

  for (let i = 0; i < tokens.length; i++) {
    const w = tokens[i];
    unigrams[w] = (unigrams[w] || 0) + 1;
    if (i >= 1) {
      const prev = tokens[i - 1];
      bigrams[prev] = bigrams[prev] || {};
      bigrams[prev][w] = (bigrams[prev][w] || 0) + 1;
    }
    if (i >= 2) {
      const key = `${tokens[i - 2]} ${tokens[i - 1]}`;
      trigrams[key] = trigrams[key] || {};
      trigrams[key][w] = (trigrams[key][w] || 0) + 1;
    }
  }
  return { unigrams, bigrams, trigrams, vocabularySize: Object.keys(unigrams).length, tokenCount: tokens.length };
}

/**
 * TODO GN-301 - Probability of every possible next word, given the words so far.
 * 1. If there are 2+ context words and model.trigrams["w1 w2"] exists, use it (source "trigram").
 * 2. Else if model.bigrams[lastWord] exists, use it (source "bigram").
 * 3. Else use model.unigrams (source "unigram").
 * Turn the counts into probabilities (count / total) and sort from most to least likely.
 * Example: context ["your", "order"] -> options[0] = { word: "has", probability: 0.428... } (3 of 7), source "trigram"
 * Returns { options: [{ word, probability }], source }
 */
export function nextWordDistribution(model, contextTokens) {
  void model; void contextTokens;
  return { options: [], source: "todo" };
}

/**
 * TODO GN-301 - Reshape probabilities with temperature.
 * weight = probability ^ (1 / temperature), then divide every weight by the sum of weights.
 * Use Math.max(0.05, temperature) so we never divide by zero.
 * Low temperature -> top word gets even more likely. High temperature -> flatter.
 */
export function applyTemperature(options, temperature) {
  void temperature;
  return options;
}

/**
 * TODO GN-301 - Pick one word at random according to the probabilities ("weighted wheel").
 * r = random(); walk through options subtracting each probability; return the word where r <= 0.
 * If nothing is chosen (rounding), return the last option's word. Return "." when options is empty.
 */
export function sample(options, random) {
  void random;
  return options.length ? options[0].word : ".";
}

/** Generates `maxWords` words after the prompt. Stops early at a full stop. */
export function generate(model, prompt, { maxWords = 15, temperature = 0.7, seed = 42 } = {}) {
  const random = createRandom(seed);
  const tokens = tokenize(prompt);
  const steps = [];

  for (let i = 0; i < maxWords; i++) {
    const { options, source } = nextWordDistribution(model, tokens);
    const shaped = applyTemperature(options, temperature);
    const word = sample(shaped, random);
    steps.push({ word, source, top: shaped.slice(0, 3) });
    tokens.push(word);
    if (word === ".") break;
  }
  return { text: tokens.join(" ").replace(/ ([.,!?])/g, "$1"), steps };
}
