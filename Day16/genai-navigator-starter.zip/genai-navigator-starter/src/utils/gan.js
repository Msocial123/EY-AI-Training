// A simplified GAN game in one dimension (no neural networks).
// REAL data: delivery times (minutes) of real orders, around 35 ± 6.
// GENERATOR: makes fake delivery times from its own mean and spread, starting badly.
// DISCRIMINATOR: tries to tell real from fake. Its accuracy falls to ~50% when the fakes look real.
import { createRandom, gaussian } from "./random";

export const REAL = { mean: 35, sd: 6 };
export const BINS = { min: 0, max: 80, count: 16 };

export function initialGenerator() {
  return { mean: 10, sd: 4 };
}

/** Draws `n` samples from a normal distribution. */
export function drawSamples(params, n, random) {
  return Array.from({ length: n }, () => params.mean + params.sd * gaussian(random));
}

/** Counts samples into equal-width bins for the histogram. */
export function histogram(samples) {
  const width = (BINS.max - BINS.min) / BINS.count;
  const counts = new Array(BINS.count).fill(0);
  for (const s of samples) {
    const i = Math.min(BINS.count - 1, Math.max(0, Math.floor((s - BINS.min) / width)));
    counts[i] += 1;
  }
  return counts;
}

/**
 * TODO GN-303 - Best possible discriminator accuracy.
 * overlap = sum over bins of min(realCounts[i], fakeCounts[i]) / n
 * accuracy = 0.5 + 0.5 * (1 - overlap)      (1.0 = fakes obvious, 0.5 = fakes look real)
 */
export function discriminatorAccuracy(realCounts, fakeCounts, n) {
  void realCounts; void fakeCounts; void n;
  return 1;
}

/**
 * TODO GN-303 - One training round.
 * 1. random = createRandom(1000 + round); real = drawSamples(REAL, n, random); fake = drawSamples(generator, n, random)
 * 2. realCounts = histogram(real), fakeCounts = histogram(fake), accuracy = discriminatorAccuracy(...)
 * 3. next.mean = generator.mean + learningRate * (REAL.mean - generator.mean); same for sd
 * Return { realCounts, fakeCounts, accuracy, next }
 */
export function trainingRound(generator, round, learningRate = 0.3, n = 400) {
  void round; void learningRate; void n; void createRandom; void drawSamples;
  const empty = new Array(BINS.count).fill(0);
  return { realCounts: empty, fakeCounts: empty, accuracy: 1, next: { ...generator } };
}
