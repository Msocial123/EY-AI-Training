// AI CLIENT: one place that talks to a Generative AI provider.
// Works with any OpenAI-compatible API: OpenAI (https://api.openai.com/v1), Ollama (http://localhost:11434/v1),
// Azure OpenAI or other gateways that follow the same request format.
// In "demo" mode no network call is made; the demo functions in utils/demoAI.js are used instead.
//
// SECURITY NOTE: a key in a browser app can be read by anyone using the app. That is acceptable for a
// personal learning project only. Company apps keep keys on a backend server and call the AI from there.

/** Default settings come from .env (see .env.example). The Settings page can override them. */
export function getEnvConfig() {
  const env = import.meta.env;
  return {
    provider: env.VITE_AI_PROVIDER || "demo",
    baseUrl: env.VITE_AI_BASE_URL || "https://api.openai.com/v1",
    apiKey: env.VITE_AI_API_KEY || "",
    textModel: env.VITE_AI_TEXT_MODEL || "",
    imageModel: env.VITE_AI_IMAGE_MODEL || "",
  };
}

function buildHeaders(config) {
  const headers = { "Content-Type": "application/json" };
  if (config.apiKey) headers.Authorization = `Bearer ${config.apiKey}`;
  return headers;
}

/** Converts HTTP problems into messages a user can act on. */
function friendlyError(status, detail) {
  if (status === 401) return "The API key was rejected (401). Check the key in Settings.";
  if (status === 403) return "Access denied (403). Your key may not have access to this model.";
  if (status === 404) return "Not found (404). Check the base URL and the model name.";
  if (status === 429) return "Rate limit or quota exceeded (429). Wait a moment or check your billing.";
  if (status >= 500) return `The AI service had a problem (${status}). Try again shortly.`;
  return `Request failed (${status}). ${detail || ""}`.trim();
}

/** fetch() with a timeout, JSON parsing and friendly errors. */
async function request(config, path, { method = "GET", body, timeoutMs = 60000 } = {}) {
  const url = `${config.baseUrl.replace(/\/+$/, "")}${path}`;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  let response;
  try {
    response = await fetch(url, {
      method,
      headers: buildHeaders(config),
      body: body ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    });
  } catch (err) {
    if (err.name === "AbortError") throw new Error(`No response after ${timeoutMs / 1000} seconds. The model may be busy.`);
    throw new Error(`Cannot reach ${config.baseUrl}. Is the server running and does it allow requests from this site (CORS)?`);
  } finally {
    clearTimeout(timer);
  }

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = data?.error?.message || data?.message || "";
    const error = new Error(friendlyError(response.status, detail));
    error.status = response.status;
    error.detail = detail;
    throw error;
  }
  return data;
}

/** GET /models -> list of model ids. Used by "Test connection" in Settings. */
export async function listModels(config) {
  const data = await request(config, "/models", { timeoutMs: 15000 });
  return (data.data || []).map((m) => m.id);
}

/**
 * TODO GN-401 - POST /chat/completions -> { text, usage, model }
 * 1. If config.textModel is empty, throw new Error("No text model is set. Add a model name in Settings.")
 * 2. body = { model: config.textModel, messages } and add temperature only when it is not undefined
 * 3. data = await request(config, "/chat/completions", { method: "POST", body })
 * 4. If the server answers 400 and err.detail mentions "temperature", delete body.temperature and try once more
 * 5. text = data.choices[0].message.content (use ?. so a missing field does not crash); throw if empty
 * 6. return { text, usage: data.usage || null, model: data.model || config.textModel }
 */
export async function chatComplete(config, { messages, temperature }) {
  void config; void messages; void temperature;
  throw new Error("chatComplete is not implemented yet (ticket GN-401). Use demo mode for now.");
}

/**
 * TODO GN-401 - POST /images/generations -> an image src for <img>
 * 1. If config.imageModel is empty, throw a clear error
 * 2. data = await request(config, "/images/generations", { method: "POST", body: { model, prompt, size, n: 1 }, timeoutMs: 120000 })
 * 3. item = data.data[0]; if item.b64_json return "data:image/png;base64," + item.b64_json; else if item.url return item.url
 * 4. Otherwise throw new Error("The image service returned no image.")
 */
export async function generateImage(config, { prompt, size = "1024x1024" }) {
  void config; void prompt; void size;
  throw new Error("generateImage is not implemented yet (ticket GN-401). Use demo mode for now.");
}
