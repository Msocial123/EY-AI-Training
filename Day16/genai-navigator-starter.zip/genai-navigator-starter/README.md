# GenAI Navigator

An internal tool that helps business and engineering teams understand Generative AI and choose the right approach for a business problem. Read the **Project Brief** before you start: it has the requirements, tickets, acceptance criteria and test cases.

## Run it

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # must pass before every pull request
```

Node.js 20.19+ or 22.12+ is required. The app runs offline in **demo mode**; no API key is needed to complete the tickets.

## What is ready and what you build

| Ready to use | You build |
|---|---|
| `App.jsx`, navigation, Header, Settings page | `features/overview/OverviewPage.jsx` (GN-201) |
| `data/` types, models, timeline, problems, use cases, prompts, corpus | `features/mapper/MappingQuiz.jsx` (GN-202) |
| `components/ui/` Button, Badge, SegmentedControl, CopyButton, ProviderNotice | `utils/classifier.js` + `features/mapper/ProblemAnalyzer.jsx` (GN-203) |
| `utils/demoAI.js`, `random.js`, `format.js` | `utils/ngram.js` three functions (GN-301) |
| Lab pages (they call your functions) | `utils/diffusion.js` `noisyFrame` (GN-302) |
| `ImageStudio.jsx`, `AudioStudio.jsx` (use them as examples) | `utils/gan.js` two functions (GN-303) |
| `api/aiClient.js` request helper and `listModels` | `api/aiClient.js` `chatComplete` + `generateImage` (GN-401) |
| `styles.css` (all class names are listed in each TODO comment) | `TextStudio.jsx` (GN-402), `CodeStudio.jsx` (GN-403), `UseCasesPage.jsx` (GN-501) |

Every file or function you build starts with a `TODO` comment: the ticket number, what it receives, what it must return or show, an example, and the CSS classes to use. Yellow dashed boxes on screen show unfinished tickets.

## Connecting a real model (optional)

Copy `.env.example` to `.env` (or use the Settings page):

- **Ollama (free, local):** install from ollama.com, run `ollama pull llama3.2`, set the base URL to `http://localhost:11434/v1` and the text model to `llama3.2`.
- **OpenAI:** base URL `https://api.openai.com/v1`, your API key, and a model name from your account.

Never commit `.env` or an API key.

## Git workflow

```bash
git checkout -b feature/GN-301-next-word-model
git add .
git commit -m "GN-301: next-word distribution, temperature and sampling"
git push -u origin feature/GN-301-next-word-model
```
